SELECT ta_hjurnal.`keterangan`, ta_djurnal.`no_bukti`, ta_hjurnal.`tgl_trans`, ta_hjurnal.`id_djt`, ta_djurnal.`no_urut`, ta_djurnal.`id_akun3`, akun3.`nama_akun3`, ta_djurnal.Debet, ta_djurnal.Kredit
FROM ta_djurnal 
INNER JOIN ta_hjurnal ON ta_djurnal.`no_bukti` = ta_hjurnal.`no_bukti`
LEFT JOIN akun3 ON ta_djurnal.`id_akun3`=akun3.`id_akun3`
ORDER BY ta_hjurnal.`tgl_trans`,ta_djurnal.`no_bukti`, ta_djurnal.`no_urut`