/*
SQLyog Ultimate v12.5.1 (64 bit)
MySQL - 10.4.16-MariaDB : Database - taxakuwarta
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`taxakuwarta` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `taxakuwarta`;

/*Table structure for table `akun1` */

DROP TABLE IF EXISTS `akun1`;

CREATE TABLE `akun1` (
  `id_akun1` char(1) NOT NULL,
  `nama_akun1` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_akun1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `akun1` */

insert  into `akun1`(`id_akun1`,`nama_akun1`) values 
('1','Aset'),
('2','Liabilitas'),
('3','Equitas'),
('4','Pendapatan'),
('5','Beban'),
('6','Koreksi Fiskal'),
('7','Taksiran PPH');

/*Table structure for table `akun2` */

DROP TABLE IF EXISTS `akun2`;

CREATE TABLE `akun2` (
  `id_akun1` char(1) NOT NULL,
  `id_akun2` char(3) NOT NULL,
  `nama_akun2` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_akun1`,`id_akun2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `akun2` */

insert  into `akun2`(`id_akun1`,`id_akun2`,`nama_akun2`) values 
('1','110','Aset Lancar'),
('1','120','Aset Tidak Lancar'),
('2','210','Liabilitas Jangka Pendek'),
('2','220','Liabilitas Jangka Panjang'),
('3','310','Modal Saham, Modal Dasar'),
('3','320','Tambahan Modal Disetor'),
('3','330','Saham Treasuri'),
('3','340','Selisih Kurs Karena Penjabaran'),
('3','350','Saldo Laba'),
('4','410','Pendapatan Jasa'),
('4','420','Pendapatan Penjualan'),
('4','430','Pendapatan Lain'),
('5','510','Beban Pokok Penjualan'),
('5','520','Beban Operasi'),
('5','530','Beban Lain'),
('6','610','Perbedaan Waktu'),
('6','620','Perbedaan Tetap'),
('6','630','Kompensasi Rugi Pajak'),
('7','710','Taksiran PPH');

/*Table structure for table `akun3` */

DROP TABLE IF EXISTS `akun3`;

CREATE TABLE `akun3` (
  `id_akun1` char(1) NOT NULL,
  `id_akun2` char(3) NOT NULL,
  `id_akun3` char(5) NOT NULL,
  `nama_akun3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_akun1`,`id_akun2`,`id_akun3`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `akun3` */

insert  into `akun3`(`id_akun1`,`id_akun2`,`id_akun3`,`nama_akun3`) values 
('1','110','','Aset Lancar'),
('1','110','11010','Kas dan Setara Kas'),
('1','110','11020','Invenstasi Jangka Pendek'),
('1','110','11030','Piutang Usaha'),
('1','110','11040','Piutang Lain-lain Pihak Ketiga'),
('1','110','11050','Persediaan'),
('1','110','11060','Pajak Dibayar Dimuka'),
('1','110','11070','Uang Muka dan Biaya Dibayar Dimuka'),
('1','120','','Aset Tidak Lancar'),
('1','120','12010','Uang Muka Investasi'),
('1','120','12015','Property Investasi'),
('1','120','12020','Aset Tetap - Setelah Penyusutan'),
('1','120','12025','Aset Tak Berwujud - Bersih'),
('1','120','12030','Aset Eksplorasi dan Evaluasi'),
('1','120','12035','Aset Pajak Tangguhan- Bersih'),
('1','120','12040','Aset Tambang - Bersih'),
('1','120','12045','Akumulasi Penyusutan'),
('1','120','12050','Uang Muka Jangka Panjang'),
('1','120','12055','Taksiran Tagihan Pajak'),
('1','120','12060','Aset Dalam Pengerjaan'),
('1','120','12065','Goodwil'),
('1','120','12070','Aset Keuangan Jasa Konsesi'),
('1','120','12075','Bank Garansi'),
('1','120','12080','Aset Tidak Lancar Lainnya'),
('2','210','','Liabilitas Jangka Pendek'),
('2','210','21010','Utang Usaha - Pihak Ketiga'),
('2','210','21020','Utang Lain-lain - Pihak Ketiga'),
('2','210','21030','Utang Pajak'),
('2','210','21040','Beban Akrual'),
('2','210','21050','Uang Jaminan'),
('2','210','21060','Liabilitas Imbalan Kerja'),
('2','210','21070','Liabilitas Jangka Panjang yang Jatuh Tempo'),
('2','210','21080','Pendapatan Diterima Dimuka'),
('2','220','','Liabilitas Jangka Panjang'),
('2','220','22010','Utang Bank'),
('2','220','22020','Liabilitas Imbalan Kerja'),
('2','220','22030','Uang Jaminan'),
('2','220','22040','Utang Kepada Pihak-pihak Berelasi'),
('2','220','22050','Liabilitas Pajak Tangguhan - Bersih'),
('2','220','22060','Provisi Pengelolaan dan Reklamasi Lingkungan Hidup'),
('2','220','22070','Liabilitas Jangka Panjang - Setelah Dikurangi Yg Jatuh Tempo'),
('3','310','','Modal Saham, Modal Dasar'),
('3','310','31010','Modal Dasar Ditempatkan'),
('3','320','','Tambahan Modal Disetor'),
('3','320','32010','Tambahan Modal Disetor '),
('3','330','','Saham Treasuri'),
('3','330','33010','Saham Treasuri'),
('3','340','','Selisih Kurs Karena Penjabaran Laporan Keuangan'),
('3','340','34010','Selisih Kurs Karena Penjabaran Laporan Keuangan'),
('3','350','','Saldo Laba'),
('3','350','35010','Laba Rugi Tahun Lalu'),
('3','350','35020','Laba Rugi Tahun Berjalan'),
('4','410','','Pendapatan Jasa'),
('4','410','41010','Pendapatan Jasa Konstruksi'),
('4','410','41020','Pendapatan Jasa Pembiayaan'),
('4','420','','Pendapatan Penjualan'),
('4','420','42010','Pendapatan Penjualan'),
('4','430','43010','Pendapatan Lain'),
('5','510','','Beban Pokok Penjualan'),
('5','510','51010','Beban Pokok Penjualan'),
('5','510','51020','Biaya Ditangguhkan- CIP'),
('5','510','51030','Biaya Ditangguhkan- Pembiayaan'),
('5','520','','Beban Operasi'),
('5','520','52010','Beban Operasi'),
('5','530','','Beban Lain'),
('5','530','53020','Beban Lain'),
('6','610','61010','Perbedaan Antara Piutang dengan Aset Tetap'),
('6','610','61020','Beban Bunga'),
('6','620','62010','Biaya Yang Tidak Dapat Dikurangkan'),
('6','620','62020','Pendapatan yang Dikenakan Pajak Final'),
('6','620','62030','Selisih Karena Pengukuran Kembali Laporan Keuangan'),
('6','620','62040','Aset Pajak Tangguhan yang Tidak Dapat Diakui'),
('6','630','63010','Kompensasi-Rugi Pajak Tahun Berjalan'),
('6','630','63020','Kompensai-Rugi Pajak '),
('7','710','71010','Taksiran Pajak Penghasilan Tahun Berjalan'),
('7','710','71020','Penyesuaian Pajak Tahun Sebelumnya Tangguhan ');

/*Table structure for table `r_djt` */

DROP TABLE IF EXISTS `r_djt`;

CREATE TABLE `r_djt` (
  `id_jt` int(1) NOT NULL,
  `id_djt` int(2) NOT NULL,
  `nama_djt` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_jt`,`id_djt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `r_djt` */

insert  into `r_djt`(`id_jt`,`id_djt`,`nama_djt`) values 
(1,11,'Jasa CIP-Konstruksi'),
(1,12,'Jasa Pembiayaan-Konstruksi'),
(2,21,'Fixed Operating and Maintenance'),
(2,22,'Energy Payment (Fuel Cost)'),
(2,23,'Variable Operating and Maintenance'),
(2,24,'Special Facility and Others (Commisioning)'),
(3,31,'General Journal'),
(3,32,'Adjustment Journal'),
(4,41,'Time Difference'),
(4,42,'Permanent Difference'),
(5,51,'Opening Balance');

/*Table structure for table `r_hjt` */

DROP TABLE IF EXISTS `r_hjt`;

CREATE TABLE `r_hjt` (
  `id_jt` int(1) NOT NULL,
  `nama_jt` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_jt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `r_hjt` */

insert  into `r_hjt`(`id_jt`,`nama_jt`) values 
(1,'CCR'),
(2,'OM'),
(3,'JU'),
(4,'FA'),
(5,'OB');

/*Table structure for table `r_perush` */

DROP TABLE IF EXISTS `r_perush`;

CREATE TABLE `r_perush` (
  `nama` varchar(200) NOT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `kodepos` varchar(10) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `pimpinan` varchar(100) DEFAULT NULL,
  `tahun` int(4) NOT NULL,
  PRIMARY KEY (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `r_perush` */

insert  into `r_perush`(`nama`,`alamat`,`kodepos`,`telepon`,`email`,`pimpinan`,`tahun`) values 
('PT Wahana Energi Sejehtera',NULL,NULL,NULL,NULL,'Jacob Tedjakusuma',2020);

/*Table structure for table `ta_ccr` */

DROP TABLE IF EXISTS `ta_ccr`;

CREATE TABLE `ta_ccr` (
  `no_bukti` char(20) NOT NULL,
  `no_urut` int(2) NOT NULL,
  `tgl_trans` date NOT NULL,
  `id_akun3` char(5) NOT NULL,
  `jc` varchar(100) NOT NULL,
  `debet` double DEFAULT 0,
  `kredit` double DEFAULT 0,
  `keterangan` varchar(200) DEFAULT 'Pembayaran atas kapasitas',
  PRIMARY KEY (`no_bukti`,`no_urut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `ta_ccr` */

/*Table structure for table `ta_djurnal` */

DROP TABLE IF EXISTS `ta_djurnal`;

CREATE TABLE `ta_djurnal` (
  `no_bukti` char(20) NOT NULL,
  `no_urut` int(2) NOT NULL,
  `id_akun3` char(5) DEFAULT NULL,
  `dk` char(1) DEFAULT NULL,
  `debet` double DEFAULT NULL,
  `kredit` double DEFAULT NULL,
  PRIMARY KEY (`no_bukti`,`no_urut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `ta_djurnal` */

/*Table structure for table `ta_hjurnal` */

DROP TABLE IF EXISTS `ta_hjurnal`;

CREATE TABLE `ta_hjurnal` (
  `no_bukti` char(20) NOT NULL,
  `periode` int(4) DEFAULT NULL,
  `tgl_trans` date DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `id_djt` int(2) DEFAULT NULL,
  PRIMARY KEY (`no_bukti`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `ta_hjurnal` */

/*Table structure for table `ta_neraca_saldo` */

DROP TABLE IF EXISTS `ta_neraca_saldo`;

CREATE TABLE `ta_neraca_saldo` (
  `no_bukti` char(20) NOT NULL,
  `periode` char(6) NOT NULL,
  `akun3` char(5) NOT NULL,
  `totaldebet` double DEFAULT NULL,
  `totalkredit` double DEFAULT NULL,
  `saldodebet` double DEFAULT NULL,
  `saldokredit` double DEFAULT NULL,
  PRIMARY KEY (`no_bukti`,`periode`,`akun3`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `ta_neraca_saldo` */

insert  into `ta_neraca_saldo`(`no_bukti`,`periode`,`akun3`,`totaldebet`,`totalkredit`,`saldodebet`,`saldokredit`) values 
('FA-201129000','','62010',-888888,-344,NULL,NULL),
('FA-201129000','','63010',-1012343,0,NULL,NULL),
('FA-201129000','','71010',0,0,NULL,NULL),
('GJ-201129000','','11050',0,-3455,NULL,NULL),
('GJ-201129000','','21030',-1456,0,NULL,NULL),
('OB-201129000','','12025',0,-77777,NULL,NULL),
('OB-201129000','','12055',-1111111,0,NULL,NULL);

/*Table structure for table `ta_om` */

DROP TABLE IF EXISTS `ta_om`;

CREATE TABLE `ta_om` (
  `no_bukti` char(20) NOT NULL,
  `no_urut` int(2) NOT NULL,
  `tgl_trans` date NOT NULL,
  `id_akun3` char(5) NOT NULL,
  `jom` varchar(100) NOT NULL,
  `debet` double DEFAULT 0,
  `kredit` double DEFAULT 0,
  `keterangan` varchar(200) DEFAULT 'Pembayaran atas OM',
  PRIMARY KEY (`no_bukti`,`no_urut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `ta_om` */

/*Table structure for table `ta_periode` */

DROP TABLE IF EXISTS `ta_periode`;

CREATE TABLE `ta_periode` (
  `periode` char(6) DEFAULT NULL,
  `dari_tgl` date DEFAULT NULL,
  `sampai_tgl` date DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `ta_periode` */

insert  into `ta_periode`(`periode`,`dari_tgl`,`sampai_tgl`,`status`) values 
('202011','2020-11-01','2020-11-30','posted');

/*Table structure for table `ta_saldo_awal` */

DROP TABLE IF EXISTS `ta_saldo_awal`;

CREATE TABLE `ta_saldo_awal` (
  `periode` year(4) NOT NULL,
  `rek4` char(10) NOT NULL,
  `debet` double NOT NULL,
  `kredit` double NOT NULL,
  `tgl_insert` datetime NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`periode`,`rek4`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `ta_saldo_awal` */

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `iduser` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `level` enum('super admin','admin','user') NOT NULL,
  `foto` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`iduser`,`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `users` */

insert  into `users`(`iduser`,`username`,`password`,`nama_lengkap`,`level`,`foto`) values 
(1,'1','•','','',NULL),
(2,'2','–','','',NULL),
(3,'admin','ÅÈÑÍÒ','','',NULL);

/* Trigger structure for table `ta_djurnal` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `ti_ta_djurnal` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `ti_ta_djurnal` AFTER INSERT ON `ta_djurnal` FOR EACH ROW BEGIN
	INSERT INTO ta_neraca_saldo 
	SET no_bukti = new.no_bukti, akun3 = new.id_akun3, totaldebet	= new.debet, totalkredit = new.kredit
	ON DUPLICATE	KEY UPDATE totaldebet	= totaldebet+new.debet, totalkredit = totalkredit+new.kredit;
    END */$$


DELIMITER ;

/* Trigger structure for table `ta_djurnal` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `ta_ta_djurnal` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `ta_ta_djurnal` AFTER UPDATE ON `ta_djurnal` FOR EACH ROW BEGIN
	INSERT INTO ta_neraca_saldo 
	SET no_bukti = new.no_bukti, akun3 = new.id_akun3, totaldebet = new.debet, totalkredit = new.kredit
	ON DUPLICATE	KEY UPDATE totaldebet	= new.debet, totalkredit = new.kredit;

    END */$$


DELIMITER ;

/* Trigger structure for table `ta_djurnal` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `td_ta_djurnal` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `td_ta_djurnal` AFTER DELETE ON `ta_djurnal` FOR EACH ROW BEGIN
	UPDATE ta_neraca_saldo
	SET totaldebet	= totaldebet-old.debet, totalkredit = totalkredit-old.kredit
	WHERE no_bukti	= old.no_bukti; 
	

    END */$$


DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
