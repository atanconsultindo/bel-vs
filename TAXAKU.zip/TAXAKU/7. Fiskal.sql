

SELECT LEFT(ta_djurnal.id_akun3,'1') AS akun1, akun1.nama_akun1, LEFT(ta_djurnal.id_akun3,'3')  AS akun2, akun2.nama_akun2, ta_djurnal.id_akun3, akun3.nama_akun3, SUM(ta_djurnal.kredit)-SUM(ta_djurnal.debet) AS SumNilai FROM ta_djurnal
LEFT JOIN akun1 ON  LEFT(ta_djurnal.id_akun3,'1') = akun1.id_akun1
LEFT JOIN akun2 ON  LEFT(ta_djurnal.id_akun3,'3') = akun2.id_akun2
LEFT JOIN akun3 ON  ta_djurnal.id_akun3 = akun3.id_akun3
GROUP BY LEFT(ta_djurnal.id_akun3,'1'), akun1.nama_akun1, LEFT(ta_djurnal.id_akun3,'3'), akun2.nama_akun2, ta_djurnal.id_akun3, akun3.nama_akun3
HAVING LEFT(ta_djurnal.id_akun3,'1')='6'

UNION

SELECT LEFT(ta_djurnal.id_akun3,'1') AS akun1, akun1.nama_akun1, LEFT(ta_djurnal.id_akun3,'3')  AS akun2, akun2.nama_akun2, ta_djurnal.id_akun3, akun3.nama_akun3, SUM(ta_djurnal.kredit)-SUM(ta_djurnal.debet) AS SumNilai FROM ta_djurnal
LEFT JOIN akun1 ON  LEFT(ta_djurnal.id_akun3,'1') = akun1.id_akun1
LEFT JOIN akun2 ON  LEFT(ta_djurnal.id_akun3,'3') = akun2.id_akun2
LEFT JOIN akun3 ON  ta_djurnal.id_akun3 = akun3.id_akun3
GROUP BY LEFT(ta_djurnal.id_akun3,'1'), akun1.nama_akun1, LEFT(ta_djurnal.id_akun3,'3'), akun2.nama_akun2, ta_djurnal.id_akun3, akun3.nama_akun3
HAVING LEFT(ta_djurnal.id_akun3,'1')='5'
