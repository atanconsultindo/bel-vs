-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2021 at 05:09 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taxakuwarta`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun1`
--

CREATE TABLE `akun1` (
  `id_akun1` char(1) NOT NULL,
  `nama_akun1` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `akun1`
--

INSERT INTO `akun1` (`id_akun1`, `nama_akun1`) VALUES
('1', 'Aset'),
('2', 'Liabilitas'),
('3', 'Equitas'),
('4', 'Pendapatan'),
('5', 'Beban'),
('6', 'Koreksi Fiskal'),
('7', 'Taksiran PPH');

-- --------------------------------------------------------

--
-- Table structure for table `akun2`
--

CREATE TABLE `akun2` (
  `id_akun1` char(1) NOT NULL,
  `id_akun2` char(3) NOT NULL,
  `nama_akun2` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `akun2`
--

INSERT INTO `akun2` (`id_akun1`, `id_akun2`, `nama_akun2`) VALUES
('1', '110', 'Aset Lancar'),
('1', '120', 'Aset Tidak Lancar'),
('2', '210', 'Liabilitas Jangka Pendek'),
('2', '220', 'Liabilitas Jangka Panjang'),
('3', '310', 'Modal Saham, Modal Dasar'),
('3', '320', 'Tambahan Modal Disetor'),
('3', '330', 'Saham Treasuri'),
('3', '340', 'Selisih Kurs Karena Penjabaran'),
('3', '350', 'Saldo Laba'),
('4', '410', 'Pendapatan Jasa'),
('4', '420', 'Pendapatan Penjualan'),
('4', '430', 'Pendapatan Lain'),
('5', '510', 'Beban Pokok Penjualan'),
('5', '520', 'Beban Operasi'),
('5', '530', 'Beban Lain'),
('6', '610', 'Perbedaan Waktu'),
('6', '620', 'Perbedaan Tetap'),
('6', '630', 'Kompensasi Rugi Pajak'),
('7', '710', 'Taksiran PPH Tahun Berjalan');

-- --------------------------------------------------------

--
-- Table structure for table `akun3`
--

CREATE TABLE `akun3` (
  `id_akun1` char(1) NOT NULL,
  `id_akun2` char(3) NOT NULL,
  `id_akun3` char(5) NOT NULL,
  `nama_akun3` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `akun3`
--

INSERT INTO `akun3` (`id_akun1`, `id_akun2`, `id_akun3`, `nama_akun3`) VALUES
('1', '110', '11010', 'Kas dan Setara Kas'),
('1', '110', '11011', 'Kas Kecil'),
('1', '110', '11012', 'Bank BRI-6306'),
('1', '110', '11013', 'Bank Panin-3939'),
('1', '110', '11014', 'Bank Panin-7199'),
('1', '110', '11020', 'Deposito BRI'),
('1', '110', '11030', 'Piutang Usaha'),
('1', '110', '11040', 'Piutang Lain-lain Pihak Ketiga'),
('1', '110', '11050', 'Persediaan'),
('1', '110', '11060', 'Uang Muka Pembelian'),
('1', '110', '11070', 'Pajak Dibayar Dimuka'),
('1', '110', '11071', 'Uang Muka PPN Masukan'),
('1', '110', '11072', 'Uang Muka PPh Final 4 ayat 2'),
('1', '110', '11073', 'Uang Muka PPH 22'),
('1', '110', '11074', 'Uang Muka PPH 23'),
('1', '110', '11075', 'Uang Muka PPH 25'),
('1', '110', '11080', 'Investasi Pembangunan di BWX'),
('1', '110', '11090', 'Biaya Pendirian PLTM'),
('1', '120', '12010', 'Aset Tetap'),
('1', '120', '12011', 'Peralatan'),
('1', '120', '12012', 'Inventaris Kantor'),
('1', '120', '12013', 'Tanah'),
('1', '120', '12014', 'Bangunan'),
('1', '120', '12020', 'Akumulasi Penyusutan Aset Tetap'),
('1', '120', '12021', 'Akumulasi Penyusutan Aset Tetap- Peralatan'),
('1', '120', '12022', 'Akumulasi Penyusutan Aset Tetap - Inventaris Kantor'),
('1', '120', '12023', 'Akumulasi Penyusutan Aset Tetap - Bangunan'),
('1', '120', '12045', 'Akumulasi Penyusutan'),
('1', '120', '12080', 'Aset Tidak Lancar Lainnya'),
('2', '210', '21010', 'Utang Usaha'),
('2', '210', '21020', 'Utang Lancar Lain'),
('2', '210', '21030', 'Utang Pajak-PPh ps 21'),
('2', '210', '21031', 'Utang Pajak-PPh Ps 23'),
('2', '210', '21032', 'Utang Pajak-PPH Badan'),
('2', '210', '21033', 'Utang Pajak-PPH ps 4 ayat 2'),
('2', '210', '21034', 'Utang Pajak-PPN'),
('2', '210', '21040', 'Beban Akrual'),
('2', '210', '21050', 'Uang Jaminan'),
('2', '210', '21060', 'Liabilitas Imbalan Kerja'),
('2', '210', '21070', 'Liabilitas Jangka Panjang yang Jatuh Tempo'),
('2', '210', '21080', 'Pendapatan Diterima Dimuka'),
('2', '220', '22010', 'Utang Bank'),
('2', '220', '22020', 'Liabilitas Imbalan Kerja'),
('2', '220', '22030', 'Uang Jaminan'),
('2', '220', '22040', 'Utang Kepada Pihak 3'),
('2', '220', '22050', 'Liabilitas Pajak Tangguhan - Bersih'),
('2', '220', '22060', 'Provisi Pengelolaan dan Reklamasi Lingkungan Hidup'),
('2', '220', '22070', 'Liabilitas Jangka Panjang - Setelah Dikurangi Yg Jatuh Tempo'),
('3', '310', '31010', 'Modal Dasar Ditempatkan'),
('3', '320', '32010', 'Tambahan Modal Disetor '),
('3', '330', '33010', 'Saham Treasuri'),
('3', '340', '34010', 'Selisih Kurs Karena Penjabaran Laporan Keuangan'),
('3', '350', '35010', 'Laba Rugi Tahun Lalu'),
('3', '350', '35020', 'Laba Rugi Tahun Berjalan'),
('4', '410', '41010', 'Pendapatan Jasa Konstruksi'),
('4', '410', '41020', 'Pendapatan Jasa Pembiayaan'),
('4', '420', '42010', 'Pendapatan Penjualan'),
('4', '430', '43010', 'Pendapatan Lain'),
('4', '430', '43011', 'Pendapatan Bunga Bank'),
('4', '430', '43012', 'Pendapatan Selisih Bayar'),
('5', '510', '51010', 'Beban Pokok Penjualan'),
('5', '510', '51020', 'Biaya Ditangguhkan- CIP'),
('5', '510', '51030', 'Biaya Ditangguhkan- Pembiayaan'),
('5', '520', '52010', 'Beban Operasi'),
('5', '530', '53020', 'Beban Lain'),
('5', '530', '53021', 'Biaya Admin Bank'),
('5', '530', '53022', 'Biaya Pajak Bunga Bank'),
('5', '530', '53023', 'Biaya Selisih Bayar'),
('6', '610', '61010', 'Perbedaan Antara Piutang dengan Aset Tetap'),
('6', '610', '61020', 'Beban Bunga'),
('6', '620', '62010', 'Biaya Yang Tidak Dapat Dikurangkan'),
('6', '620', '62020', 'Pendapatan yang Dikenakan Pajak Final'),
('6', '620', '62030', 'Selisih Karena Pengukuran Kembali Laporan Keuangan'),
('6', '620', '62040', 'Aset Pajak Tangguhan yang Tidak Dapat Diakui'),
('6', '630', '63010', 'Kompensasi-Rugi Pajak Tahun Berjalan'),
('6', '630', '63020', 'Kompensai-Rugi Pajak '),
('7', '710', '71020', 'Penyesuaian Pajak Tahun Sebelumnya Tangguhan ');

-- --------------------------------------------------------

--
-- Table structure for table `akun3_copy`
--

CREATE TABLE `akun3_copy` (
  `id_akun1` char(1) NOT NULL,
  `id_akun2` char(3) NOT NULL,
  `id_akun3` char(5) NOT NULL,
  `nama_akun3` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `akun3_copy`
--

INSERT INTO `akun3_copy` (`id_akun1`, `id_akun2`, `id_akun3`, `nama_akun3`) VALUES
('1', '110', '11010', 'Kas dan Setara Kas'),
('1', '110', '11020', 'Invenstasi Jangka Pendek'),
('1', '110', '11030', 'Piutang Usaha'),
('1', '110', '11040', 'Piutang Lain-lain Pihak Ketiga'),
('1', '110', '11050', 'Persediaan'),
('1', '110', '11060', 'Pajak Dibayar Dimuka'),
('1', '110', '11070', 'Uang Muka dan Biaya Dibayar Dimuka'),
('1', '120', '', 'Aset Tidak Lancar'),
('1', '120', '12010', 'Uang Muka Investasi'),
('1', '120', '12015', 'Property Investasi'),
('1', '120', '12020', 'Aset Tetap - Setelah Penyusutan'),
('1', '120', '12025', 'Aset Tak Berwujud - Bersih'),
('1', '120', '12030', 'Aset Eksplorasi dan Evaluasi'),
('1', '120', '12035', 'Aset Pajak Tangguhan- Bersih'),
('1', '120', '12040', 'Aset Tambang - Bersih'),
('1', '120', '12045', 'Akumulasi Penyusutan'),
('1', '120', '12050', 'Uang Muka Jangka Panjang'),
('1', '120', '12055', 'Taksiran Tagihan Pajak'),
('1', '120', '12060', 'Aset Dalam Pengerjaan'),
('1', '120', '12065', 'Goodwil'),
('1', '120', '12070', 'Aset Keuangan Jasa Konsesi'),
('1', '120', '12075', 'Bank Garansi'),
('1', '120', '12080', 'Aset Tidak Lancar Lainnya'),
('2', '210', '', 'Liabilitas Jangka Pendek'),
('2', '210', '21010', 'Utang Usaha - Pihak Ketiga'),
('2', '210', '21020', 'Utang Lain-lain - Pihak Ketiga'),
('2', '210', '21030', 'Utang Pajak'),
('2', '210', '21040', 'Beban Akrual'),
('2', '210', '21050', 'Uang Jaminan'),
('2', '210', '21060', 'Liabilitas Imbalan Kerja'),
('2', '210', '21070', 'Liabilitas Jangka Panjang yang Jatuh Tempo'),
('2', '210', '21080', 'Pendapatan Diterima Dimuka'),
('2', '220', '', 'Liabilitas Jangka Panjang'),
('2', '220', '22010', 'Utang Bank'),
('2', '220', '22020', 'Liabilitas Imbalan Kerja'),
('2', '220', '22030', 'Uang Jaminan'),
('2', '220', '22040', 'Utang Kepada Pihak-pihak Berelasi'),
('2', '220', '22050', 'Liabilitas Pajak Tangguhan - Bersih'),
('2', '220', '22060', 'Provisi Pengelolaan dan Reklamasi Lingkungan Hidup'),
('2', '220', '22070', 'Liabilitas Jangka Panjang - Setelah Dikurangi Yg Jatuh Tempo'),
('3', '310', '', 'Modal Saham, Modal Dasar'),
('3', '310', '31010', 'Modal Dasar Ditempatkan'),
('3', '320', '', 'Tambahan Modal Disetor'),
('3', '320', '32010', 'Tambahan Modal Disetor '),
('3', '330', '', 'Saham Treasuri'),
('3', '330', '33010', 'Saham Treasuri'),
('3', '340', '', 'Selisih Kurs Karena Penjabaran Laporan Keuangan'),
('3', '340', '34010', 'Selisih Kurs Karena Penjabaran Laporan Keuangan'),
('3', '350', '', 'Saldo Laba'),
('3', '350', '35010', 'Laba Rugi Tahun Lalu'),
('3', '350', '35020', 'Laba Rugi Tahun Berjalan'),
('4', '410', '', 'Pendapatan Jasa'),
('4', '410', '41010', 'Pendapatan Jasa Konstruksi'),
('4', '410', '41020', 'Pendapatan Jasa Pembiayaan'),
('4', '420', '', 'Pendapatan Penjualan'),
('4', '420', '42010', 'Pendapatan Penjualan'),
('4', '430', '43010', 'Pendapatan Lain'),
('5', '510', '', 'Beban Pokok Penjualan'),
('5', '510', '51010', 'Beban Pokok Penjualan'),
('5', '510', '51020', 'Biaya Ditangguhkan- CIP'),
('5', '510', '51030', 'Biaya Ditangguhkan- Pembiayaan'),
('5', '520', '', 'Beban Operasi'),
('5', '520', '52010', 'Beban Operasi'),
('5', '530', '', 'Beban Lain'),
('5', '530', '53020', 'Beban Lain'),
('6', '610', '61010', 'Perbedaan Antara Piutang dengan Aset Tetap'),
('6', '610', '61020', 'Beban Bunga'),
('6', '620', '62010', 'Biaya Yang Tidak Dapat Dikurangkan'),
('6', '620', '62020', 'Pendapatan yang Dikenakan Pajak Final'),
('6', '620', '62030', 'Selisih Karena Pengukuran Kembali Laporan Keuangan'),
('6', '620', '62040', 'Aset Pajak Tangguhan yang Tidak Dapat Diakui'),
('6', '630', '63010', 'Kompensasi-Rugi Pajak Tahun Berjalan'),
('6', '630', '63020', 'Kompensai-Rugi Pajak '),
('7', '710', '71010', 'Taksiran Pajak Penghasilan Tahun Berjalan'),
('7', '710', '71020', 'Penyesuaian Pajak Tahun Sebelumnya Tangguhan '),
('8', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `r_dfiscor`
--

CREATE TABLE `r_dfiscor` (
  `id_fiscor` tinyint(1) DEFAULT NULL,
  `id_dfiscor` tinyint(2) DEFAULT NULL,
  `nama_dfiscor` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_dfiscor`
--

INSERT INTO `r_dfiscor` (`id_fiscor`, `id_dfiscor`, `nama_dfiscor`) VALUES
(1, 11, 'Beban Penyusutan dan Amortisasi'),
(1, 12, 'Beban Sewa'),
(1, 13, 'Penilaian Persediaan'),
(1, 14, 'Pengapusan Piutang Tak Tertagih'),
(2, 21, 'Penghasilan dari Sumbangan dan Hibah'),
(2, 22, 'Pemberian Natura Kepada Karyawan'),
(2, 23, 'Penghasilan Bunga Deposito'),
(2, 24, 'Penghasilan Yang telah Dikenakan Pajak Final'),
(2, 25, 'Biaya Pajak Penghasilan'),
(2, 26, 'Biaya Sumbangan'),
(2, 27, 'Biaya Sanksi Perpajakan'),
(1, 15, 'Pendapatan Lebih Selisih Kurs'),
(2, 28, 'Test update');

-- --------------------------------------------------------

--
-- Table structure for table `r_djt`
--

CREATE TABLE `r_djt` (
  `id_jt` int(1) NOT NULL,
  `id_djt` int(2) NOT NULL,
  `nama_djt` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_djt`
--

INSERT INTO `r_djt` (`id_jt`, `id_djt`, `nama_djt`) VALUES
(1, 11, 'Jasa CIP-Konstruksi'),
(1, 12, 'Jasa Pembiayaan-Konstruksi'),
(2, 21, 'Fixed Operating and Maintenance'),
(2, 22, 'Energy Payment (Fuel Cost)'),
(2, 23, 'Variable Operating and Maintenance'),
(2, 24, 'Special Facility and Others (Commisioning)'),
(3, 31, 'General Journal'),
(3, 32, 'Adjustment Journal'),
(4, 41, 'Timing Difference'),
(4, 42, 'Permanent Difference'),
(4, 43, 'Timing Difference dan Permanent Difference'),
(4, 44, 'Fiscal Ajdjustment-Tax Expenses '),
(5, 51, 'Opening Balance');

-- --------------------------------------------------------

--
-- Table structure for table `r_hfiscor`
--

CREATE TABLE `r_hfiscor` (
  `id_fiscor` tinyint(1) DEFAULT NULL,
  `nama_fiscor` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_hfiscor`
--

INSERT INTO `r_hfiscor` (`id_fiscor`, `nama_fiscor`) VALUES
(1, 'Timing Difference'),
(2, 'Permanent Difference');

-- --------------------------------------------------------

--
-- Table structure for table `r_hjt`
--

CREATE TABLE `r_hjt` (
  `id_jt` int(1) NOT NULL,
  `nama_jt` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_hjt`
--

INSERT INTO `r_hjt` (`id_jt`, `nama_jt`) VALUES
(1, 'CCR'),
(2, 'OM'),
(3, 'JU'),
(4, 'FA'),
(5, 'OB');

-- --------------------------------------------------------

--
-- Table structure for table `r_perush`
--

CREATE TABLE `r_perush` (
  `nama` varchar(200) NOT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `npwp` varchar(25) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `pimpinan` varchar(100) DEFAULT NULL,
  `tahun` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `r_perush`
--

INSERT INTO `r_perush` (`nama`, `alamat`, `npwp`, `telepon`, `email`, `pimpinan`, `tahun`) VALUES
('PT Wahana Energi Sejehtera', 'Kompleks Pergudangan Margomulyo Jaya Jalan Sentong Asri Blok A No 1, Balongsari, Tandes, Surabaya', '75.385.335.7-604.000', '031-', 'akuntansi@waes.org.id edit', 'Jacob Tedjakusuma', 2020);

-- --------------------------------------------------------

--
-- Table structure for table `ta_ccr`
--

CREATE TABLE `ta_ccr` (
  `no_bukti` char(20) NOT NULL,
  `no_urut` int(2) NOT NULL,
  `tgl_trans` date NOT NULL,
  `id_akun3` char(5) NOT NULL,
  `jc` varchar(100) NOT NULL,
  `debet` double DEFAULT 0,
  `kredit` double DEFAULT 0,
  `keterangan` varchar(200) DEFAULT 'Pembayaran atas kapasitas'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ta_djurnal`
--

CREATE TABLE `ta_djurnal` (
  `no_bukti` char(20) NOT NULL,
  `no_urut` int(2) NOT NULL,
  `id_akun3` char(5) DEFAULT NULL,
  `dk` char(1) DEFAULT NULL,
  `debet` double DEFAULT NULL,
  `kredit` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ta_djurnal`
--

INSERT INTO `ta_djurnal` (`no_bukti`, `no_urut`, `id_akun3`, `dk`, `debet`, `kredit`) VALUES
('GJ-210100001', 1, '11012', 'D', 1996011, 0),
('GJ-210100001', 2, '43011', 'K', 0, 1996011),
('GJ-210100002', 1, '53022', 'D', 399202, 0),
('GJ-210100002', 2, '11012', 'K', 0, 399202),
('GJ-210100004', 1, '11012', 'D', 500, 0),
('GJ-210100004', 2, '43012', 'K', 0, 500),
('GJ-210620000', 1, '11011', 'D', 14140000, 0),
('GJ-210620000', 2, '11012', 'K', 0, 14140000),
('OB-210110000', 1, '11011', 'D', 100, 0),
('OB-210110000', 2, '11012', 'D', 1236915892, 0),
('OB-210110000', 3, '11013', 'D', 10003398, 0),
('OB-210110000', 4, '11014', 'D', 2842941, 0),
('OB-210110000', 5, '11020', 'D', 1045591600, 0),
('OB-210110000', 6, '11040', 'D', 1881465000, 0),
('OB-210110000', 7, '11080', 'D', 2950773648, 0),
('OB-210110000', 8, '11060', 'D', 3418285925, 0),
('OB-210110000', 9, '11090', 'D', 4460672350, 0),
('OB-210110000', 10, '12011', 'D', 29800000, 0),
('OB-210110000', 11, '12012', 'D', 3650000, 0),
('OB-210110000', 12, '22040', 'K', 0, 5694749724),
('OB-210110000', 13, '31010', 'K', 0, 9350000000),
('OB-210110000', 14, '35010', 'K', 0, 1357276),
('OB-210110000', 15, '35020', 'D', 6106146, 0);

--
-- Triggers `ta_djurnal`
--
DELIMITER $$
CREATE TRIGGER `ta_ta_djurnal` AFTER UPDATE ON `ta_djurnal` FOR EACH ROW BEGIN
	INSERT INTO ta_neraca_saldo 
	SET no_bukti = new.no_bukti, akun3 = new.id_akun3, totaldebet = new.debet, totalkredit = new.kredit
	ON DUPLICATE	KEY UPDATE totaldebet	= new.debet, totalkredit = new.kredit;

    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `td_ta_djurnal` AFTER DELETE ON `ta_djurnal` FOR EACH ROW BEGIN
	UPDATE ta_neraca_saldo
	SET totaldebet	= totaldebet-old.debet, totalkredit = totalkredit-old.kredit
	WHERE no_bukti	= old.no_bukti; 
	

    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `ti_ta_djurnal` AFTER INSERT ON `ta_djurnal` FOR EACH ROW BEGIN
	INSERT INTO ta_neraca_saldo 
	SET no_bukti = new.no_bukti, akun3 = new.id_akun3, totaldebet	= new.debet, totalkredit = new.kredit
	ON DUPLICATE	KEY UPDATE totaldebet	= totaldebet+new.debet, totalkredit = totalkredit+new.kredit;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ta_fiscor`
--

CREATE TABLE `ta_fiscor` (
  `no` bigint(3) NOT NULL,
  `id_dfiscor` int(2) NOT NULL,
  `pn` varchar(1) DEFAULT 'p',
  `nilai` double DEFAULT NULL,
  `ket` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ta_hjurnal`
--

CREATE TABLE `ta_hjurnal` (
  `no_bukti` char(20) NOT NULL,
  `periode` int(4) DEFAULT NULL,
  `tgl_trans` date DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `id_djt` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ta_hjurnal`
--

INSERT INTO `ta_hjurnal` (`no_bukti`, `periode`, `tgl_trans`, `keterangan`, `status`, `id_djt`) VALUES
('GJ-210100001', 2020, '2021-01-25', 'Pendapatan Bunga BRI - Januari 2021', 'UnPosted', 31),
('GJ-210100002', 2020, '2021-01-25', 'Beban Pajak Bunga Bank BRI - Januari 2021', 'UnPosted', 31),
('GJ-210100004', 2020, '2021-06-01', 'PEMBULATAN BRI - JANUARI 2021', 'UnPosted', 31),
('GJ-210620000', 2020, '2021-01-27', 'DROPING DANA DARI BRI KE KAS KECIL', 'UnPosted', 31),
('OB-210110000', 2020, '2021-01-01', 'Saldo Awal Per 1 Januari 2021', 'UnPosted', 51);

-- --------------------------------------------------------

--
-- Table structure for table `ta_lak`
--

CREATE TABLE `ta_lak` (
  `no_bukti` char(20) NOT NULL,
  `no_urut` int(2) NOT NULL,
  `id_akun3` char(5) DEFAULT NULL,
  `dk` char(1) DEFAULT NULL,
  `debet` double DEFAULT NULL,
  `kredit` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ta_neraca_saldo`
--

CREATE TABLE `ta_neraca_saldo` (
  `no_bukti` char(20) NOT NULL,
  `periode` char(6) NOT NULL,
  `akun3` char(5) NOT NULL,
  `totaldebet` double DEFAULT NULL,
  `totalkredit` double DEFAULT NULL,
  `saldodebet` double DEFAULT NULL,
  `saldokredit` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ta_neraca_saldo`
--

INSERT INTO `ta_neraca_saldo` (`no_bukti`, `periode`, `akun3`, `totaldebet`, `totalkredit`, `saldodebet`, `saldokredit`) VALUES
('CC-201206000', '', '12070', 0, -10000000, NULL, NULL),
('CC-201206000', '', '41010', -10000000, 0, NULL, NULL),
('FA-201206000', '', '62010', 0, 0, NULL, NULL),
('FA-201213000', '', '21030', -4000000, 0, NULL, NULL),
('FA-201213000', '', '71010', 0, -4000000, NULL, NULL),
('GJ-201206000', '', '11030', 0, -30000000, NULL, NULL),
('GJ-201206000', '', '42010', -30000000, 0, NULL, NULL),
('GJ-210100001', '', '11012', 1996011, -3992022, NULL, NULL),
('GJ-210100001', '', '43010', -1996011, -1996011, NULL, NULL),
('GJ-210100001', '', '43011', -1996011, 1996011, NULL, NULL),
('GJ-210100002', '', '11012', 0, 399202, NULL, NULL),
('GJ-210100002', '', '53022', 399202, 0, NULL, NULL),
('GJ-210100004', '', '11012', 500, 0, NULL, NULL),
('GJ-210100004', '', '43012', 0, 500, NULL, NULL),
('GJ-210620000', '', '11011', 14140000, 0, NULL, NULL),
('GJ-210620000', '', '11012', 0, 14140000, NULL, NULL),
('OB-201206000', '', '11010', -1275695259, -45816600, NULL, NULL),
('OB-201206000', '', '11020', -38779467, -45816600, NULL, NULL),
('OB-201206000', '', '11030', -1267584707, -45816600, NULL, NULL),
('OB-201206000', '', '11060', -1261268872, -45816600, NULL, NULL),
('OB-201206000', '', '12020', -1259453131, -45816600, NULL, NULL),
('OB-201206000', '', '21010', -1275695359, -38336120, NULL, NULL),
('OB-201206000', '', '21050', -1275695359, -41723680, NULL, NULL),
('OB-201206000', '', '31010', -1275695359, -21777417, NULL, NULL),
('OB-201206000', '', '35010', -1275695359, -35612583, NULL, NULL),
('OB-210110000', '', '11011', 100, 0, NULL, NULL),
('OB-210110000', '', '11012', 1236915892, 0, NULL, NULL),
('OB-210110000', '', '11013', 10003398, 0, NULL, NULL),
('OB-210110000', '', '11014', 2842941, 0, NULL, NULL),
('OB-210110000', '', '11020', 1045591600, 0, NULL, NULL),
('OB-210110000', '', '11040', 1881465000, 0, NULL, NULL),
('OB-210110000', '', '11060', 3418285925, 0, NULL, NULL),
('OB-210110000', '', '11080', 2950773648, 0, NULL, NULL),
('OB-210110000', '', '11090', 4460672350, 0, NULL, NULL),
('OB-210110000', '', '12011', 29800000, 0, NULL, NULL),
('OB-210110000', '', '12012', 3650000, 0, NULL, NULL),
('OB-210110000', '', '22040', 0, 5694749724, NULL, NULL),
('OB-210110000', '', '31010', 0, 9350000000, NULL, NULL),
('OB-210110000', '', '35010', 0, 1357276, NULL, NULL),
('OB-210110000', '', '35020', 6106146, 0, NULL, NULL),
('OB-210620000', '', '11011', -1236915892, 0, NULL, NULL),
('OB-210620000', '', '11012', -100, 0, NULL, NULL),
('OM-201206000', '', '11010', -20000000, 0, NULL, NULL),
('OM-201206000', '', '51020', 0, -20000000, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ta_om`
--

CREATE TABLE `ta_om` (
  `no_bukti` char(20) NOT NULL,
  `no_urut` int(2) NOT NULL,
  `tgl_trans` date NOT NULL,
  `id_akun3` char(5) NOT NULL,
  `jom` varchar(100) NOT NULL,
  `debet` double DEFAULT 0,
  `kredit` double DEFAULT 0,
  `keterangan` varchar(200) DEFAULT 'Pembayaran atas OM'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ta_periode`
--

CREATE TABLE `ta_periode` (
  `periode` char(6) DEFAULT NULL,
  `dari_tgl` date DEFAULT NULL,
  `sampai_tgl` date DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ta_periode`
--

INSERT INTO `ta_periode` (`periode`, `dari_tgl`, `sampai_tgl`, `status`) VALUES
('202011', '2020-11-01', '2020-11-30', 'posted');

-- --------------------------------------------------------

--
-- Table structure for table `ta_saldo_awal`
--

CREATE TABLE `ta_saldo_awal` (
  `periode` year(4) NOT NULL,
  `rek4` char(10) NOT NULL,
  `debet` double NOT NULL,
  `kredit` double NOT NULL,
  `tgl_insert` datetime NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `iduser` bigint(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama_unit` varchar(100) NOT NULL DEFAULT 'Acccounting',
  `level` varchar(100) NOT NULL,
  `foto` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`iduser`, `username`, `password`, `nama_unit`, `level`, `foto`) VALUES
(1, '1', '•', 'Accounting', '·ÙÔÉÖ ¥ÈÑÍÒ', NULL),
(2, 'admin', 'ÅÈÑÍÒ', 'Marketing', '¹×ÉÖ', NULL),
(3, 'User', 'Ù×ÉÖ', 'Tax', '¹×ÉÖ', NULL),
(4, 'Tamu', 'ØÅÑÙ', 'Tamu', '¸ÅÑÙ', NULL),
(5, 'Super', '×ÙÔÉÖ', 'Head', '·ÙÔÉÖ ¥ÈÑÍÒ', NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_rptlr`
-- (See below for the actual view)
--
CREATE TABLE `v_rptlr` (
`akun1` varchar(1)
,`nama_akun1` varchar(100)
,`akun2` varchar(3)
,`nama_akun2` varchar(100)
,`id_akun3` char(5)
,`nama_akun3` varchar(100)
,`SumNilai` double
);

-- --------------------------------------------------------

--
-- Structure for view `v_rptlr`
--
DROP TABLE IF EXISTS `v_rptlr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_rptlr`  AS  select left(`ta_djurnal`.`id_akun3`,'1') AS `akun1`,`akun1`.`nama_akun1` AS `nama_akun1`,left(`ta_djurnal`.`id_akun3`,'3') AS `akun2`,`akun2`.`nama_akun2` AS `nama_akun2`,`ta_djurnal`.`id_akun3` AS `id_akun3`,`akun3`.`nama_akun3` AS `nama_akun3`,sum(`ta_djurnal`.`kredit`) - sum(`ta_djurnal`.`debet`) AS `SumNilai` from (((`ta_djurnal` left join `akun1` on(left(`ta_djurnal`.`id_akun3`,'1') = `akun1`.`id_akun1`)) left join `akun2` on(left(`ta_djurnal`.`id_akun3`,'3') = `akun2`.`id_akun2`)) left join `akun3` on(`ta_djurnal`.`id_akun3` = `akun3`.`id_akun3`)) group by left(`ta_djurnal`.`id_akun3`,'1'),`akun1`.`nama_akun1`,left(`ta_djurnal`.`id_akun3`,'3'),`akun2`.`nama_akun2`,`ta_djurnal`.`id_akun3`,`akun3`.`nama_akun3` having left(`ta_djurnal`.`id_akun3`,'1') = '4' union select left(`ta_djurnal`.`id_akun3`,'1') AS `akun1`,`akun1`.`nama_akun1` AS `nama_akun1`,left(`ta_djurnal`.`id_akun3`,'3') AS `akun2`,`akun2`.`nama_akun2` AS `nama_akun2`,`ta_djurnal`.`id_akun3` AS `id_akun3`,`akun3`.`nama_akun3` AS `nama_akun3`,sum(`ta_djurnal`.`kredit`) - sum(`ta_djurnal`.`debet`) AS `SumNilai` from (((`ta_djurnal` left join `akun1` on(left(`ta_djurnal`.`id_akun3`,'1') = `akun1`.`id_akun1`)) left join `akun2` on(left(`ta_djurnal`.`id_akun3`,'3') = `akun2`.`id_akun2`)) left join `akun3` on(`ta_djurnal`.`id_akun3` = `akun3`.`id_akun3`)) group by left(`ta_djurnal`.`id_akun3`,'1'),`akun1`.`nama_akun1`,left(`ta_djurnal`.`id_akun3`,'3'),`akun2`.`nama_akun2`,`ta_djurnal`.`id_akun3`,`akun3`.`nama_akun3` having left(`ta_djurnal`.`id_akun3`,'1') = '5' ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun1`
--
ALTER TABLE `akun1`
  ADD PRIMARY KEY (`id_akun1`);

--
-- Indexes for table `akun2`
--
ALTER TABLE `akun2`
  ADD PRIMARY KEY (`id_akun1`,`id_akun2`);

--
-- Indexes for table `akun3`
--
ALTER TABLE `akun3`
  ADD PRIMARY KEY (`id_akun1`,`id_akun2`,`id_akun3`);

--
-- Indexes for table `akun3_copy`
--
ALTER TABLE `akun3_copy`
  ADD PRIMARY KEY (`id_akun1`,`id_akun2`,`id_akun3`);

--
-- Indexes for table `r_djt`
--
ALTER TABLE `r_djt`
  ADD PRIMARY KEY (`id_jt`,`id_djt`);

--
-- Indexes for table `r_hjt`
--
ALTER TABLE `r_hjt`
  ADD PRIMARY KEY (`id_jt`);

--
-- Indexes for table `ta_ccr`
--
ALTER TABLE `ta_ccr`
  ADD PRIMARY KEY (`no_bukti`,`no_urut`);

--
-- Indexes for table `ta_djurnal`
--
ALTER TABLE `ta_djurnal`
  ADD PRIMARY KEY (`no_bukti`,`no_urut`);

--
-- Indexes for table `ta_fiscor`
--
ALTER TABLE `ta_fiscor`
  ADD PRIMARY KEY (`no`,`id_dfiscor`);

--
-- Indexes for table `ta_hjurnal`
--
ALTER TABLE `ta_hjurnal`
  ADD PRIMARY KEY (`no_bukti`);

--
-- Indexes for table `ta_lak`
--
ALTER TABLE `ta_lak`
  ADD PRIMARY KEY (`no_bukti`,`no_urut`);

--
-- Indexes for table `ta_neraca_saldo`
--
ALTER TABLE `ta_neraca_saldo`
  ADD PRIMARY KEY (`no_bukti`,`periode`,`akun3`);

--
-- Indexes for table `ta_om`
--
ALTER TABLE `ta_om`
  ADD PRIMARY KEY (`no_bukti`,`no_urut`);

--
-- Indexes for table `ta_saldo_awal`
--
ALTER TABLE `ta_saldo_awal`
  ADD PRIMARY KEY (`periode`,`rek4`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`iduser`,`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ta_fiscor`
--
ALTER TABLE `ta_fiscor`
  MODIFY `no` bigint(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `iduser` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
