SELECT 'Laba' AS id_akun3, 'Laba/(Rugi) Periode Berjalan' AS nama_akun3 , SUM((ta_djurnal.`kredit`)-(ta_djurnal.Debet)) AS Nilai, 0 AS NilaiAwal, '350'  AS Rek2,  'Laba/(Rugi) Periode Berjalan' AS Uraian2, '3' AS Rek1, 'Ekuitas' AS nama_akun1, '60' AS id_jt
  FROM ta_djurnal
WHERE (((ta_djurnal.`id_akun3`) LIKE '4%' OR (ta_djurnal.`id_akun3`) LIKE '5%'));

