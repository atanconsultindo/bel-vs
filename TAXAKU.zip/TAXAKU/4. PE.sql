SELECT '1' AS Kode, 'Saldo Awal Ekuitas' AS EkuitasUraian, ta_djurnal.`id_akun3`, akun3.`nama_akun3`, SUM(ta_djurnal.Kredit) - SUM(ta_djurnal.Debet) AS Nilai, ta_hjurnal.`id_djt`
FROM ta_djurnal 
LEFT JOIN akun3 ON ta_djurnal.`id_akun3` = akun3.`id_akun3`
LEFT JOIN ta_hjurnal ON ta_djurnal.`no_bukti` = ta_hjurnal.`no_bukti`	
GROUP BY '1', 'Ekuitas Awal', ta_djurnal.`id_akun3`
HAVING (((ta_djurnal.`id_akun3`) LIKE '3%') AND ((ta_hjurnal.`id_djt`)='51'))

UNION
SELECT '1' AS Kode, 'Saldo Awal Ekuitas' AS EkuitasUraian, ta_djurnal.`id_akun3`, akun3.`nama_akun3`, SUM(ta_djurnal.Kredit) - SUM(ta_djurnal.Debet) AS Nilai, ta_hjurnal.`id_djt`
FROM ta_djurnal 
LEFT JOIN akun3 ON ta_djurnal.`id_akun3` = akun3.`id_akun3`
LEFT JOIN ta_hjurnal ON ta_djurnal.`no_bukti` = ta_hjurnal.`no_bukti`	
GROUP BY '1', 'Ekuitas Awal', ta_djurnal.`id_akun3`
HAVING (((ta_djurnal.`id_akun3`) LIKE '3%') AND ((ta_hjurnal.`id_djt`)='51'))

UNION
SELECT '3' AS Kode, 'Laba (Rugi) Berjalan ' AS EkuitasUraian, '35020' AS KodeRek, 'Laba (Rugi) Periode Berjalan' AS Uraian, SUM(ta_djurnal.`kredit`-ta_djurnal.`debet`) AS Nilai, ta_hjurnal.`id_djt`
FROM ta_djurnal
LEFT JOIN ta_hjurnal ON ta_djurnal.`no_bukti` = ta_hjurnal.`no_bukti`
WHERE LEFT(ta_djurnal.`id_akun3`,'1')='4' OR LEFT(ta_djurnal.`id_akun3`,'1')= '5'

