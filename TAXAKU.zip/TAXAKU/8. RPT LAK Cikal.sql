SELECT DISTINCT * FROM 
(SELECT DISTINCT ta_djurnal.`no_bukti`, ta_djurnal.`no_urut`, ta_djurnal.`id_akun3`, akun3.`nama_akun3`, ta_djurnal.`debet`, ta_djurnal.`kredit`  FROM ta_djurnal
LEFT JOIN akun3 ON ta_djurnal.`id_akun3`= akun3.`id_akun3`) AS X
 INNER JOIN
(  
SELECT DISTINCT no_bukti FROM ta_djurnal WHERE ta_djurnal.`id_akun3` = '11010')
AS Y ON X.`no_bukti` = Y.no_bukti WHERE x.id_akun3 <> '11010'

 
