SELECT ta_djurnal.`id_akun3`, akun3.`nama_akun3`, ta_djurnal.`no_bukti`, ta_hjurnal.`tgl_trans`, ta_djurnal.Debet, ta_djurnal.Kredit
FROM ta_djurnal 
LEFT JOIN akun3 ON ta_djurnal.`id_akun3` = akun3.`id_akun3`
LEFT JOIN ta_hjurnal ON ta_djurnal.`no_bukti` = ta_hjurnal.`no_bukti`
ORDER BY ta_djurnal.`id_akun3`, ta_hjurnal.`tgl_trans` ;