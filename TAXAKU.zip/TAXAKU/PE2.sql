SELECT '2' AS Kode, 'Tambahan Modal' AS EkuitasUraian, ta_djurnal.`id_akun3`, akun3.`nama_akun3`, IF(ISNULL(SUM(ta_djurnal.`kredit`)-SUM(ta_djurnal.`debet`)),0,SUM(ta_djurnal.`kredit`)-SUM(ta_djurnal.`debet`)) AS Nilai, ta_hjurnal.`id_djt`
FROM ta_djurnal
LEFT JOIN akun3 ON ta_djurnal.`id_akun3` = akun3.`id_akun3`
LEFT JOIN ta_hjurnal ON ta_djurnal.`no_bukti` = ta_hjurnal.`no_bukti`
GROUP BY Kode, EkuitasUraian, ta_djurnal.`id_akun3`
HAVING ((ta_djurnal.`id_akun3`) LIKE '3%') AND ((ta_hjurnal.`id_djt`) <> '51');

