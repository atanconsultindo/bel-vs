SELECT ta_djurnal.id_akun3, akun3.`nama_akun3`, 0 AS Nilai, IF(ta_djurnal.`id_akun3` LIKE '1%',SUM(ta_djurnal.Debet)-SUM(ta_djurnal.Kredit),SUM(ta_djurnal.kredit)-SUM(ta_djurnal.Debet)) AS NilaiAwal, LEFT(ta_djurnal.`id_akun3`,'3') AS id_akun2, akun2.`nama_akun2`,  LEFT(ta_djurnal.`id_akun3`,'1') AS id_akun1,  akun1.`nama_akun1`, ta_hjurnal.`id_djt`
FROM ta_djurnal
LEFT JOIN akun3 ON ta_djurnal.`id_akun3` = akun3.`id_akun3` 
LEFT JOIN akun2 ON LEFT(ta_djurnal.`id_akun3`,'3') = akun2.`id_akun2` 
LEFT JOIN akun1 ON LEFT(ta_djurnal.`id_akun3`,'1') = akun1.`id_akun1`
LEFT JOIN ta_hjurnal ON ta_djurnal.`no_bukti` = ta_hjurnal.`no_bukti`
WHERE (ta_djurnal.`id_akun3` LIKE '1%' OR  ta_djurnal.`id_akun3` LIKE '2%' OR  ta_djurnal.`id_akun3` LIKE'3%') AND ta_hjurnal.`id_djt` = '51'
GROUP BY ta_djurnal.id_akun3
