SELECT '88888' AS id_akun3, 'Total Kewajiban dan Ekuitas' AS nama_akun3, SUM(ta_djurnal.`kredit`)-SUM( ta_djurnal.`debet`) AS Nilai, 0 AS NilaiAwal,  '888' AS id_akun2, 'Kewajiban' AS nama_akun2,  '8' AS id_akun1, 'Kewajiban' AS nama_akun1, '80' AS id_jt
FROM ta_djurnal
WHERE (((LEFT(ta_djurnal.`id_akun3`,'1')) BETWEEN '2' AND '5'));
