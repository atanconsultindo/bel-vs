﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PanelSlide = New System.Windows.Forms.Panel()
        Me.PanelUser = New System.Windows.Forms.Panel()
        Me.PanelHeaderSlide = New System.Windows.Forms.Panel()
        Me.PanelMainHeader = New System.Windows.Forms.Panel()
        Me.LblRun = New System.Windows.Forms.Label()
        Me.PanelMain = New System.Windows.Forms.Panel()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusDriver = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusDb = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TimerRun = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BtnRegistrasi = New System.Windows.Forms.Button()
        Me.BtnRef = New System.Windows.Forms.Button()
        Me.BtnReport = New System.Windows.Forms.Button()
        Me.BtnSawal = New System.Windows.Forms.Button()
        Me.BtnTax = New System.Windows.Forms.Button()
        Me.BtnUser = New System.Windows.Forms.Button()
        Me.BtnSliding = New System.Windows.Forms.Button()
        Me.BtnJurnal = New System.Windows.Forms.Button()
        Me.BtnLogout = New System.Windows.Forms.Button()
        Me.BtnFOM = New System.Windows.Forms.Button()
        Me.BtnCCR = New System.Windows.Forms.Button()
        Me.PanelSlide.SuspendLayout()
        Me.PanelUser.SuspendLayout()
        Me.PanelHeaderSlide.SuspendLayout()
        Me.PanelMainHeader.SuspendLayout()
        Me.PanelMain.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelSlide
        '
        Me.PanelSlide.BackColor = System.Drawing.Color.Navy
        Me.PanelSlide.Controls.Add(Me.BtnRef)
        Me.PanelSlide.Controls.Add(Me.BtnReport)
        Me.PanelSlide.Controls.Add(Me.BtnSawal)
        Me.PanelSlide.Controls.Add(Me.BtnTax)
        Me.PanelSlide.Controls.Add(Me.PanelUser)
        Me.PanelSlide.Controls.Add(Me.PanelHeaderSlide)
        Me.PanelSlide.Controls.Add(Me.BtnJurnal)
        Me.PanelSlide.Controls.Add(Me.BtnLogout)
        Me.PanelSlide.Controls.Add(Me.BtnFOM)
        Me.PanelSlide.Controls.Add(Me.BtnCCR)
        Me.PanelSlide.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelSlide.Location = New System.Drawing.Point(0, 0)
        Me.PanelSlide.Name = "PanelSlide"
        Me.PanelSlide.Size = New System.Drawing.Size(200, 568)
        Me.PanelSlide.TabIndex = 1
        '
        'PanelUser
        '
        Me.PanelUser.Controls.Add(Me.BtnUser)
        Me.PanelUser.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelUser.Location = New System.Drawing.Point(0, 37)
        Me.PanelUser.Name = "PanelUser"
        Me.PanelUser.Size = New System.Drawing.Size(200, 52)
        Me.PanelUser.TabIndex = 9
        '
        'PanelHeaderSlide
        '
        Me.PanelHeaderSlide.BackColor = System.Drawing.Color.DarkOrange
        Me.PanelHeaderSlide.Controls.Add(Me.BtnSliding)
        Me.PanelHeaderSlide.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelHeaderSlide.ForeColor = System.Drawing.Color.White
        Me.PanelHeaderSlide.Location = New System.Drawing.Point(0, 0)
        Me.PanelHeaderSlide.Name = "PanelHeaderSlide"
        Me.PanelHeaderSlide.Size = New System.Drawing.Size(200, 37)
        Me.PanelHeaderSlide.TabIndex = 8
        '
        'PanelMainHeader
        '
        Me.PanelMainHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.PanelMainHeader.Controls.Add(Me.LblRun)
        Me.PanelMainHeader.Controls.Add(Me.BtnRegistrasi)
        Me.PanelMainHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelMainHeader.Location = New System.Drawing.Point(200, 0)
        Me.PanelMainHeader.Name = "PanelMainHeader"
        Me.PanelMainHeader.Size = New System.Drawing.Size(700, 37)
        Me.PanelMainHeader.TabIndex = 2
        '
        'LblRun
        '
        Me.LblRun.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LblRun.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblRun.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRun.Location = New System.Drawing.Point(0, 0)
        Me.LblRun.Name = "LblRun"
        Me.LblRun.Size = New System.Drawing.Size(600, 37)
        Me.LblRun.TabIndex = 14
        Me.LblRun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelMain
        '
        Me.PanelMain.Controls.Add(Me.PictureBox1)
        Me.PanelMain.Controls.Add(Me.StatusStrip1)
        Me.PanelMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelMain.Location = New System.Drawing.Point(200, 37)
        Me.PanelMain.Name = "PanelMain"
        Me.PanelMain.Size = New System.Drawing.Size(700, 531)
        Me.PanelMain.TabIndex = 4
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusDriver, Me.ToolStripStatusLabel2, Me.ToolStripStatusDb})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 509)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(700, 22)
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "Driver:"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.AutoSize = False
        Me.ToolStripStatusLabel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(41, 17)
        Me.ToolStripStatusLabel1.Text = "Driver:"
        '
        'ToolStripStatusDriver
        '
        Me.ToolStripStatusDriver.AutoSize = False
        Me.ToolStripStatusDriver.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Italic)
        Me.ToolStripStatusDriver.Name = "ToolStripStatusDriver"
        Me.ToolStripStatusDriver.Size = New System.Drawing.Size(200, 17)
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ToolStripStatusLabel2.ForeColor = System.Drawing.SystemColors.Control
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(58, 17)
        Me.ToolStripStatusLabel2.Text = "Database:"
        '
        'ToolStripStatusDb
        '
        Me.ToolStripStatusDb.AutoSize = False
        Me.ToolStripStatusDb.Name = "ToolStripStatusDb"
        Me.ToolStripStatusDb.Size = New System.Drawing.Size(100, 17)
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'TimerRun
        '
        Me.TimerRun.Interval = 500
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = Global.E_TaxAku.My.Resources.Resources.BGPTWES_01
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(700, 509)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'BtnRegistrasi
        '
        Me.BtnRegistrasi.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnRegistrasi.Dock = System.Windows.Forms.DockStyle.Right
        Me.BtnRegistrasi.FlatAppearance.BorderSize = 0
        Me.BtnRegistrasi.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRegistrasi.Image = Global.E_TaxAku.My.Resources.Resources.Actions_list_add_user_icon
        Me.BtnRegistrasi.Location = New System.Drawing.Point(600, 0)
        Me.BtnRegistrasi.Name = "BtnRegistrasi"
        Me.BtnRegistrasi.Size = New System.Drawing.Size(100, 37)
        Me.BtnRegistrasi.TabIndex = 1
        Me.BtnRegistrasi.Text = "User"
        Me.BtnRegistrasi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnRegistrasi.UseVisualStyleBackColor = True
        '
        'BtnRef
        '
        Me.BtnRef.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnRef.FlatAppearance.BorderSize = 0
        Me.BtnRef.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRef.ForeColor = System.Drawing.Color.White
        Me.BtnRef.Image = Global.E_TaxAku.My.Resources.Resources.table_add_icon
        Me.BtnRef.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnRef.Location = New System.Drawing.Point(0, 473)
        Me.BtnRef.Name = "BtnRef"
        Me.BtnRef.Size = New System.Drawing.Size(193, 45)
        Me.BtnRef.TabIndex = 13
        Me.BtnRef.Text = "Referensi"
        Me.BtnRef.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnRef.UseVisualStyleBackColor = True
        '
        'BtnReport
        '
        Me.BtnReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnReport.FlatAppearance.BorderSize = 0
        Me.BtnReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnReport.ForeColor = System.Drawing.Color.White
        Me.BtnReport.Image = Global.E_TaxAku.My.Resources.Resources.Books_1_icon
        Me.BtnReport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnReport.Location = New System.Drawing.Point(0, 407)
        Me.BtnReport.Name = "BtnReport"
        Me.BtnReport.Size = New System.Drawing.Size(193, 45)
        Me.BtnReport.TabIndex = 12
        Me.BtnReport.Text = "Pelaporan"
        Me.BtnReport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnReport.UseVisualStyleBackColor = True
        '
        'BtnSawal
        '
        Me.BtnSawal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSawal.FlatAppearance.BorderSize = 0
        Me.BtnSawal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSawal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSawal.ForeColor = System.Drawing.Color.White
        Me.BtnSawal.Image = Global.E_TaxAku.My.Resources.Resources.Wall_Clock____Time_Machine
        Me.BtnSawal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnSawal.Location = New System.Drawing.Point(0, 102)
        Me.BtnSawal.Name = "BtnSawal"
        Me.BtnSawal.Size = New System.Drawing.Size(193, 45)
        Me.BtnSawal.TabIndex = 11
        Me.BtnSawal.Text = "Saldo Awal"
        Me.BtnSawal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnSawal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnSawal.UseVisualStyleBackColor = True
        '
        'BtnTax
        '
        Me.BtnTax.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnTax.FlatAppearance.BorderSize = 0
        Me.BtnTax.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTax.ForeColor = System.Drawing.Color.White
        Me.BtnTax.Image = Global.E_TaxAku.My.Resources.Resources.Money_icon1
        Me.BtnTax.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnTax.Location = New System.Drawing.Point(0, 346)
        Me.BtnTax.Name = "BtnTax"
        Me.BtnTax.Size = New System.Drawing.Size(193, 45)
        Me.BtnTax.TabIndex = 10
        Me.BtnTax.Text = "Penyesuaian Fiskal"
        Me.BtnTax.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnTax.UseVisualStyleBackColor = True
        '
        'BtnUser
        '
        Me.BtnUser.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnUser.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnUser.FlatAppearance.BorderSize = 0
        Me.BtnUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnUser.Image = Global.E_TaxAku.My.Resources.Resources.user_group_icon11
        Me.BtnUser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnUser.Location = New System.Drawing.Point(0, 0)
        Me.BtnUser.Name = "BtnUser"
        Me.BtnUser.Size = New System.Drawing.Size(200, 45)
        Me.BtnUser.TabIndex = 0
        Me.BtnUser.Text = "     User Login"
        Me.BtnUser.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnUser.UseVisualStyleBackColor = True
        '
        'BtnSliding
        '
        Me.BtnSliding.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSliding.Dock = System.Windows.Forms.DockStyle.Right
        Me.BtnSliding.FlatAppearance.BorderSize = 0
        Me.BtnSliding.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSliding.Image = Global.E_TaxAku.My.Resources.Resources.UI____Appearance
        Me.BtnSliding.Location = New System.Drawing.Point(160, 0)
        Me.BtnSliding.Name = "BtnSliding"
        Me.BtnSliding.Size = New System.Drawing.Size(40, 37)
        Me.BtnSliding.TabIndex = 0
        Me.BtnSliding.UseVisualStyleBackColor = True
        '
        'BtnJurnal
        '
        Me.BtnJurnal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnJurnal.FlatAppearance.BorderSize = 0
        Me.BtnJurnal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnJurnal.ForeColor = System.Drawing.Color.White
        Me.BtnJurnal.Image = Global.E_TaxAku.My.Resources.Resources.Books_icon1
        Me.BtnJurnal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnJurnal.Location = New System.Drawing.Point(0, 285)
        Me.BtnJurnal.Name = "BtnJurnal"
        Me.BtnJurnal.Size = New System.Drawing.Size(193, 45)
        Me.BtnJurnal.TabIndex = 7
        Me.BtnJurnal.Text = "Jurnal Umum dan Penyesuaian"
        Me.BtnJurnal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnJurnal.UseVisualStyleBackColor = True
        '
        'BtnLogout
        '
        Me.BtnLogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnLogout.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BtnLogout.FlatAppearance.BorderSize = 0
        Me.BtnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnLogout.ForeColor = System.Drawing.Color.White
        Me.BtnLogout.Image = Global.E_TaxAku.My.Resources.Resources.onebit_62
        Me.BtnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnLogout.Location = New System.Drawing.Point(0, 523)
        Me.BtnLogout.Name = "BtnLogout"
        Me.BtnLogout.Size = New System.Drawing.Size(200, 45)
        Me.BtnLogout.TabIndex = 5
        Me.BtnLogout.Text = "   Log Out"
        Me.BtnLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnLogout.UseVisualStyleBackColor = True
        '
        'BtnFOM
        '
        Me.BtnFOM.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnFOM.FlatAppearance.BorderSize = 0
        Me.BtnFOM.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFOM.ForeColor = System.Drawing.Color.White
        Me.BtnFOM.Image = Global.E_TaxAku.My.Resources.Resources.Invoice_icon
        Me.BtnFOM.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnFOM.Location = New System.Drawing.Point(0, 224)
        Me.BtnFOM.Name = "BtnFOM"
        Me.BtnFOM.Size = New System.Drawing.Size(193, 45)
        Me.BtnFOM.TabIndex = 2
        Me.BtnFOM.Text = "Operasi and Pemeliharaan"
        Me.BtnFOM.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnFOM.UseVisualStyleBackColor = True
        '
        'BtnCCR
        '
        Me.BtnCCR.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnCCR.FlatAppearance.BorderSize = 0
        Me.BtnCCR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCCR.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCCR.ForeColor = System.Drawing.Color.White
        Me.BtnCCR.Image = Global.E_TaxAku.My.Resources.Resources.onebit_54
        Me.BtnCCR.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnCCR.Location = New System.Drawing.Point(0, 163)
        Me.BtnCCR.Name = "BtnCCR"
        Me.BtnCCR.Size = New System.Drawing.Size(193, 45)
        Me.BtnCCR.TabIndex = 1
        Me.BtnCCR.Text = "Kapasitas Power"
        Me.BtnCCR.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnCCR.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnCCR.UseVisualStyleBackColor = True
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(900, 568)
        Me.Controls.Add(Me.PanelMain)
        Me.Controls.Add(Me.PanelMainHeader)
        Me.Controls.Add(Me.PanelSlide)
        Me.ForeColor = System.Drawing.SystemColors.Control
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.IsMdiContainer = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmMain"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SISTEM AKUNTANSI IPP"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.PanelSlide.ResumeLayout(False)
        Me.PanelUser.ResumeLayout(False)
        Me.PanelHeaderSlide.ResumeLayout(False)
        Me.PanelMainHeader.ResumeLayout(False)
        Me.PanelMain.ResumeLayout(False)
        Me.PanelMain.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelSlide As Panel
    Friend WithEvents PanelMainHeader As Panel
    Friend WithEvents BtnFOM As Button
    Friend WithEvents BtnCCR As Button
    Friend WithEvents BtnLogout As Button
    Friend WithEvents PanelMain As Panel
    Friend WithEvents BtnJurnal As Button
    Friend WithEvents PanelHeaderSlide As Panel
    Friend WithEvents BtnSliding As Button
    Friend WithEvents PanelUser As Panel
    Friend WithEvents BtnUser As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusDriver As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusDb As ToolStripStatusLabel
    Friend WithEvents BtnRegistrasi As Button
    Friend WithEvents BtnTax As Button
    Friend WithEvents LblRun As Label
    Friend WithEvents TimerRun As Timer
    Friend WithEvents BtnSawal As Button
    Friend WithEvents BtnReport As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents BtnRef As Button
End Class
