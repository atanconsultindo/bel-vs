﻿Public Class FrmRef
    Private Sub cmdKeluar_Click(sender As Object, e As EventArgs) Handles cmdKeluar.Click
        Dispose()
    End Sub

    Private Sub BtnPilih_Click(sender As Object, e As EventArgs) Handles BtnPilih.Click
        Try

            If Me.RBPerush.Checked = True Then
                FrmCompany.ShowDialog()
            End If

            If Me.RBBas.Checked = True Then
                FrmAkun.ShowDialog()
            End If

            If Me.RBFA.Checked = True Then
                FrmReFiscor.ShowDialog()
            End If

            If Me.RBFisRec.Checked = True Then
                FrmCRptFisRec.ShowDialog()
            End If

            If Me.RBDivisi.Checked = True Then
                'FrmCRptJurnal.ShowDialog()
            End If

            If Me.RBEmploy.Checked = True Then
                'FrmCRptJurnal.ShowDialog()
            End If

            If Me.RBEmploy.Checked = True Then
                'FrmCRptBB.ShowDialog()
            End If

        Catch ex As Exception

        End Try
    End Sub
End Class