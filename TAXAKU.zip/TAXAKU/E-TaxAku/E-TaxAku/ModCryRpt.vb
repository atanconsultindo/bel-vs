﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Data.Odbc
Module ModCryRpt
    Public Sub SetReportDb(ByVal ConnectionString As String, ByRef CrystalReportViewer As CrystalDecisions.Windows.Forms.CrystalReportViewer, ByRef reportDocument As ReportClass)
        'Get SQL Server Details
        'Dim builder As New System.Data.Common.DbConnectionStringBuilder()
        Dim builder As New SqlClient.SqlConnectionStringBuilder
        builder.ConnectionString = ConnectionString


        ''Dim zDriver As String = TryCast(builder("DRIVERNAME"), String)
        'Dim zServer As String = TryCast(builder("SERVER"), String)
        'Dim zDatabase As String = TryCast(builder("DATABASE"), String)
        'Dim zUsername As String = TryCast(builder("UID"), String)
        'Dim zPassword As String = TryCast(builder("PWD"), String)

        'Dim zDriver As String = TryCast(builder("DRIVERNAME"), String)
        Dim zServer As String = TryCast(builder("Data Source"), String)
        Dim zDatabase As String = TryCast(builder("Initial Catalog"), String)
        Dim zSecurity As String = TryCast(builder("Integrated Security"), String)
        Dim zUsername As String = TryCast(builder("User ID"), String)
        Dim zPassword As String = TryCast(builder("Password"), String)

        Dim ciReportConnection As New ConnectionInfo


        ciReportConnection.ServerName = zServer
        ciReportConnection.DatabaseName = zDatabase
        ciReportConnection.UserID = zUsername
        ciReportConnection.Password = zPassword

        'conn.ConnectionString = "DRIVER =" & DRIVERNAME & ";SERVER =" & SERVERNAME & ";DATABASE=" & DATABASENAME & ";PWD=" & PWDNAME & ";UID=" & UIDNAME

        'Assign data source details to tables
        If zSecurity = False Then
            ciReportConnection.UserID = zUsername
            ciReportConnection.Password = zPassword
        Else
            reportDocument.DataSourceConnections(0).IntegratedSecurity = True
        End If


        For Each table As Table In reportDocument.Database.Tables
            table.LogOnInfo.ConnectionInfo = ciReportConnection
            table.ApplyLogOnInfo(table.LogOnInfo)
        Next

        For Each subrep As ReportDocument In reportDocument.Subreports
            For Each table As Table In subrep.Database.Tables
                table.LogOnInfo.ConnectionInfo = ciReportConnection
                table.ApplyLogOnInfo(table.LogOnInfo)
            Next
        Next

        'Assign data source details to the report viewer
        If CrystalReportViewer.LogOnInfo IsNot Nothing Then
            Dim tlInfo As TableLogOnInfos = CrystalReportViewer.LogOnInfo
            For Each tbloginfo As TableLogOnInfo In tlInfo
                tbloginfo.ConnectionInfo = ciReportConnection
            Next
        End If
        reportDocument.VerifyDatabase()
        reportDocument.Refresh()
        CrystalReportViewer.ReportSource = reportDocument
        CrystalReportViewer.Refresh()
    End Sub

End Module
