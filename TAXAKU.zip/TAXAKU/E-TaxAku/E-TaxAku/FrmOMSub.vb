﻿Imports System.Data.Odbc
Public Class FrmOMSub
    Private Sub PosisiList()

        With LVJUSub.Columns
            .Add("Periode", 60)
            .Add("Tanggal", 90, HorizontalAlignment.Right)
            .Add("No.Transaksi", 110)
            .Add("Keterangan", 325)
            .Add("Status", 0)
            .Add("Jenis Transaksi", 150)
        End With
    End Sub

    Private Sub IsiList()
        Dim a As Integer
        Try
            query = "SELECT ta_hjurnal.periode, ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.Status, r_djt.nama_djt FROM ta_hjurnal LEFt JOIN r_djt on ta_hjurnal.id_djt = r_djt.id_djt  WHERE (ta_hjurnal.periode = '" & cboPeriode.Text & "') AND (ta_hjurnal.id_djt LIKE '2%') ORDER BY ta_hjurnal.periode ASC, ta_hjurnal.tgl_trans ASC, ta_hjurnal.no_bukti ASC, ta_hjurnal.status ASC; "

            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            LVJUSub.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVJUSub
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(1), "yyyy-MM-dd"))
                    '.Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.LightBlue
                    End If
                End With
            Next
        Catch ex As Exception
            'MsgBox(ex.Message, MsgBoxStyle.OkOnly)
        End Try
    End Sub

    Private Sub AmbilData()
        Try
            With LVJUSub.SelectedItems
                FrmOM.lblPeriode.Text = .Item(0).SubItems(0).Text
                FrmOM.DateTPJU.Text = .Item(0).SubItems(1).Text
                FrmOM.TxtNoBukti.Text = .Item(0).SubItems(2).Text
                FrmOM.TxtKetJU.Text = .Item(0).SubItems(3).Text
                FrmOM.mPosted = .Item(0).SubItems(4).Text
                FrmOM.CbJasa.Text = .Item(0).SubItems(5).Text
                FrmOM.TSBTambah.Text = " & Tambah"
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub IsiComboPeriode()
        Try
            query = "SELECT r_perush.tahun FROM r_perush ORDER BY tahun Desc"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            cboPeriode.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With cboPeriode
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub


    Private Sub cmdYa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdYa.Click
        AmbilData()
        FrmOM.IsiListMasJU()
        FrmOM.JumlahDebetKredit()
        Dispose()
    End Sub

    Private Sub ListView_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles LVJUSub.KeyPress
        If e.KeyChar = Chr(13) Then
            AmbilData()
            FrmOM.IsiListMasJU()
            FrmOM.JumlahDebetKredit()
            Dispose()
        End If
    End Sub

    Private Sub txtNoTransaksi_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtNoTransaksi.KeyPress
        If e.KeyChar = Chr(13) Then
            LVJUSub.Focus()
        End If
    End Sub

    Private Sub txtNoTransaksi_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNoTransaksi.TextChanged
        Try
            query = "SELECT ta_hjurnal.periode, ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.Status FROM(ta_hjurnal) GROUP BY ta_hjurnal.periode, ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.Status HAVING(((ta_hjurnal.periode) = '" & cboPeriode.Text & "') And ((ta_hjurnal.no_bukti) Like '" & "%" & txtNoTransaksi.Text & "%" & "')) ORDER BY ta_hjurnal.periode, ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.Status"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            LVJUSub.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVJUSub
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(1), "dd/MM/yyyy"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.LightBlue
                    End If
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub cboPeriode_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboPeriode.KeyPress
        If e.KeyChar = Chr(13) Then
            If cboPeriode.Text = "" Then
                MsgBox("Periode kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan Periode")
                cboPeriode.Focus()
            Else
                txtNoTransaksi.Focus()
            End If
        End If
    End Sub

    Private Sub cboPeriode_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboPeriode.SelectedIndexChanged
        Try
            'query = "SELECT ta_hjurnal.periode, ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.Status FROM(ta_hjurnal) GROUP BY ta_hjurnal.periode, ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.Status HAVING(((ta_hjurnal.periode) = '" & cboPeriode.Text & "')) ORDER BY ta_hjurnal.periode DESC , ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.Status"
            query = "SELECT ta_hjurnal.periode, ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.Status, r_djt.nama_djt FROM ta_hjurnal LEFt JOIN r_djt on ta_hjurnal.id_djt = r_djt.id_djt  WHERE (ta_hjurnal.periode = '" & cboPeriode.Text & "') AND (ta_hjurnal.id_djt LIKE '2%') ORDER BY ta_hjurnal.periode ASC, ta_hjurnal.tgl_trans ASC, ta_hjurnal.no_bukti ASC, ta_hjurnal.status ASC;"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            LVJUSub.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVJUSub
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(1), "yyyy-MM-dd"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.LightBlue
                    End If
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ListView_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles LVJUSub.KeyUp
        If e.KeyCode = Keys.Escape Then
            Dispose()
        End If
    End Sub

    Private Sub FrmOMSub_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            GetDatabaseSetting()
            cboPeriode.Text = FrmOM.lblPeriode.Text
            PosisiList()
            IsiList()
            IsiComboPeriode()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub ListView_DoubleClick(sender As Object, e As EventArgs) Handles LVJUSub.DoubleClick
        Try
            AmbilData()
            FrmOM.IsiListMasJU()
            FrmOM.JumlahDebetKredit()
            Dispose()
        Catch ex As Exception
            'MsgBox("Tidak ada data rincian", MsgBoxStyle.OkOnly, "Pesan")
        End Try

    End Sub

    Private Sub FrmOMSub_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        txtNoTransaksi.Focus()
        'PosisiList()
        'IsiList()
    End Sub

    Private Sub LVJUSub_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVJUSub.SelectedIndexChanged
        AmbilData()
        FrmOM.IsiListMasJU()
        'FrmOMrnalUmum.TotalDebetKredit()
        FrmOM.JumlahDebetKredit()
        Dispose()
    End Sub
    Private Sub cmdKeluar_Click(sender As Object, e As EventArgs) Handles cmdKeluar.Click
        Dispose()
    End Sub

End Class