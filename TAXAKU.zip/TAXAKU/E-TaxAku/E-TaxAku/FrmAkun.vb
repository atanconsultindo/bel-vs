﻿Imports System.Data.Odbc
Public Class FrmAkun

    Private Sub PosisiListRek()
        Try
            With LVRek.Columns
                .Add("Kd Akun1", 40)
                .Add("Group Akun", 140)
                .Add("Kd Akun2", 0)
                .Add("Kelompok Akun", 200)
                .Add("Kode Akun", 100)
                .Add("Nama Akun (Perkiraan)", 350)
            End With
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub

    Sub IsiListRek()
        Dim a As Integer
        Try
            query = "SELECT akun3.`id_akun1`, akun1.`nama_akun1`, akun3.`id_akun2`,akun2.`nama_akun2`, akun3.`id_akun3`, akun3.`nama_akun3`" &
                    " FROM akun3 " &
                    "LEFT JOIN akun1 ON akun1.`id_akun1` = akun3.`id_akun1` " &
                    "LEFT JOIN akun2 ON akun3.`id_akun2` = akun3.`id_akun2` AND akun3.`id_akun1` = akun2.`id_akun1` " &
                    "GROUP BY akun3.`id_akun1`, akun3.`id_akun2`, akun3.`id_akun3` " &
                    " ORDER BY akun3.`id_akun3`"

            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVRek.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVRek
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.LavenderBlush
                    End If
                End With

            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Dispose()
    End Sub

    Private Sub TSBSave_Click(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            If CbGroup.Text = "" Then
                MessageBox.Show("Group tidak boleh kosong", "warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                CbGroup.Focus()
            Else
                If CbKel.Text = "" Then
                    MsgBox("Kelompok tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                    CbKel.Focus()
                Else
                    If TxtKdAKun.Text = "" Then
                        MsgBox("Kode akun tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                        TxtKdAKun.Focus()
                    Else
                        If TxtUraian.Text = "" Then
                            MsgBox("Uraian akun tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                            TxtUraian.Focus()
                        Else

                            CekData_Akun()
                            BersihkanIsian()
                            IsiListRek()
                        End If
                    End If
                End If
            End If

        Catch ex As Exception
            MsgBox("Data tidak bisa tersimpan karena user sudah ada...", MsgBoxStyle.Exclamation, "Error")
            CbGroup.Focus()
        End Try
    End Sub

    Private Sub CekData_Akun()
        Try
            query = "SELECT * FROM akun3 where id_akun3 = '" & TxtKdAKun.Text & "' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            If dsData.Tables(0).Rows.Count > 0 Then
                MsgBox("Kode '" & TxtKdAKun.Text & "' sudah ada...", MsgBoxStyle.Exclamation, "Error")
                CbGroup.Focus()
            Else
                SimpanData_Akun()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SimpanData_Akun()
        Try
            query = "INSERT INTO akun3(id_akun1, id_akun2, id_akun3, nama_akun3) VALUES( '" & LblGroup.Text & "', '" & LblKel.Text & "', '" & TxtKdAKun.Text & "', '" & TxtUraian.Text & "');"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            MsgBox("Data user baru tersimpan", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Pesan")
            'Return query
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub BersihkanIsian()
        CbGroup.Text = ""
        LblGroup.Text = ""
        CbKel.Text = ""
        LblKel.Text = ""
        TxtKdAKun.Text = ""
        TxtUraian.Text = ""
    End Sub

    Private Sub GroupAkun_load()

        Dim a As Integer
        Try
            query = "SELECT * FROM akun1  ORDER BY id_akun1"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbGroup.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbGroup
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2)
                    .Items.Add(dsData.Tables(0).Rows(a).Item(1))
                End With


            Next
        Catch ex As Exception

        End Try

    End Sub


    Private Sub KelAkun_load()

        Dim a As Integer
        Try
            query = "SELECT * FROM akun2  where id_akun1 = '" & LblGroup.Text & "' ORDER BY id_akun1  "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbKel.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbKel
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2)
                    .Items.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception

        End Try

    End Sub

    Private Sub FrmAkun_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            GetDatabaseSetting()
            PosisiListRek()
            IsiListRek()
            GroupAkun_load()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub CbGroup_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles CbGroup.SelectedIndexChanged
        Try
            CbKel.Text = ""
            LblKel.Text = ""
            query = "SELECT * FROM akun1 WHERE nama_akun1 = '" & CbGroup.Text & "' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            With dsData.Tables(0).Rows(0)
                LblGroup.Text = .Item(0)
            End With

            KelAkun_load()
        Catch ex As Exception
            'MsgBox(ex.Message, "Changer")
        End Try
    End Sub

    Private Sub CbKel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbKel.SelectedIndexChanged
        Try
            query = "SELECT * FROM akun2 WHERE nama_akun2 = '" & CbKel.Text & "' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            With dsData.Tables(0).Rows(0)
                LblKel.Text = .Item(1)
            End With


        Catch ex As Exception
            'MsgBox(ex.Message, "Changer")
        End Try
    End Sub

    Private Sub CbGroup_Click(sender As Object, e As EventArgs) Handles CbGroup.Click
        'CbKel.Items.Clear()
    End Sub

    Private Sub TSBPrint_Click(sender As Object, e As EventArgs) Handles TSBPrint.Click
        FrmCRptBas.ShowDialog()
    End Sub

    Private Sub FrmAkun_LocationChanged(sender As Object, e As EventArgs) Handles MyBase.LocationChanged
        Try
            'Me.Location = New Point(500, 60)
            Me.Location = New Point(250, 60)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBEdit_Click(sender As Object, e As EventArgs) Handles TSBEdit.Click
        Dim A As String

        'If mPosted = "UnPosted" Then
        A = MsgBox("Benar akan di-Edit", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Informasi Edit")
        Select Case A
            Case vbCancel
                CbGroup.Focus()
                TSBEdit.Text = "&Edit"
                TSBSave.Enabled = True
                TSBAdd.Enabled = True
                BersihkanIsian()

                Exit Sub
            Case vbOK
                Try
                    EditBas()
                    IsiListRek()
                    BersihkanIsian()
                    TSBEdit.Text = "&Edit"
                    TSBSave.Enabled = True
                    TSBAdd.Enabled = True

                Catch ex As Exception
                    MsgBox("Terjadi kesalahan")
                End Try
        End Select
    End Sub

    Private Sub EditBas()
        Try
            If CbGroup.Text = "" Then
                MessageBox.Show("Group tidak boleh kosong", "warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                CbGroup.Focus()
            Else
                If CbKel.Text = "" Then
                    MsgBox("Kelompok tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                    CbKel.Focus()
                Else
                    If TxtKdAKun.Text = "" Then
                        MsgBox("Kode akun tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                        TxtKdAKun.Focus()
                    Else
                        If TxtUraian.Text = "" Then
                            MsgBox("Uraian akun tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                            TxtUraian.Focus()
                        Else
                            query = "UPDATE akun3 SET nama_akun3 = '" & TxtUraian.Text & "' WHERE id_akun3 = '" & TxtKdAKun.Text & "';"
                            daData = New OdbcDataAdapter(query, conn)
                            dsData = New DataSet
                            daData.Fill(dsData)
                            MsgBox("Data updated", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Pesan")
                        End If
                    End If
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub LVRek_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVRek.SelectedIndexChanged
        Try
            AmbilDataListAkun()
            CbGroup.Enabled = False
            CbKel.Enabled = False
            TxtKdAKun.Enabled = False
            TSBSave.Enabled = False
            TSBEdit.Enabled = True
            TSBDelete.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AmbilDataListAkun()

        '.Add("Kd Akun1", 40)
        '.Add("Group Akun", 140)
        '.Add("Kd Akun2", 0)
        '.Add("Kelompok Akun", 200)
        '.Add("Kode Akun", 100)
        '.Add("Nama Akun (Perkiraan)", 350)
        Try
            With LVRek.SelectedItems
                Try
                    LblGroup.Text = .Item(0).SubItems(0).Text
                    CbGroup.Text = .Item(0).SubItems(1).Text
                    LblKel.Text = .Item(0).SubItems(2).Text
                    CbKel.Text = .Item(0).SubItems(3).Text
                    TxtKdAKun.Text = .Item(0).SubItems(4).Text
                    TxtUraian.Text = .Item(0).SubItems(5).Text
                Catch ex As Exception

                End Try
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBAdd_Click(sender As Object, e As EventArgs) Handles TSBAdd.Click
        Try

            CbGroup.Enabled = True
            CbKel.Enabled = True
            TxtKdAKun.Enabled = True
            TSBSave.Enabled = True
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            BersihkanIsian()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub LVRek_Click(sender As Object, e As EventArgs) Handles LVRek.Click
        CbGroup.Enabled = False
        CbKel.Enabled = False
        TxtKdAKun.Enabled = False
        TSBSave.Enabled = False
        TSBEdit.Enabled = True
        TSBDelete.Enabled = True
    End Sub

    Private Sub TSBDelete_Click(sender As Object, e As EventArgs) Handles TSBDelete.Click
        Dim A As String

        'If mPosted = "UnPosted" Then
        Try
            If Len(TxtKdAKun.Text) = 0 Then
                MsgBox("Pilih data yang dihapus", MsgBoxStyle.Information, "Informasi hapus")
                TxtKdAKun.Enabled = True
                TxtKdAKun.Focus()
                TSBSave.Enabled = True
                TSBAdd.Enabled = True
                Exit Sub
            Else

                'untuk menghapus record jurnal
                A = MsgBox("Benar akan dihapus...", MsgBoxStyle.OkCancel, "Informasi")
                Select Case A
                    Case vbCancel
                        TxtKdAKun.Focus()
                        TSBEdit.Text = "&Edit"
                        TSBAdd.Text = "&New Item"
                        TxtKdAKun.Enabled = True
                        TSBSave.Enabled = True
                        TSBAdd.Enabled = True
                        Exit Sub
                    Case vbOK
                        HapusAkun()
                        'HapusIsiOMDetail()
                        IsiListRek()
                        BersihkanIsian()
                        TxtKdAKun.Focus()

                        TSBEdit.Text = "&Edit"
                        TSBAdd.Text = "&New Item"
                        TxtKdAKun.Enabled = True
                        TSBSave.Enabled = True
                        TSBAdd.Enabled = True
                End Select
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Perhatian")
        End Try

    End Sub

    Private Sub HapusAkun()
        Try

            query = "DELETE FROM akun3 WHERE id_akun3 = '" & TxtKdAKun.Text & "'"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            MsgBox("Data deleted", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Pesan")

        Catch ex As Exception

        End Try
    End Sub



    Private Sub TxtKdAKun_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtKdAKun.KeyPress
        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = ".") Then
            e.Handled = True
        End If
    End Sub
End Class