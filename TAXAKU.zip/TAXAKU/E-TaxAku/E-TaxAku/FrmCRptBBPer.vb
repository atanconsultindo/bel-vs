﻿Public Class FrmCRptBBPer
    Private Sub FrmCRptBBPer_Load(sender As Object, e As EventArgs) Handles MyBase.Load, CrystalReportViewer1.Load
        Dim rep As New RptBBPer 'crJual merupakan nama file CrystalReport
        'rep.SetParameterValue("lblprov", prov)
        'rep.SetParameterValue("lblkab", kab)

        rep.SetParameterValue("tglawal", FrmReportPer.DateTPAwal.Value.ToShortDateString)
        rep.SetParameterValue("tglakhir", FrmReportPer.DateTPAkhir.Value.ToShortDateString)
        CrystalReportViewer1.SelectionFormula = "{Command.tgl_trans} >= #" & FrmReportPer.DateTPAwal.Value.ToShortDateString & "# AND {Command.tgl_trans} <= #" & FrmReportPer.DateTPAkhir.Value.ToShortDateString & "#"
        'CrystalReportViewer1.SelectionFormula = "{Command.MaxOfTglTransaksi} >= #" & FrmLapkeu.DateTPAwal.Value.ToShortDateString & "# AND {Command.MaxOfTglTransaksi} <= #" & FrmLapkeu.DateTPAkhir.Value.ToShortDateString & "#"
        'CrystalReportViewer1.
        CrystalReportViewer1.ReportSource = rep
        CrystalReportViewer1.Refresh()
        CrystalReportViewer1.EnableRefresh = False
        'CrystalReportViewer1.ReportSource = rep
        CrystalReportViewer1.Refresh()
        CrystalReportViewer1.EnableRefresh = False
    End Sub
End Class