﻿Imports System.Data.Odbc
Public Class FrmFisRec
    Private mNilai As Long
    Private mNiBTax As Long
    Private mNiATax As Long
    Private mFiscalAdj As Long

    Private Sub PosisiList()
        Try
            With LVFiscor.Columns
                .Add("No", 40)
                .Add("Kd Koreksi", 40)
                .Add("Jenis Koreksi ", 150)
                .Add("Pos/Neg", 60)
                .Add("Nilai", 125, HorizontalAlignment.Right)
                .Add("Keterangan", 250)
            End With
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub

    Sub IsiList()
        Dim a As Integer
        Try
            str = "SELECT ta_fiscor.`no`, ta_fiscor.`id_dfiscor`, r_dfiscor.`nama_dfiscor`,  ta_fiscor.`pn`, ta_fiscor.`nilai`, ta_fiscor.`ket` FROM ta_fiscor " &
                    " LEFT JOIN r_dfiscor ON ta_fiscor.`id_dfiscor` = r_dfiscor.`id_dfiscor` " &
                    " ORDER BY ta_fiscor.`id_dfiscor`"

            'query = "SELECT dJurnal.NoTransaksi, dJurnal.NoPerkiraan, tblMasterPerkiraan.NamaPerkiraan, dJurnal.DK, dJurnal.Debet, dJurnal.Kredit FROM (dJurnal LEFT JOIN ta_hjurnal ON dJurnal.NoTransaksi = ta_hjurnal.no_bukti) LEFT JOIN tblMasterPerkiraan ON dJurnal.NoPerkiraan = tblMasterPerkiraan.NoPerkiraan WHERE(((dJurnal.NoTransaksi) = '" & txtNobukti.Text & "'))"
            daData = New OdbcDataAdapter(str, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVFiscor.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVFiscor
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(4), "#,#0"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))



                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.Orange
                    End If
                    'Else
                    '    MsgBox("No Data", MsgBoxStyle.OkOnly, "Pesan")
                    'End If
                End With
            Next


        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "No Data")
        End Try
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Dispose()
    End Sub

    Private Sub FrmFisRec_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            GetDatabaseSetting()
            PosisiList()
            IsiList()
            Fiscor_load()
            HitungNiBTax()
            HitungFA()
            HitungNiATax()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Fiscor_load()

        Dim a As Integer
        Try
            query = "SELECT * FROM r_dfiscor  ORDER BY id_dfiscor "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CBFiscor.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CBFiscor
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2)
                    .Items.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception

        End Try

    End Sub

    Private Sub CBFiscor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBFiscor.SelectedIndexChanged
        Try
            query = "SELECT * FROM r_dfiscor WHERE nama_dfiscor = '" & CBFiscor.Text & "' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            With dsData.Tables(0).Rows(0)
                LblFiscor.Text = .Item(1)
            End With
        Catch ex As Exception
            'MsgBox(ex.Message, "Changer")
        End Try
    End Sub


    Private Sub TxtNilai_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNilai.KeyPress
        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = ".") Then
            e.Handled = True
        End If
    End Sub

    Private Sub TSBSave_Click(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            If CBFiscor.Text = "" Then
                MessageBox.Show("Jenis koreksi tidak boleh kosong", "warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                CBFiscor.Focus()
            Else
                If CbPN.Text = "" Then
                    MsgBox("Koreksi Pos/Neg tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                    CbPN.Focus()
                Else
                    If TxtNilai.Text = "" Then
                        TxtNilai.Text = "0"
                    Else
                        SimpanData_Fiscor()
                        BersihkanIsian()
                        IsiList()
                        MsgBox("Data user baru tersimpan", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Pesan")
                        HitungNiBTax()
                        HitungFA()
                        HitungNiATax()

                    End If
                End If

            End If

        Catch ex As Exception
            MsgBox("Data tidak bisa tersimpan karena user sudah ada...", MsgBoxStyle.Exclamation, "Error")
            'frmPerkiraan.txtNo.Focus()
        End Try
    End Sub

    Private Sub SimpanData_Fiscor()
        Try
            mNilai = TxtNilai.Text

            query = "INSERT INTO ta_fiscor(id_dfiscor, pn, nilai, ket) VALUES( '" & LblFiscor.Text & "', '" & Microsoft.VisualBasic.Left(CbPN.Text, "1") & "', '" & mNilai & "', '" & TxtKet.Text & "');"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            'Return query
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub BersihkanIsian()
        'NoTransaksi()
        CBFiscor.Text = ""
        LblFiscor.Text = ""
        LblNo.Text = ""
        CbPN.Text = ""
        TxtNilai.Text = "0"
        TxtKet.Text = ""
        CBFiscor.Focus()

    End Sub

    Private Sub TSBEdit_Click(sender As Object, e As EventArgs) Handles TSBEdit.Click
        Dim A As String

        'If mPosted = "UnPosted" Then
        A = MsgBox("Benar akan di-Edit", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Informasi Edit")
        Select Case A
            Case vbCancel
                CBFiscor.Focus()
                TSBEdit.Text = "&Edit"
                TSBSave.Enabled = True
                TSBAdd.Enabled = True
                BersihkanIsian()

                Exit Sub
            Case vbOK
                Try
                    EditFiscor()
                    IsiList()
                    HitungNiBTax()
                    HitungFA()
                    HitungNiATax()
                    BersihkanIsian()

                    TSBEdit.Text = "&Edit"
                    TSBSave.Enabled = True
                    TSBAdd.Enabled = True

                Catch ex As Exception
                    MsgBox("Terjadi kesalahan")
                End Try
        End Select
    End Sub

    Private Sub EditFiscor()
        Try
            If CBFiscor.Text = "" Then
                MessageBox.Show("Jenis koreksi tidak boleh kosong", "warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                CBFiscor.Focus()
            Else
                If CbPN.Text = "" Then
                    MsgBox("Koreksi Pos/Neg tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                    CbPN.Focus()
                Else
                    If TxtNilai.Text = "" Then
                        TxtNilai.Text = "0"
                    Else
                        mNilai = TxtNilai.Text

                        query = "UPDATE ta_fiscor SET pn = '" & Microsoft.VisualBasic.Left(CbPN.Text, "1") & "', nilai = '" & mNilai & "', ket = '" & TxtKet.Text &
                                "' WHERE id_dfiscor = '" & LblFiscor.Text & "' AND no = '" & LblNo.Text & "';"
                        daData = New OdbcDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                    End If
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub LVFiscor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVFiscor.SelectedIndexChanged
        Try
            AmbilDataListFiscor()
            CBFiscor.Enabled = False
            TSBSave.Enabled = False
            TSBEdit.Enabled = True
            TSBDelete.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AmbilDataListFiscor()
        '.Add("No", 40)
        '.Add("Jenis Koreksi ", 90)
        '.Add("Pos/Neg", 60)
        '.Add("Nilai", 125, HorizontalAlignment.Right)
        '.Add("Keterangan", 150)

        Try
            With LVFiscor.SelectedItems
                Try
                    LblNo.Text = .Item(0).SubItems(0).Text
                    LblFiscor.Text = .Item(0).SubItems(1).Text
                    CBFiscor.Text = .Item(0).SubItems(2).Text
                    CbPN.Text = .Item(0).SubItems(3).Text
                    TxtNilai.Text = .Item(0).SubItems(4).Text
                    TxtKet.Text = .Item(0).SubItems(5).Text
                Catch ex As Exception

                End Try
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub LVFiscor_Click(sender As Object, e As EventArgs) Handles LVFiscor.Click
        CBFiscor.Enabled = False
        TSBSave.Enabled = False
        TSBEdit.Enabled = True
        TSBDelete.Enabled = True
    End Sub

    Private Sub TSBDelete_Click(sender As Object, e As EventArgs) Handles TSBDelete.Click
        Dim A As String

        'If mPosted = "UnPosted" Then
        Try
            If Len(CBFiscor.Text) = 0 Then
                MsgBox("Pilih data yang dihapus", MsgBoxStyle.Information, "Informasi hapus")
                CBFiscor.Enabled = True
                CBFiscor.Focus()
                TSBSave.Enabled = True
                TSBAdd.Enabled = True
                Exit Sub
            Else

                'untuk menghapus record jurnal
                A = MsgBox("Benar akan dihapus...", MsgBoxStyle.OkCancel, "Informasi")
                Select Case A
                    Case vbCancel
                        CBFiscor.Focus()
                        TSBEdit.Text = "&Edit"
                        TSBAdd.Text = "&New Item"
                        CBFiscor.Enabled = True
                        TSBSave.Enabled = True
                        TSBAdd.Enabled = True
                        Exit Sub
                    Case vbOK
                        HapusFiscor()
                        'HapusIsiOMDetail()
                        IsiList()
                        HitungNiBTax()
                        HitungFA()
                        HitungNiATax()
                        BersihkanIsian()
                        CBFiscor.Focus()

                        TSBEdit.Text = "&Edit"
                        TSBAdd.Text = "&New Item"
                        CBFiscor.Enabled = True
                        TSBSave.Enabled = True
                        TSBAdd.Enabled = True
                End Select
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Perhatian")
        End Try
        'Else
        '    MsgBox("Data ini sudah diposting, tidak bisa dihapus...", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Hapus data")
        '    tsbsave.Enabled = True
        'End If
    End Sub
    Private Sub HapusFiscor()
        Try

            query = "DELETE FROM ta_fiscor WHERE id_dfiscor = '" & LblFiscor.Text & "' AND no = '" & LblNo.Text & "'"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBCancel_Click(sender As Object, e As EventArgs) Handles TSBCancel.Click
        BersihkanIsian()
    End Sub

    Private Sub TSBAdd_Click(sender As Object, e As EventArgs) Handles TSBAdd.Click
        CBFiscor.Enabled = True
        TSBSave.Enabled = True
        TSBEdit.Enabled = False
        TSBDelete.Enabled = False
        BersihkanIsian()
    End Sub

    Private Sub BtnPreview_Click(sender As Object, e As EventArgs) Handles BtnPreview.Click
        FrmCRptFisRec.ShowDialog()
    End Sub

    Private Sub HitungNiBTax()
        Try
            query = "SELECT SUM(ta_djurnal.kredit-ta_djurnal.debet) AS 'Laba/(Rugi)' " &
                    "FROM ta_djurnal " &
                    " WHERE LEFT(ta_djurnal.id_akun3,'1')='4' OR LEFT(ta_djurnal.id_akun3,'1')='5' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            With dsData.Tables(0).Rows(0)
                mNiBTax = .Item(0)
                LblNiBTax.Text = Format(mNiBTax, "#,#0")
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub HitungFA()
        Try
            query = "SELECT ((SELECT SUM(ta_fiscor.`nilai`) FROM ta_fiscor WHERE ta_fiscor.`pn` IN ('p')) + (SELECT -SUM(ta_fiscor.`nilai`) FROM ta_fiscor WHERE ta_fiscor.`pn` IN ('n')) ) AS Fiscor"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            With dsData.Tables(0).Rows(0)
                mFiscalAdj = .Item(0)
                LblFa.Text = Format(mFiscalAdj, "#,#0")
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub HitungNiATax()
        Try
            HitungNiBTax()
            HitungFA()
            LblNiATax.Text = Format(mNiBTax + mFiscalAdj, "#,#0")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TxtTarif_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtTarif.KeyPress
        Try
            If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = ".") Then
                e.Handled = True
            End If
            LblPph.Text = Format(TxtTarif.Text * LblNiATax.Text / 100, "#,#0")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TxtTarif_TextChanged(sender As Object, e As EventArgs) Handles TxtTarif.TextChanged
        Try
            LblPph.Text = Format(TxtTarif.Text * LblNiATax.Text / 100, "#,#0")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FrmFiscal.ShowDialog()
    End Sub
End Class