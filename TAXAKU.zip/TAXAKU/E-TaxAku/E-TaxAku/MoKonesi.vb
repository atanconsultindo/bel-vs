﻿Imports System.Data.Odbc
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Module MoKonesi
    Public conn As New OdbcConnection
    Public dbDriver As String
    Public dbServer As String
    Public dbDatabase As String
    Public dbPassword As String
    Public dbUID As String
    Public sLocalConn As String


    Public da, da1, da2, da3, da4, da5, daData As OdbcDataAdapter
    Public ds, ds1, dsData As DataSet
    Public datatable As New DataTable
    Public query, str, str1, str2, str3, str4, str5, str6 As String
    Public dr, dr1, dr2, dr3 As OdbcDataReader

    Public cmd, cmd1, cmd2, cmd3 As OdbcCommand

    'Public cmd As New OleDbCommand
    'Public da, daData, da1, da2, da3, da4, da5 As New OleDbDataAdapter
    'Public ds, dsData, ds1, ds2, ds3 As New DataSet
    'Public query, str, str1, str2, str3, str4, str5, str6 As String
    'Public datatable As New DataTable
    'Public DR As OleDbDataReader
    Public Const prov As String = "PEMERINTAH PROVINSI JAWA TIMUR"
    Public Const company As String = "PT WAHANA ENERGI SEJAHTERA"

    Public Sub GetDatabaseSetting()
        Try
            dbDriver = My.Settings.dbDriver
            dbServer = My.Settings.dbServer
            dbDatabase = My.Settings.dbDatabase
            dbPassword = My.Settings.dbPassword
            dbUID = My.Settings.dbUID
            sLocalConn = "DRIVER=" & dbDriver & ";SERVER=" & dbServer & ";DATABASE=" & dbDatabase & ";PWD=" & dbPassword & ";UID=" & dbUID
            conn = New OdbcConnection(sLocalConn)
            If conn.State = ConnectionState.Closed Then conn.Open()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Public Function DatabaseConnected(Optional ByVal DRIVERNAME As String = "",
                                      Optional ByVal SERVERNAME As String = "",
                                      Optional ByVal DATABASENAME As String = "",
                                      Optional ByVal PWDNAME As String = "",
                                      Optional ByVal UIDNAME As String = "") As Boolean
        Dim conn As OdbcConnection
        conn = New OdbcConnection()
        If DRIVERNAME = "" And SERVERNAME = "" And DATABASENAME = "" And PWDNAME = "" And UIDNAME = "" Then
            conn.ConnectionString = sLocalConn
        Else
            conn.ConnectionString = "DRIVER =" & DRIVERNAME & ";SERVER =" & SERVERNAME & ";DATABASE=" & DATABASENAME & ";PWD=" & PWDNAME & ";UID=" & UIDNAME
        End If

        Try
            'conn = New OdbcConnection(MyDb)
            conn.Open()
            'conn.Close()
            Return True
        Catch ex As Exception
            Return False
            MsgBox("GetDatabaseSetting error" + vbNewLine + "Check Setting GetDatabaseSetting!", MsgBoxStyle.Critical, "PESAN KESALAHAN")
        Finally
            conn.Dispose()
        End Try
        Return False
    End Function

End Module
