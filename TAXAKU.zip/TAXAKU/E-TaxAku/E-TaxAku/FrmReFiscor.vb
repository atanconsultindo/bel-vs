﻿Imports System.Data.Odbc
Public Class FrmReFiscor
    Private Sub PosisiList()
        Try
            With LVFisrec.Columns
                .Add("Kd Jens", 80)
                .Add("Jenis Beda", 150)
                .Add("Kd Rekon", 80)
                .Add("Nama AKun Rekonsiliasi", 400)
            End With
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub

    Sub IsiList()
        Dim a As Integer
        Try
            query = "SELECT r_dfiscor.`id_fiscor`, r_hfiscor.`nama_fiscor`, r_dfiscor.`id_dfiscor`, r_dfiscor.`nama_dfiscor` " &
                    "FROM r_dfiscor " &
                    "LEFT JOIN r_hfiscor ON r_dfiscor.`id_fiscor` = r_hfiscor.`id_fiscor` " &
                    " GROUP BY r_dfiscor.`id_fiscor`, r_dfiscor.`id_dfiscor`  " &
                    " ORDER BY r_dfiscor.`id_dfiscor` "

            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVFisrec.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVFisrec
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))

                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.LavenderBlush
                    End If
                End With
            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Dispose()
    End Sub

    Private Sub FrmReFiscor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            GetDatabaseSetting()
            JenisFiscor_load()
            PosisiList()
            IsiList()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub JenisFiscor_load()

        Dim a As Integer
        Try
            query = "SELECT * FROM r_hfiscor  ORDER BY id_fiscor"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbJenis.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbJenis
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2)
                    .Items.Add(dsData.Tables(0).Rows(a).Item(1))
                End With
            Next
        Catch ex As Exception

        End Try

    End Sub

    Private Sub TxtKdAKun_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtKdRecon.KeyPress
        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = ".") Then
            e.Handled = True
        End If
    End Sub

    Private Sub CbJenis_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbJenis.SelectedIndexChanged
        Try
            query = "SELECT * FROM r_hfiscor WHERE nama_fiscor = '" & CbJenis.Text & "' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            With dsData.Tables(0).Rows(0)
                LblJenis.Text = .Item(0)
                TxtKdRecon.Text = .Item(0) & "_"
            End With

            'TxtKdRecon.Text = '" & LblJenis.text & "_"'

        Catch ex As Exception
            'MsgBox(ex.Message, "Changer")
        End Try
    End Sub

    Private Sub TSBSave_Click(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            If CbJenis.Text = "" Then
                MessageBox.Show("Group tidak boleh kosong", "warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                CbJenis.Focus()
            Else
                If TxtKdRecon.Text = "" Then
                    MsgBox("Kode rekon tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                    TxtKdRecon.Focus()
                Else

                    If TxtUraian.Text = "" Then
                        MsgBox("Uraian akun tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                        TxtUraian.Focus()
                    Else

                        CekData_Rekon()
                        BersihkanIsian()
                        IsiList()

                    End If
                End If
            End If

        Catch ex As Exception
            'MsgBox("Data tidak bisa tersimpan karena user sudah ada...", MsgBoxStyle.Exclamation, "Error")
            'CbGroup.Focus()
        End Try
    End Sub


    Private Sub CekData_Rekon()
        Try
            query = "SELECT * FROM r_dfiscor where id_dfiscor = '" & TxtKdRecon.Text & "' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            If dsData.Tables(0).Rows.Count > 0 Then
                MsgBox("Kode '" & TxtKdRecon.Text & "' sudah ada...", MsgBoxStyle.Exclamation, "Error")
                'CbGroup.Focus()
            Else
                SimpanData_Rekon()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SimpanData_Rekon()
        Try
            query = "INSERT INTO r_dfiscor(id_fiscor, id_dfiscor,  nama_dfiscor) VALUES( '" & LblJenis.Text & "', '" & TxtKdRecon.Text & "', '" & TxtUraian.Text & "');"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            MsgBox("Data ref rekonsiliasi baru tersimpan", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Pesan")
            'Return query
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TSBAdd_Click(sender As Object, e As EventArgs) Handles TSBAdd.Click
        Try

            CbJenis.Enabled = True
            't.Enabled = True
            TxtKdRecon.Enabled = True
            TSBSave.Enabled = True
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            BersihkanIsian()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BersihkanIsian()
        CbJenis.Text = ""
        LblJenis.Text = ""
        TxtKdRecon.Text = ""
        TxtUraian.Text = ""
    End Sub

    Private Sub TSBEdit_Click(sender As Object, e As EventArgs) Handles TSBEdit.Click
        Dim A As String

        'If mPosted = "UnPosted" Then
        A = MsgBox("Benar akan di-Edit", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Informasi Edit")
        Select Case A
            Case vbCancel
                CbJenis.Focus()
                TSBEdit.Text = "&Edit"
                TSBSave.Enabled = True
                TSBAdd.Enabled = True
                BersihkanIsian()

                Exit Sub
            Case vbOK
                Try
                    EditFiscor()
                    IsiList()
                    BersihkanIsian()
                    TSBEdit.Text = "&Edit"
                    TSBSave.Enabled = True
                    TSBAdd.Enabled = True

                Catch ex As Exception
                    MsgBox("Terjadi kesalahan")
                End Try
        End Select
    End Sub

    Private Sub EditFiscor()
        Try
            If CbJenis.Text = "" Then
                MessageBox.Show("Group tidak boleh kosong", "warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                CbJenis.Focus()
            Else
                If TxtKdRecon.Text = "" Then
                    MsgBox("Kode rekon tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                    TxtKdRecon.Focus()
                Else

                    If TxtUraian.Text = "" Then
                        MsgBox("Uraian akun tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                        TxtUraian.Focus()
                    Else
                        query = "UPDATE r_dfiscor SET nama_dfiscor = '" & TxtUraian.Text & "' WHERE id_dfiscor = '" & TxtKdRecon.Text & "';"
                        daData = New OdbcDataAdapter(query, conn)
                            dsData = New DataSet
                            daData.Fill(dsData)
                            MsgBox("Data updated", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Pesan")

                    End If
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub LVFisrec_Click(sender As Object, e As EventArgs) Handles LVFisrec.Click
        CbJenis.Enabled = False
        'CbKel.Enabled = False
        TxtKdRecon.Enabled = False
        TSBSave.Enabled = False
        TSBEdit.Enabled = True
        TSBDelete.Enabled = True
    End Sub

    Private Sub LVFisrec_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVFisrec.SelectedIndexChanged
        Try
            AmbilDataListFiscor()
            CbJenis.Enabled = False
            'CbKel.Enabled = False
            TxtKdRecon.Enabled = False
            TSBSave.Enabled = False
            TSBEdit.Enabled = True
            TSBDelete.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AmbilDataListFiscor()
        Try
            With LVFisrec.SelectedItems
                Try
                    LblJenis.Text = .Item(0).SubItems(0).Text
                    CbJenis.Text = .Item(0).SubItems(1).Text
                    'LblKel.Text = .Item(0).SubItems(2).Text
                    'CbKel.Text = .Item(0).SubItems(3).Text
                    TxtKdRecon.Text = .Item(0).SubItems(2).Text
                    TxtUraian.Text = .Item(0).SubItems(3).Text
                Catch ex As Exception

                End Try
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBDelete_Click(sender As Object, e As EventArgs) Handles TSBDelete.Click
        Dim A As String

        'If mPosted = "UnPosted" Then
        Try
            If Len(TxtKdRecon.Text) = 0 Then
                MsgBox("Pilih data yang dihapus", MsgBoxStyle.Information, "Informasi hapus")
                TxtKdRecon.Enabled = True
                TxtKdRecon.Focus()
                TSBSave.Enabled = True
                TSBAdd.Enabled = True
                Exit Sub
            Else

                'untuk menghapus record jurnal
                A = MsgBox("Benar akan dihapus...", MsgBoxStyle.OkCancel, "Informasi")
                Select Case A
                    Case vbCancel
                        TxtKdRecon.Focus()
                        TSBEdit.Text = "&Edit"
                        TSBAdd.Text = "&New Item"
                        TxtKdRecon.Enabled = True
                        TSBSave.Enabled = True
                        TSBAdd.Enabled = True
                        Exit Sub
                    Case vbOK
                        HapusFiscor()
                        'HapusIsiOMDetail()
                        IsiList()
                        BersihkanIsian()
                        TxtKdRecon.Focus()

                        TSBEdit.Text = "&Edit"
                        TSBAdd.Text = "&New Item"
                        TxtKdRecon.Enabled = True
                        TSBSave.Enabled = True
                        TSBAdd.Enabled = True
                End Select
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Perhatian")
        End Try

    End Sub

    Private Sub HapusFiscor()
        Try

            query = "DELETE FROM r_dfiscor WHERE id_dfiscor = '" & TxtKdRecon.Text & "'"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            MsgBox("Data deleted", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Pesan")

        Catch ex As Exception

        End Try
    End Sub
End Class