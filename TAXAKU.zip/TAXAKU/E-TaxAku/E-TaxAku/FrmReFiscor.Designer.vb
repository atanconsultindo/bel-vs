﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmReFiscor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmReFiscor))
        Me.BtnClose = New System.Windows.Forms.Button()
        Me.TSBCancel = New System.Windows.Forms.ToolStripButton()
        Me.TxtKdRecon = New System.Windows.Forms.TextBox()
        Me.LblJenis = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtUraian = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TSBDelete = New System.Windows.Forms.ToolStripButton()
        Me.TSBEdit = New System.Windows.Forms.ToolStripButton()
        Me.CbJenis = New System.Windows.Forms.ComboBox()
        Me.TSBSave = New System.Windows.Forms.ToolStripButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.TSBAdd = New System.Windows.Forms.ToolStripButton()
        Me.TSBPrint = New System.Windows.Forms.ToolStripButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LVFisrec = New System.Windows.Forms.ListView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Panel1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnClose
        '
        Me.BtnClose.BackColor = System.Drawing.SystemColors.Control
        Me.BtnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClose.Image = CType(resources.GetObject("BtnClose.Image"), System.Drawing.Image)
        Me.BtnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnClose.Location = New System.Drawing.Point(415, 589)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(73, 25)
        Me.BtnClose.TabIndex = 135
        Me.BtnClose.Text = "&Close"
        Me.BtnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnClose.UseVisualStyleBackColor = False
        '
        'TSBCancel
        '
        Me.TSBCancel.Image = CType(resources.GetObject("TSBCancel.Image"), System.Drawing.Image)
        Me.TSBCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCancel.Name = "TSBCancel"
        Me.TSBCancel.Size = New System.Drawing.Size(63, 22)
        Me.TSBCancel.Text = "Cancel"
        '
        'TxtKdRecon
        '
        Me.TxtKdRecon.Location = New System.Drawing.Point(145, 41)
        Me.TxtKdRecon.MaxLength = 2
        Me.TxtKdRecon.Name = "TxtKdRecon"
        Me.TxtKdRecon.Size = New System.Drawing.Size(553, 20)
        Me.TxtKdRecon.TabIndex = 33
        '
        'LblJenis
        '
        Me.LblJenis.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.LblJenis.Location = New System.Drawing.Point(704, 13)
        Me.LblJenis.Name = "LblJenis"
        Me.LblJenis.Size = New System.Drawing.Size(109, 20)
        Me.LblJenis.TabIndex = 29
        Me.LblJenis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(82, 67)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 13)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Uraian:"
        '
        'TxtUraian
        '
        Me.TxtUraian.Location = New System.Drawing.Point(145, 67)
        Me.TxtUraian.Name = "TxtUraian"
        Me.TxtUraian.Size = New System.Drawing.Size(553, 20)
        Me.TxtUraian.TabIndex = 24
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(53, 41)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Kode Rekon:"
        '
        'TSBDelete
        '
        Me.TSBDelete.Image = CType(resources.GetObject("TSBDelete.Image"), System.Drawing.Image)
        Me.TSBDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDelete.Name = "TSBDelete"
        Me.TSBDelete.Size = New System.Drawing.Size(60, 22)
        Me.TSBDelete.Text = "Delete"
        '
        'TSBEdit
        '
        Me.TSBEdit.Image = CType(resources.GetObject("TSBEdit.Image"), System.Drawing.Image)
        Me.TSBEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEdit.Name = "TSBEdit"
        Me.TSBEdit.Size = New System.Drawing.Size(47, 22)
        Me.TSBEdit.Text = "Edit"
        '
        'CbJenis
        '
        Me.CbJenis.FormattingEnabled = True
        Me.CbJenis.Location = New System.Drawing.Point(145, 10)
        Me.CbJenis.Name = "CbJenis"
        Me.CbJenis.Size = New System.Drawing.Size(553, 21)
        Me.CbJenis.TabIndex = 34
        '
        'TSBSave
        '
        Me.TSBSave.Image = CType(resources.GetObject("TSBSave.Image"), System.Drawing.Image)
        Me.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSave.Name = "TSBSave"
        Me.TSBSave.Size = New System.Drawing.Size(51, 22)
        Me.TSBSave.Text = "Save"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(34, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 13)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Jenis Perbedaan:"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.CbJenis)
        Me.Panel1.Controls.Add(Me.TxtKdRecon)
        Me.Panel1.Controls.Add(Me.LblJenis)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.TxtUraian)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(6, 14)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(827, 114)
        Me.Panel1.TabIndex = 137
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBAdd, Me.TSBSave, Me.TSBEdit, Me.TSBDelete, Me.TSBCancel, Me.TSBPrint})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(901, 25)
        Me.ToolStrip1.TabIndex = 136
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'TSBAdd
        '
        Me.TSBAdd.Image = CType(resources.GetObject("TSBAdd.Image"), System.Drawing.Image)
        Me.TSBAdd.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBAdd.Name = "TSBAdd"
        Me.TSBAdd.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TSBAdd.Size = New System.Drawing.Size(49, 22)
        Me.TSBAdd.Text = "Add"
        Me.TSBAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'TSBPrint
        '
        Me.TSBPrint.Image = CType(resources.GetObject("TSBPrint.Image"), System.Drawing.Image)
        Me.TSBPrint.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBPrint.Name = "TSBPrint"
        Me.TSBPrint.Size = New System.Drawing.Size(52, 22)
        Me.TSBPrint.Text = "Print"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LVFisrec)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 176)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(857, 404)
        Me.GroupBox3.TabIndex = 138
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Data Akun Rekonsiliasi Fiskal"
        '
        'LVFisrec
        '
        Me.LVFisrec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LVFisrec.FullRowSelect = True
        Me.LVFisrec.GridLines = True
        Me.LVFisrec.HideSelection = False
        Me.LVFisrec.Location = New System.Drawing.Point(13, 25)
        Me.LVFisrec.MultiSelect = False
        Me.LVFisrec.Name = "LVFisrec"
        Me.LVFisrec.Size = New System.Drawing.Size(839, 365)
        Me.LVFisrec.TabIndex = 0
        Me.LVFisrec.UseCompatibleStateImageBehavior = False
        Me.LVFisrec.View = System.Windows.Forms.View.Details
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Location = New System.Drawing.Point(25, 36)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(839, 134)
        Me.GroupBox1.TabIndex = 139
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Form Isian Referensi Rekonsiliasi Fiskal"
        '
        'FrmReFiscor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 619)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.BtnClose)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.GroupBox3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmReFiscor"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fiscal Adjustment References"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BtnClose As Button
    Friend WithEvents TSBCancel As ToolStripButton
    Friend WithEvents TxtKdRecon As TextBox
    Friend WithEvents LblJenis As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtUraian As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TSBDelete As ToolStripButton
    Friend WithEvents TSBEdit As ToolStripButton
    Friend WithEvents CbJenis As ComboBox
    Friend WithEvents TSBSave As ToolStripButton
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents TSBAdd As ToolStripButton
    Friend WithEvents TSBPrint As ToolStripButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents LVFisrec As ListView
    Friend WithEvents GroupBox1 As GroupBox
End Class
