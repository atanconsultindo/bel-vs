﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Data.Odbc
Public Class FrmCRptPoskeu
    'Private Sub FrmCRptPoskeu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'SetReportDb(My.Settings.ConnectionString, CrystalReportViewer1, rptin)
    '    Dim cryRPT As New ReportDocument
    '    Dim crTableLogOnInfos As New TableLogOnInfos
    '    Dim crTableLogOnInfo As New TableLogOnInfo
    '    Dim crConnectionInfo As New ConnectionInfo
    '    Dim crTables As Tables
    '    Dim crTable As Table

    '    cryRPT.Load(Application.StartupPath + "\RptPosKeu.rpt")
    '    cryRPT.SetDatabaseLogon(dbUID, dbPassword, dbServer, dbDatabase)
    '    With crConnectionInfo
    '        .ServerName = dbServer
    '        .DatabaseName = dbDatabase
    '        .UserID = dbUID
    '        .Password = dbPassword
    '    End With

    '    crTables = cryRPT.Database.Tables
    '    For Each crTable In crTables
    '        crTableLogOnInfo = crTable.LogOnInfo
    '        crTableLogOnInfo.ConnectionInfo = crConnectionInfo
    '        crTable.ApplyLogOnInfo(crTableLogOnInfo)


    '    Next
    '    Me.CrystalReportViewer1.LogOnInfo.Item(0).ConnectionInfo.ServerName = dbServer
    '    Me.CrystalReportViewer1.LogOnInfo.Item(0).ConnectionInfo.DatabaseName = dbDatabase
    '    Me.CrystalReportViewer1.LogOnInfo.Item(0).ConnectionInfo.UserID = dbUID
    '    Me.CrystalReportViewer1.LogOnInfo.Item(0).ConnectionInfo.Password = dbPassword
    '    CrystalReportViewer1.ReportSource = cryRPT
    '    CrystalReportViewer1.Refresh()


    '    '    'CrystalReportViewer1.RefreshReport()

    'End Sub

    'Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs) Handles CrystalReportViewer1.Load
    '    'SetReportDb(My.Settings.ConnectionString, CrystalReportViewer1, RptPosKeu1)
    'End Sub
End Class