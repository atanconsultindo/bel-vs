﻿Imports System.Data.Odbc
Public Class FrmOB
    Private mPeriode As String
    Private mTglTransaksi As Date
    Private mKeterangan As String
    Private mNoPerkiraan As String
    Private DK As String
    Private mDebet As Long
    Private mKredit As Long
    Public mPosted As String
    Public mDK As String
    Dim mNoTransaksi As String
    Dim mJumlah As Long
    Private Sub PosisiListMasJU()
        Try
            With LVJU.Columns
                .Add("No", 40)
                '.Add("Tanggal", 100)
                .Add("No. Akun", 90)
                .Add("Nama Akun", 150)
                .Add("DK", 0)
                .Add("Nilai", 125, HorizontalAlignment.Right)
                .Add("Kredit", 125, HorizontalAlignment.Right)
            End With
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub

    Sub IsiListMasJU()
        Dim a As Integer
        Try
            str = "SELECT ta_djurnal.no_urut, ta_djurnal.id_akun3, akun3.nama_akun3,  ta_djurnal.dk, ta_djurnal.debet, ta_djurnal.kredit  " &
                    " FROM ta_djurnal LEFT JOIN ta_hjurnal ON ta_djurnal.no_bukti = ta_hjurnal.no_bukti " &
                    " LEFT JOIN akun3 ON ta_djurnal.id_akun3 = akun3.id_akun3 " &
                    " WHERE(((ta_djurnal.no_bukti) = '" & TxtNoBukti.Text & "'))" &
                    " GROUP BY ta_djurnal.no_bukti, ta_djurnal.no_urut" &
                    " ORDER BY ta_djurnal.no_urut; "

            'query = "SELECT dJurnal.NoTransaksi, dJurnal.NoPerkiraan, tblMasterPerkiraan.NamaPerkiraan, dJurnal.DK, dJurnal.Debet, dJurnal.Kredit FROM (dJurnal LEFT JOIN ta_hjurnal ON dJurnal.NoTransaksi = ta_hjurnal.no_bukti) LEFT JOIN tblMasterPerkiraan ON dJurnal.NoPerkiraan = tblMasterPerkiraan.NoPerkiraan WHERE(((dJurnal.NoTransaksi) = '" & txtNobukti.Text & "'))"
            daData = New OdbcDataAdapter(str, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVJU.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVJU
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(4), "#,00"))
                    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(5), "#,00"))

                    'If Not IsDBNull(dsData.Tables(0).Rows(a).Item(0)) Then
                    '    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    'End If
                    'If Not IsDBNull(dsData.Tables(0).Rows(a).Item(1)) Then
                    '    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    'End If
                    'If Not IsDBNull(dsData.Tables(0).Rows(a).Item(2)) Then
                    '    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    'End If
                    'If Not IsDBNull(dsData.Tables(0).Rows(a).Item(3)) Then
                    '    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    'End If
                    'If Not IsDBNull(dsData.Tables(0).Rows(a).Item(4)) Then
                    '    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(4), "###,##0"))
                    'End If
                    'If Not IsDBNull(dsData.Tables(0).Rows(a).Item(5)) Then
                    '    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(5), "###,##0"))
                    'End If

                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.Orange
                    End If
                    'Else
                    '    MsgBox("No Data", MsgBoxStyle.OkOnly, "Pesan")
                    'End If
                End With
            Next


        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "No Data")
        End Try
    End Sub

    Private Sub NoTransaksi()
        Try
            Dim mMemoriNo As String
            Dim mTempNoTransaksi As String

            mMemoriNo = Format(Microsoft.VisualBasic.Right(Now.Year, 2)) & Format(Now.Month, "00") & Format(Now.Day, "00")
            TxtNoBukti.Text = "OB-" & mMemoriNo & "000"
            query = "SELECT Count(ta_hjurnal.no_bukti) AS CountOfNoTransaksi FROM(ta_hjurnal) HAVING ((Mid([ta_hjurnal].[no_bukti],4,6)='" & mMemoriNo & "')) AND ([ta_hjurnal].[jt]= 'JC')"

            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            If dsData.Tables(0).Rows.Count = 0 Then
                TxtNoBukti.Text = "OB-" & mMemoriNo + "000" + dsData.Tables(0).Rows(0).Item(0) + 1
                mTempNoTransaksi = "OB-" & mMemoriNo + "000" + dsData.Tables(0).Rows(0).Item(0) + 1
            Else
                TxtNoBukti.Text = "OB-" & mMemoriNo + "000" + dsData.Tables(0).Rows(0).Item(0) + 1
                mTempNoTransaksi = "OB-" & mMemoriNo + "000" + dsData.Tables(0).Rows(0).Item(0) + 1
            End If

            query = "SELECT ta_hjurnal.no_bukti, Count(ta_hjurnal.no_bukti) AS Jumlah FROM ta_hjurnal GROUP BY ta_hjurnal.no_bukti HAVING (((ta_hjurnal.no_bukti)='" & TxtNoBukti.Text & "')) AND AND ([ta_hjurnal].[jt]= 'JC')"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            If dsData.Tables(0).Rows.Count = 0 Then
                TxtNoBukti.Text = mTempNoTransaksi
            Else
                TxtNoBukti.Text = Microsoft.VisualBasic.Mid(TxtNoBukti.Text, 1, 3) & Val(Microsoft.VisualBasic.Mid(TxtNoBukti.Text, 4, 9)) + 1
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub CariPeriode()
        Try
            query = "SELECT r_perush.tahun FROM(r_perush)"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            If dsData.Tables(0).Rows.Count - 1 Then
                MsgBox("Periode belum ada, silahkan buat periode di master periode...", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                Dispose()
            Else
                lblPeriode.Text = dsData.Tables(0).Rows(0).Item(0)
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub TSBTambah_Click(sender As Object, e As EventArgs) Handles TSBTambah.Click
        Try
            BersihkanIsianJU()
            LVJU.Items.Clear()
            TxtNoBukti.Focus()
            'IsiListBeriKredit()
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            TSBSave.Enabled = True
            BtnAdd.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBSave_Click(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            If TxtNoBukti.Text = "" Then
                MessageBox.Show("No Bukti tidak boleh kosong", "warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TxtNoBukti.Focus()
            Else
                If CbJasa.Text = "" Then
                    MsgBox("Jenis Jasa tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                    CbJasa.Focus()
                Else
                    If TxtKetJU.Text = "" Then
                        MsgBox("Keterangan tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                        TxtKetJU.Focus()
                    Else
                        Dim tanya As String
                        If Val(Me.LblBalance.Text) <> 0 Then
                            tanya = MsgBox("Total DEBET tidak sama dengan Total KREDIT: Tetap Mau Lanjutkan....?",
                          MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Peringatan")
                            '<-- Membuat logika jika benar mau menutup aplikasi maka tutup aplikasi
                            If tanya = vbCancel Then
                                TxtNoBukti.Focus()

                                BersihkanIsianGrid()
                            Else
                                AdaNoTransaksi()
                                DateTPJU.Focus()
                                'Dispose()
                            End If
                        Else
                            Dispose()
                        End If
                    End If
                End If

            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub AdaNoTransaksi()
        Try
            query = "SELECT no_bukti FROM ta_hjurnal WHERE no_bukti = '" & TxtNoBukti.Text & "'"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            If dsData.Tables(0).Rows.Count - 1 Then
                MsgBox("Belum ada transksi jurnal....", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan simpan data")
                TxtNo.Focus()
            Else
                PeriksaDataNoTransaksi()
                BersihkanIsianJU()
                BersihkanIsianGrid()
                NoTransaksi()
                LVJU.Clear()
                PosisiListMasJU()
                IsiListMasJU()
                TSBEdit.Text = "&Edit"
                TSBTambah.Text = "&New Item"
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub BersihkanIsianJU()
        DateTPJU.Value = Now()
        TxtKetJU.Clear()

        'NoTransaksi()
        TxtNo.Clear()
        CbAkun.Text = ""
        LblAkun.Text = ""
        TxtDebet.Text = "0"
        TxtKredit.Text = "0"
        TxtNo.Focus()
        DateTPJU.Focus()

    End Sub
    Private Sub BersihkanIsianGrid()
        'NoTransaksi()
        TxtNo.Clear()
        CbAkun.Text = ""
        TxtDebet.Text = "0"
        TxtKredit.Text = "0"
        TxtNo.Focus()

    End Sub

    Private Sub TSBEdit_Click(sender As Object, e As EventArgs) Handles TSBEdit.Click
        Dim A As String

        'If mPosted = "UnPosted" Then
        A = MsgBox("Benar akan di-Edit", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Informasi Edit")
        Select Case A
            Case vbCancel
                TxtNoBukti.Focus()
                TSBEdit.Text = "&Edit"
                TSBSave.Enabled = True
                BtnAdd.Enabled = True
                BersihkanIsianGrid()
                Exit Sub
            Case vbOK
                Try
                    If TxtNo.Text = "" Then
                        EditDataHJurnal() 'EditHJurnal
                        JumlahDebetKredit()
                        TSBEdit.Text = "&Edit"
                        TSBSave.Enabled = True
                        BtnAdd.Enabled = True
                    Else
                        EditJurnalGrid()
                        TSBEdit.Text = "&Edit"
                        TSBSave.Enabled = True
                        BtnAdd.Enabled = True
                    End If
                Catch ex As Exception
                    MsgBox("Terjadi kesalahan")
                End Try
        End Select
        'Else
        '    MsgBox("Data ini sudah diposting, tidak bisa di Edit", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan edit")
        '    TSBEdit.Text = "&Edit"
        '    TSBSave.Enabled = True
        '    BersihkanIsianGrid()
        'End If
    End Sub

    Private Sub CariDataNoTransaksi()
        Try
            query = "SELECT ta_hjurnal.periode, ta_hJurnal.tgl_trans, ta_hJurnal.no_bukti, ta_hJurnal.Keterangan, ta_hJurnal.Status FROM(ta_hJurnal) GROUP BY ta_hJurnal.Periode, ta_hJurnal.tgl_trans, ta_hJurnal.bo_bukti, ta_hJurnal.Keterangan, ta_hJurnal.Status HAVING(((ta_hJurnal.no_bukti) = '" & TxtNoBukti.Text & "')) ORDER BY ta_hJurnal.Periode, ta_hJurnal.tgl_trans, ta_hJurnal.no_bukti, ta_hJurnal.Keterangan, ta_hJurnal.Status"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            If dsData.Tables(0).Rows.Count - 1 Then
                BersihkanIsianJU()
                DateTPJU.Focus()
                LVJU.Clear()
                PosisiListMasJU()
                IsiListMasJU()
            Else
                lblPeriode.Text = dsData.Tables(0).Rows(0).Item(0)
                DateTPJU.Text = dsData.Tables(0).Rows(0).Item(1)
                TxtNoBukti.Text = dsData.Tables(0).Rows(0).Item(2)
                TxtKetJU.Text = dsData.Tables(0).Rows(0).Item(3)
                mPosted = dsData.Tables(0).Rows(0).Item(4)

                IsiListMasJU()
                JumlahDebetKredit()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Public Function EditDataHJurnal()
        Try
            mNoTransaksi = TxtNoBukti.Text
            mTglTransaksi = Format(DateTPJU.Value, "yyyy-MM-dd")
            'Format(DateTPJU.Value, "yyyy-MM-dd")
            mKeterangan = TxtKetJU.Text


            query = "UPDATE ta_hjurnal SET  tgl_trans = '" & Format(DateTPJU.Value, "yyyy-MM-dd") & "', Keterangan = '" & mKeterangan & "', id_djt = '" & LblJasa.Text & "' WHERE no_bukti = '" & mNoTransaksi & "' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            Return query
        Catch ex As Exception
            Return 0
        End Try
    End Function

    Private Sub EditJurnalGrid()
        Try
            EditDataHJurnal() 'edit hJurnal

            If TxtDebet.Text > 0 Then
                mDK = "D"
            Else
                mDK = "K"
            End If
            EditData() 'edit dJurnal
            'EditDataOM() 'edit ta_om
            IsiListMasJU()
            BersihkanIsianGrid()
            TxtNo.Enabled = True
            TxtNoBukti.Enabled = True
            JumlahDebetKredit()
        Catch ex As Exception
        End Try
    End Sub



    Public Function EditData()
        Try
            DK = mDK
            mDebet = TxtDebet.Text
            mKredit = TxtKredit.Text
            mNoTransaksi = TxtNoBukti.Text
            mNoPerkiraan = TxtNo.Text

            query = "UPDATE ta_djurnal SET  DK = '" & DK & "', Debet = '" & mDebet & "', Kredit = '" & mKredit & "' WHERE no_bukti = '" & mNoTransaksi & "' AND no_urut = '" & mNoPerkiraan & "'"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            Return query
        Catch ex As Exception
            Return 0
        End Try
    End Function

    Private Sub EditDataOM()
        Try

            DK = mDK
            mDebet = TxtDebet.Text
            mKredit = TxtKredit.Text
            mNoTransaksi = TxtNoBukti.Text
            mNoPerkiraan = TxtNo.Text

            query = "UPDATE ta_om SET  tgl_trans = '" & Format(DateTPJU.Value, "yyyy-MM-dd") & "',  id_akun3 = '" & LblAkun.Text & "', Debet = '" & mDebet & "', Kredit = '" & mKredit & "' WHERE no_bukti = '" & mNoTransaksi & "' AND no_urut = '" & mNoPerkiraan & "'"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            'Return query
        Catch ex As Exception
            'Return 0
        End Try

    End Sub


    Private Sub TSBDelete_Click(sender As Object, e As EventArgs) Handles TSBDelete.Click
        Dim A As String

        'If mPosted = "UnPosted" Then
        Try
            If Len(TxtNoBukti.Text) = 0 Then
                MsgBox("Pilih data yang dihapus", MsgBoxStyle.Information, "Informasi hapus")
                TxtNo.Enabled = True
                TxtNo.Focus()
                TSBSave.Enabled = True
                BtnAdd.Enabled = True
                Exit Sub
            Else
                If TxtNo.Text = "" Then
                    'hapus semua transaksi dengan no transksi yang sesuai dengan no.transaksi
                    A = MsgBox("Benar akan dihapus...", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Informasi")
                    Select Case A
                        Case vbCancel
                            TxtNo.Focus()
                            TSBEdit.Text = "&Edit"
                            TSBTambah.Text = "&New Item"
                            TxtNo.Enabled = True
                            TSBSave.Enabled = True
                            BtnAdd.Enabled = True
                            Exit Sub
                        Case vbOK
                            'Hapus hJurnal
                            HapusDataHJurnal()
                            'Hapus dJurnal
                            HapusData()
                            BersihkanIsianJU()
                            BersihkanIsianGrid()
                            LVJU.Clear()
                            PosisiListMasJU()
                            IsiListMasJU()
                            DateTPJU.Focus()
                            NoTransaksi()
                            JumlahDebetKredit()
                            TSBEdit.Text = "&Edit"
                            TSBTambah.Text = "&New Item"
                            TxtNo.Enabled = True
                            TSBSave.Enabled = True
                            BtnAdd.Enabled = True
                    End Select
                Else
                    'untuk menghapus record jurnal
                    A = MsgBox("Benar akan dihapus...", MsgBoxStyle.OkCancel, "Informasi")
                    Select Case A
                        Case vbCancel
                            TxtNo.Focus()
                            TSBEdit.Text = "&Edit"
                            TSBTambah.Text = "&New Item"
                            TxtNo.Enabled = True
                            TSBSave.Enabled = True
                            BtnAdd.Enabled = True
                            Exit Sub
                        Case vbOK
                            HapusIsiGrid()
                            IsiListMasJU()
                            BersihkanIsianGrid()
                            TxtNo.Focus()
                            JumlahDebetKredit()
                            TSBEdit.Text = "&Edit"
                            TSBTambah.Text = "&New Item"
                            TxtNo.Enabled = True
                            TSBSave.Enabled = True
                            BtnAdd.Enabled = True
                    End Select
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Perhatian")
        End Try
        'Else
        '    MsgBox("Data ini sudah diposting, tidak bisa dihapus...", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Hapus data")
        '    tsbsave.Enabled = True
        'End If
    End Sub

    Public Function HapusDataHJurnal()
        Try
            mNoTransaksi = TxtNoBukti.Text
            query = "DELETE FROM ta_hJurnal WHERE no_bukti = '" & mNoTransaksi & "'"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            Return query
        Catch ex As Exception
            Return 0
        End Try
    End Function

    Public Function HapusData()
        Try
            mNoTransaksi = TxtNoBukti.Text
            query = "DELETE FROM ta_dJurnal WHERE no_bukti = '" & mNoTransaksi & "'"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            Return query
        Catch ex As Exception
            Return 0
        End Try
    End Function

    Private Sub HapusIsiGrid()
        Try
            'Menghapus isi data grid
            'query = "DELETE FROM ta_dJurnal WHERE no_bukti = '" & TxtNoBukti.Text & "' AND no_urut = '" & TxtNo.Text & "' AND DK = '" & mDK & "'"
            query = "DELETE FROM ta_dJurnal WHERE no_bukti = '" & TxtNoBukti.Text & "' AND no_urut = '" & TxtNo.Text & "' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub FrmJU_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PosisiListMasJU()
        Try
            GetDatabaseSetting()

            TxtDebet.Text = "0"
            TxtKredit.Text = "0"
            LblDebet.Text = "0"
            LblKredit.Text = "0"

            CariPeriode()

            PosisiListMasJU()
            IsiListMasJU()
            NoTransaksi()
            'JumlahDebetKredit()
            Akun_load()
            JT_load()

            TSBTambah.Text = "&New Item"
            BtnAdd.Enabled = True
        Catch ex As Exception
        End Try

    End Sub


    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        Try
            If TxtNoBukti.Text = "" Then
                MessageBox.Show("No. Bukti masih kosong", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TxtNoBukti.Focus()
            Else
                If CbJasa.Text = "" Then
                    MessageBox.Show("Jenis Jasa masih kosong", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    CbJasa.Focus()
                Else
                    If TxtKetJU.Text = "" Then
                        MessageBox.Show("Keterangan masih kosong", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        TxtKetJU.Focus()
                    Else
                        If TSBEdit.Text = "&Edit" Then
                            If TxtDebet.Text > 0 Then
                                mDK = "D"
                            Else
                                mDK = "K"
                            End If

                            If TxtDebet.Text = "" Then
                                TxtDebet.Text = 0
                            Else
                                TxtDebet.Text = TxtDebet.Text
                            End If

                            If TxtKredit.Text = "" Then
                                TxtKredit.Text = 0
                            Else
                                TxtKredit.Text = TxtKredit.Text
                            End If

                            PeriksaDataNoTransaksi()
                            SimpanData() 'dJurnal
                            'SimpanDataOM() 'ta_dcr
                            mPosted = "UnPosted"
                            IsiListMasJU()
                            JumlahDebetKredit()
                            MsgBox("Data ditambahkan ke list...", MsgBoxStyle.Information, "Pesan")
                            BersihkanIsianGrid()
                            TxtNoBukti.Focus()
                        Else
                            TSBEdit.Text = "&Edit"
                            'EditJurnalGrid()

                        End If

                    End If


                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub PeriksaDataNoTransaksi()
        Try
            query = "Select ta_hjurnal.periode, ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.status FROM(ta_hjurnal) GROUP BY ta_hjurnal.periode, ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.status HAVING(((ta_hjurnal.no_bukti) = '" & TxtNoBukti.Text & "')) ORDER BY ta_hjurnal.Periode, ta_hjurnal.tgl_trans, ta_hjurnal.no_bukti, ta_hjurnal.Keterangan, ta_hjurnal.Status "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            If dsData.Tables(0).Rows.Count - 1 Then
                'Menyimpan data ke ta_hjurnal
                SimpanData_hjurnal()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub SimpanData_hjurnal()
        Try
            mNoTransaksi = TxtNoBukti.Text
            mPeriode = lblPeriode.Text
            'mTglTransaksi = DateTPJU.Value.Date.ToString("yyyy-MM-dd")
            mTglTransaksi = DateTPJU.Value.Date.ToShortDateString
            mKeterangan = TxtKetJU.Text

            query = "INSERT INTO ta_hjurnal VALUES('" & mNoTransaksi & "', '" & mPeriode & "' , '" & Format(DateTPJU.Value, "yyyy-MM-dd") & "', '" & mKeterangan & "', '" & "UnPosted" & "', '" & LblJasa.Text & "')"
            daData = New OdbcDataAdapter(query, conn)

            dsData = New DataSet
            daData.Fill(dsData)
            'Return query
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub SimpanData()
        Try
            mNoTransaksi = TxtNoBukti.Text
            mNoPerkiraan = LblAkun.Text
            DK = mDK
            mDebet = TxtDebet.Text
            mKredit = TxtKredit.Text

            query = "INSERT INTO ta_djurnal VALUES('" & mNoTransaksi & "', '" & TxtNo.Text & "', '" & mNoPerkiraan & "',  '" & DK & "' , '" & mDebet & "' ,'" & mKredit & "')"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            'frmPerkiraan.IsiList()
            'Return query
        Catch ex As Exception
            MsgBox(ex.Message)
            'MsgBox("Data tidak bisa tersimpan karena NoPerkiraan sudah ada...", MsgBoxStyle.Exclamation, "Error")
            'frmPerkiraan.txtNo.Focus()
            'Return query
        End Try
    End Sub

    Private Sub SimpanDataOM()
        Try
            mNoTransaksi = TxtNoBukti.Text
            mNoPerkiraan = LblAkun.Text
            DK = mDK
            mDebet = TxtDebet.Text
            mKredit = TxtKredit.Text

            query = "INSERT INTO ta_om VALUES('" & mNoTransaksi & "', '" & TxtNo.Text & "', '" & Format(DateTPJU.Value.Date, "yyyy-MM-dd") & "', '" & mNoPerkiraan & "',  '" & LblJasa.Text & "' , '" & mDebet & "' ,'" & mKredit & "', '" & TxtKetJU.Text & "')"
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            'frmPerkiraan.IsiList()
            'Return query
        Catch ex As Exception
            MsgBox(ex.Message)
            'MsgBox("Data tidak bisa tersimpan karena NoPerkiraan sudah ada...", MsgBoxStyle.Exclamation, "Error")
            'frmPerkiraan.txtNo.Focus()
            'Return query
        End Try
    End Sub


    Private Sub TxtDebet_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtDebet.KeyPress
        If e.KeyChar = Chr(13) Then
            If TxtDebet.Text = "" Then
                TxtDebet.Text = 0
                TxtKredit.Focus()
            Else
                TxtKredit.Focus()
            End If
        End If

        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = ".") Then
            e.Handled = True
        End If
    End Sub


    Sub JumlahDebetKredit()
        Try
            query = "SELECT SUM(ta_djurnal.debet) AS SumOfDebet, SUM(ta_djurnal.kredit) AS SumOfKredit" &
                    " FROM ta_djurnal " &
                    " WHERE (ta_djurnal.no_bukti = '" & TxtNoBukti.Text & "') "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LblDebet.Text = Format(dsData.Tables(0).Rows(0).Item(0), "#,#0")
            LblKredit.Text = Format(dsData.Tables(0).Rows(0).Item(1), "#,#0")
            LblBalance.Text = Format(dsData.Tables(0).Rows(0).Item(0), "#,#0") - Format(dsData.Tables(0).Rows(0).Item(1), "#,#0")
        Catch ex As Exception
            MsgBox(ex.Message, 1)
        End Try
    End Sub

    Private Sub JT_load()

        Dim a As Integer
        Try
            query = "SELECT * FROM r_djt WHERE r_djt.id_jt = '5' ORDER BY id_djt "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbJasa.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbJasa
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2)
                    .Items.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Akun_load()

        Dim a As Integer
        Try
            query = "SELECT * FROM akun3 WHERE (`id_akun3` LIKE '1%') OR (`id_akun3` LIKE '2%') OR (`id_akun3` LIKE '3%')  ORDER BY id_akun3  "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbAkun.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbAkun
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2)
                    .Items.Add(dsData.Tables(0).Rows(a).Item(3))
                End With
            Next
        Catch ex As Exception

        End Try

    End Sub

    Private Sub CbAkun_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbAkun.SelectedIndexChanged
        'Dim a As Integer
        Try
            query = "SELECT * FROM akun3 WHERE nama_akun3 = '" & CbAkun.Text & "' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            With dsData.Tables(0).Rows(0)
                LblAkun.Text = .Item(2)
            End With
        Catch ex As Exception
            'MsgBox(ex.Message, "Changer")
        End Try
    End Sub

    Private Sub TxtKredit_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtKredit.KeyPress
        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = ".") Then
            e.Handled = True
        End If
    End Sub

    Private Sub LVJU_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVJU.SelectedIndexChanged
        'Add("No", 40)
        ''.Add("Tanggal", 100)
        '.Add("No. Akun", 90)
        '.Add("Nama Akun", 150)
        '.Add("DK", 0)
        '.Add("Debet", 125, HorizontalAlignment.Right)
        '.Add("Kredit", 125, HorizontalAlignment.Right)
        Try
            AmbilDataListJU()
            TxtNo.Enabled = False
        Catch ex As Exception

        End Try
    End Sub
    Private Sub AmbilDataListJU()
        Try
            With LVJU.SelectedItems
                Try
                    TxtNo.Text = .Item(0).SubItems(0).Text
                    CbAkun.Text = .Item(0).SubItems(1).Text
                    TxtDebet.Text = .Item(0).SubItems(4).Text
                    TxtKredit.Text = .Item(0).SubItems(5).Text
                Catch ex As Exception

                End Try
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BtnCari_Click(sender As Object, e As EventArgs) Handles BtnCari.Click
        '--awal
        'If LblBalance.Text <> "0" Then
        '    MsgBox("Jumlah debet dan kredit tidak seimbang, silahkan periksa", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
        '    TxtNo.Enabled = True
        '    TxtNo.Focus()
        'Else
        '    FrmJUSub.ShowDialog()
        '    TSBEdit.Text = "&Edit"
        '    DateTPJU.Focus()
        '    BersihkanIsianJU()
        '    TSBSave.Enabled = False
        'End If
        '--Awal
        '--modif
        FrmOBSub.ShowDialog()
        TSBEdit.Text = "&Edit"
        DateTPJU.Focus()
        BersihkanIsianGrid()
        TSBSave.Enabled = False
        BtnAdd.Enabled = False

        '--modif

    End Sub

    Private Sub LVJU_DoubleClick(sender As Object, e As EventArgs) Handles LVJU.DoubleClick
        Try
            AmbilDataListJU()
            TxtNoBukti.Enabled = False
            TxtNo.Enabled = False
            TSBEdit.Text = "&Update"
            TSBSave.Enabled = False
            BtnAdd.Enabled = False
        Catch ex As Exception
        End Try
    End Sub

    Private Sub CbJasa_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbJasa.SelectedIndexChanged
        'Dim a As Integer
        Try
            query = "SELECT * FROM r_djt WHERE nama_djt = '" & CbJasa.Text & "' "
            daData = New OdbcDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            With dsData.Tables(0).Rows(0)
                LblJasa.Text = .Item(1)
            End With
        Catch ex As Exception
            'MsgBox(ex.Message, "Changer")
        End Try
    End Sub

    Private Sub cmdKeluar_Click(sender As Object, e As EventArgs) Handles cmdKeluar.Click
        Dim tanya As String
        If Val(Me.LblBalance.Text) <> 0 Then
            tanya = MsgBox("ThenTotal DEBET tidak sama dengan Total KREDIT: Tetap Mau Lanjutkan....?",
          MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Peringatan")
            '<-- Membuat logika jika benar mau menutup aplikasi maka tutup aplikasi
            If tanya = vbCancel Then
                TxtNoBukti.Focus()

                BersihkanIsianGrid()
            Else
                'AdaNoTransaksi()
                'DateTPJU.Focus()
                Dispose()
            End If
        Else
            Dispose()
        End If
    End Sub
End Class