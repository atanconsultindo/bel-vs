﻿Imports System.Data.Odbc

Public Class FrmLogin

    Sub Terbuka()
        FrmMain.BtnUser.Enabled = False
        FrmMain.BtnLogout.Enabled = True
        FrmMain.BtnCCR.Enabled = True
        FrmMain.BtnFOM.Enabled = True
        FrmMain.BtnSawal.Enabled = True
        FrmMain.BtnTax.Enabled = True
        FrmMain.BtnReport.Enabled = True
        FrmMain.BtnJurnal.Enabled = True
        FrmMain.BtnRef.Enabled = True
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        Try
            If txtUser.Text = "" Or txtPass.Text = "" Then
                MsgBox("Kode user dan password tidak boleh kosong")
                txtUser.Focus()
            Else
                Try
                    'If conn.State = ConnectionState.Closed Then conn.Open()

                    Call GetDatabaseSetting()
                    'conn.Open()
                    cmd = New OdbcCommand("SELECT * FROM users WHERE username = '" & txtUser.Text & " ' and password = '" & Kryptografi(txtPass.Text) & "'", conn)
                    dr = cmd.ExecuteReader
                    dr.Read()
                    If dr.HasRows Then
                        MsgBox("Login Sukses, Selamat Datang " & txtUser.Text & "!", MsgBoxStyle.Information, "E-MANSET")
                        Me.Hide()
                        FrmMain.BtnLogout.Enabled = True
                        FrmMain.BtnLogout.ForeColor = Color.White
                        FrmMain.BtnLogout.Text = txtUser.Text
                        FrmMain.ToolStripStatusDriver.Text = dbDriver
                        'FrmMain.ToolStripStatusDriver.Font.Italic
                        FrmMain.ToolStripStatusDriver.ForeColor = Color.DarkOrange
                        FrmMain.ToolStripStatusDb.Text = dbDatabase
                        FrmMain.ToolStripStatusDb.ForeColor = Color.DarkOrange

                        Call terbuka()
                    Else
                        'Munculkan messagebox pesan salah
                        MessageBox.Show("Kombinasi Username  dan Password Salah", "E-MANSET", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        txtUser.Focus()
                    End If

                    'FrmUtama.BtnLogout.Text = CbUser.Text & " - Logout"
                    'FrmUtama.TxtProvider.Text = FrmGetDatabaseSetting.TxtProvider.Text
                    'FrmUtama.TxtDatabase.Text = FrmGetDatabaseSetting.TxtDataSource.Text
                Catch ex As Exception
                    MsgBox(ex.Message, "Pesan satu")
                End Try

            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
        Me.Hide()
    End Sub

    Private Sub BtnSetKon_Click(sender As Object, e As EventArgs) Handles BtnSetKon.Click
        FrmKoneksi.ShowDialog()
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.txtUser.Text = "1"
        Me.txtPass.Text = "1"
    End Sub
End Class