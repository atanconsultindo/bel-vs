﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmReportPer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmReportPer))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GBoxReport = New System.Windows.Forms.GroupBox()
        Me.RbLrFiscal = New System.Windows.Forms.RadioButton()
        Me.RBFisRec = New System.Windows.Forms.RadioButton()
        Me.RBBB = New System.Windows.Forms.RadioButton()
        Me.RBJurnal = New System.Windows.Forms.RadioButton()
        Me.RBLPE = New System.Windows.Forms.RadioButton()
        Me.RBLR = New System.Windows.Forms.RadioButton()
        Me.RBPoskeu = New System.Windows.Forms.RadioButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.DateTPAwal = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LblPeriode = New System.Windows.Forms.Label()
        Me.DateTPAkhir = New System.Windows.Forms.DateTimePicker()
        Me.BtnPilih = New System.Windows.Forms.Button()
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GBoxReport.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.GBoxReport)
        Me.GroupBox1.Controls.Add(Me.Panel2)
        Me.GroupBox1.Controls.Add(Me.BtnPilih)
        Me.GroupBox1.Controls.Add(Me.BtnKeluar)
        Me.GroupBox1.Location = New System.Drawing.Point(38, 29)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(458, 504)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Laporan Keuangan Periodik"
        '
        'GBoxReport
        '
        Me.GBoxReport.Controls.Add(Me.RbLrFiscal)
        Me.GBoxReport.Controls.Add(Me.RBFisRec)
        Me.GBoxReport.Controls.Add(Me.RBBB)
        Me.GBoxReport.Controls.Add(Me.RBJurnal)
        Me.GBoxReport.Controls.Add(Me.RBLPE)
        Me.GBoxReport.Controls.Add(Me.RBLR)
        Me.GBoxReport.Controls.Add(Me.RBPoskeu)
        Me.GBoxReport.Location = New System.Drawing.Point(48, 108)
        Me.GBoxReport.Margin = New System.Windows.Forms.Padding(4)
        Me.GBoxReport.Name = "GBoxReport"
        Me.GBoxReport.Padding = New System.Windows.Forms.Padding(4)
        Me.GBoxReport.Size = New System.Drawing.Size(375, 341)
        Me.GBoxReport.TabIndex = 34
        Me.GBoxReport.TabStop = False
        Me.GBoxReport.Text = "Pilih Jenis Laporan"
        '
        'RbLrFiscal
        '
        Me.RbLrFiscal.AutoSize = True
        Me.RbLrFiscal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RbLrFiscal.Location = New System.Drawing.Point(51, 126)
        Me.RbLrFiscal.Margin = New System.Windows.Forms.Padding(4)
        Me.RbLrFiscal.Name = "RbLrFiscal"
        Me.RbLrFiscal.Size = New System.Drawing.Size(133, 21)
        Me.RbLrFiscal.TabIndex = 6
        Me.RbLrFiscal.TabStop = True
        Me.RbLrFiscal.Text = "Laba Rugi Fiskal"
        Me.RbLrFiscal.UseVisualStyleBackColor = True
        '
        'RBFisRec
        '
        Me.RBFisRec.AutoSize = True
        Me.RBFisRec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBFisRec.Location = New System.Drawing.Point(51, 202)
        Me.RBFisRec.Margin = New System.Windows.Forms.Padding(4)
        Me.RBFisRec.Name = "RBFisRec"
        Me.RBFisRec.Size = New System.Drawing.Size(143, 21)
        Me.RBFisRec.TabIndex = 5
        Me.RBFisRec.TabStop = True
        Me.RBFisRec.Text = "Rekonsiliasi Fiskal"
        Me.RBFisRec.UseVisualStyleBackColor = True
        '
        'RBBB
        '
        Me.RBBB.AutoSize = True
        Me.RBBB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBBB.Location = New System.Drawing.Point(51, 278)
        Me.RBBB.Margin = New System.Windows.Forms.Padding(4)
        Me.RBBB.Name = "RBBB"
        Me.RBBB.Size = New System.Drawing.Size(101, 21)
        Me.RBBB.TabIndex = 4
        Me.RBBB.TabStop = True
        Me.RBBB.Text = "Buku Besar"
        Me.RBBB.UseVisualStyleBackColor = True
        '
        'RBJurnal
        '
        Me.RBJurnal.AutoSize = True
        Me.RBJurnal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBJurnal.Location = New System.Drawing.Point(51, 240)
        Me.RBJurnal.Margin = New System.Windows.Forms.Padding(4)
        Me.RBJurnal.Name = "RBJurnal"
        Me.RBJurnal.Size = New System.Drawing.Size(71, 21)
        Me.RBJurnal.TabIndex = 3
        Me.RBJurnal.TabStop = True
        Me.RBJurnal.Text = "Jurnal "
        Me.RBJurnal.UseVisualStyleBackColor = True
        '
        'RBLPE
        '
        Me.RBLPE.AutoSize = True
        Me.RBLPE.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBLPE.Location = New System.Drawing.Point(51, 164)
        Me.RBLPE.Margin = New System.Windows.Forms.Padding(4)
        Me.RBLPE.Name = "RBLPE"
        Me.RBLPE.Size = New System.Drawing.Size(184, 21)
        Me.RBLPE.TabIndex = 2
        Me.RBLPE.TabStop = True
        Me.RBLPE.Text = "Laba Perubahan Ekuitas"
        Me.RBLPE.UseVisualStyleBackColor = True
        '
        'RBLR
        '
        Me.RBLR.AutoSize = True
        Me.RBLR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBLR.Location = New System.Drawing.Point(51, 88)
        Me.RBLR.Margin = New System.Windows.Forms.Padding(4)
        Me.RBLR.Name = "RBLR"
        Me.RBLR.Size = New System.Drawing.Size(154, 21)
        Me.RBLR.TabIndex = 1
        Me.RBLR.TabStop = True
        Me.RBLR.Text = "Laba Rugi Komersiil"
        Me.RBLR.UseVisualStyleBackColor = True
        '
        'RBPoskeu
        '
        Me.RBPoskeu.AutoSize = True
        Me.RBPoskeu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBPoskeu.Location = New System.Drawing.Point(51, 50)
        Me.RBPoskeu.Margin = New System.Windows.Forms.Padding(4)
        Me.RBPoskeu.Name = "RBPoskeu"
        Me.RBPoskeu.Size = New System.Drawing.Size(134, 21)
        Me.RBPoskeu.TabIndex = 0
        Me.RBPoskeu.TabStop = True
        Me.RBPoskeu.Text = "Posisi Keuangan"
        Me.RBPoskeu.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.DateTPAwal)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.LblPeriode)
        Me.Panel2.Controls.Add(Me.DateTPAkhir)
        Me.Panel2.Location = New System.Drawing.Point(48, 26)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(375, 71)
        Me.Panel2.TabIndex = 33
        '
        'DateTPAwal
        '
        Me.DateTPAwal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTPAwal.Location = New System.Drawing.Point(102, 2)
        Me.DateTPAwal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DateTPAwal.Name = "DateTPAwal"
        Me.DateTPAwal.Size = New System.Drawing.Size(140, 22)
        Me.DateTPAwal.TabIndex = 30
        '
        'Label1
        '
        Me.Label1.ForeColor = System.Drawing.Color.IndianRed
        Me.Label1.Location = New System.Drawing.Point(21, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 23)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "Sampai:"
        '
        'LblPeriode
        '
        Me.LblPeriode.BackColor = System.Drawing.Color.Transparent
        Me.LblPeriode.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblPeriode.ForeColor = System.Drawing.Color.Maroon
        Me.LblPeriode.Location = New System.Drawing.Point(21, 4)
        Me.LblPeriode.Name = "LblPeriode"
        Me.LblPeriode.Size = New System.Drawing.Size(97, 23)
        Me.LblPeriode.TabIndex = 29
        Me.LblPeriode.Text = "Dari:"
        '
        'DateTPAkhir
        '
        Me.DateTPAkhir.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTPAkhir.Location = New System.Drawing.Point(103, 39)
        Me.DateTPAkhir.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DateTPAkhir.Name = "DateTPAkhir"
        Me.DateTPAkhir.Size = New System.Drawing.Size(140, 22)
        Me.DateTPAkhir.TabIndex = 31
        '
        'BtnPilih
        '
        Me.BtnPilih.Image = Global.E_TaxAku.My.Resources.Resources.onebit_34___Copy
        Me.BtnPilih.Location = New System.Drawing.Point(66, 457)
        Me.BtnPilih.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnPilih.Name = "BtnPilih"
        Me.BtnPilih.Size = New System.Drawing.Size(100, 31)
        Me.BtnPilih.TabIndex = 27
        Me.BtnPilih.Text = "Pilih"
        Me.BtnPilih.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnPilih.UseVisualStyleBackColor = True
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Image = CType(resources.GetObject("BtnKeluar.Image"), System.Drawing.Image)
        Me.BtnKeluar.Location = New System.Drawing.Point(260, 457)
        Me.BtnKeluar.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(100, 31)
        Me.BtnKeluar.TabIndex = 26
        Me.BtnKeluar.Text = "Close"
        Me.BtnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'FrmReportPer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(574, 545)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmReportPer"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Reporting"
        Me.GroupBox1.ResumeLayout(False)
        Me.GBoxReport.ResumeLayout(False)
        Me.GBoxReport.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BtnPilih As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents DateTPAwal As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents LblPeriode As Label
    Friend WithEvents DateTPAkhir As DateTimePicker
    Friend WithEvents BtnKeluar As Button
    Friend WithEvents GBoxReport As GroupBox
    Friend WithEvents RbLrFiscal As RadioButton
    Friend WithEvents RBFisRec As RadioButton
    Friend WithEvents RBBB As RadioButton
    Friend WithEvents RBJurnal As RadioButton
    Friend WithEvents RBLPE As RadioButton
    Friend WithEvents RBLR As RadioButton
    Friend WithEvents RBPoskeu As RadioButton
End Class
