﻿Module ModKrypto
    'Option Compare Database
    '<-- Membuat variabel Array 1 Dimensi dengan batas ruang 0 - 49
    Public Akses(49) As String
    Function Kryptografi(ByVal Teks As String) As String
        Dim textlength As Integer
        Dim textnew, Karakter As String
        Karakter = ""
        textnew = ""
        textlength = Len(Teks)
        For i = 1 To textlength
            Karakter = Mid(Teks, i, 1)
            Select Case Asc(Karakter)
                Case 65 To 90
                    Karakter = Chr(Asc(Karakter) + 100)
                Case 97 To 122
                    Karakter = Chr(Asc(Karakter) + 100)
                Case 48 To 57
                    Karakter = Chr(Asc(Karakter) + 100)
                Case 32
            End Select
            textnew = textnew + Karakter

        Next
        Kryptografi = textnew


    End Function

End Module
