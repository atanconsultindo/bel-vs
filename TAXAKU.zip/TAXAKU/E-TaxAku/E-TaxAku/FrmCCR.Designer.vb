﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCCR
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCCR))
        Me.LblJasa = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CbJasa = New System.Windows.Forms.ComboBox()
        Me.lblPeriode = New System.Windows.Forms.Label()
        Me.DateTPJU = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtKetJU = New System.Windows.Forms.TextBox()
        Me.TxtNoBukti = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.LblDebet = New System.Windows.Forms.Label()
        Me.LblKredit = New System.Windows.Forms.Label()
        Me.LblBalance = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LblAkun = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TxtKredit = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TxtNo = New System.Windows.Forms.TextBox()
        Me.TxtDebet = New System.Windows.Forms.TextBox()
        Me.CbAkun = New System.Windows.Forms.ComboBox()
        Me.LVJU = New System.Windows.Forms.ListView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cmdPreview = New System.Windows.Forms.Button()
        Me.cmdKeluar = New System.Windows.Forms.Button()
        Me.TSBTambah = New System.Windows.Forms.ToolStripButton()
        Me.TSBSave = New System.Windows.Forms.ToolStripButton()
        Me.TSBEdit = New System.Windows.Forms.ToolStripButton()
        Me.TSBDelete = New System.Windows.Forms.ToolStripButton()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.BtnCari = New System.Windows.Forms.Button()
        Me.GroupBox6.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'LblJasa
        '
        Me.LblJasa.Location = New System.Drawing.Point(601, 68)
        Me.LblJasa.Name = "LblJasa"
        Me.LblJasa.Size = New System.Drawing.Size(28, 16)
        Me.LblJasa.TabIndex = 84
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(61, 68)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 13)
        Me.Label5.TabIndex = 79
        Me.Label5.Text = "Jenis Jasa:"
        '
        'CbJasa
        '
        Me.CbJasa.FormattingEnabled = True
        Me.CbJasa.Location = New System.Drawing.Point(140, 65)
        Me.CbJasa.Name = "CbJasa"
        Me.CbJasa.Size = New System.Drawing.Size(455, 21)
        Me.CbJasa.TabIndex = 78
        '
        'lblPeriode
        '
        Me.lblPeriode.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblPeriode.Location = New System.Drawing.Point(662, 14)
        Me.lblPeriode.Name = "lblPeriode"
        Me.lblPeriode.Size = New System.Drawing.Size(75, 23)
        Me.lblPeriode.TabIndex = 47
        Me.lblPeriode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DateTPJU
        '
        Me.DateTPJU.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTPJU.Location = New System.Drawing.Point(140, 41)
        Me.DateTPJU.Name = "DateTPJU"
        Me.DateTPJU.Size = New System.Drawing.Size(489, 20)
        Me.DateTPJU.TabIndex = 46
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(72, 17)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 13)
        Me.Label6.TabIndex = 42
        Me.Label6.Text = "No Bukti"
        '
        'TxtKetJU
        '
        Me.TxtKetJU.Location = New System.Drawing.Point(140, 90)
        Me.TxtKetJU.Name = "TxtKetJU"
        Me.TxtKetJU.Size = New System.Drawing.Size(489, 20)
        Me.TxtKetJU.TabIndex = 39
        '
        'TxtNoBukti
        '
        Me.TxtNoBukti.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtNoBukti.Location = New System.Drawing.Point(140, 17)
        Me.TxtNoBukti.MaxLength = 12
        Me.TxtNoBukti.Name = "TxtNoBukti"
        Me.TxtNoBukti.Size = New System.Drawing.Size(455, 20)
        Me.TxtNoBukti.TabIndex = 38
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(55, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Keterangan:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(71, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Tanggal:"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.LblDebet)
        Me.GroupBox6.Controls.Add(Me.LblKredit)
        Me.GroupBox6.Controls.Add(Me.LblBalance)
        Me.GroupBox6.Controls.Add(Me.Label13)
        Me.GroupBox6.Controls.Add(Me.Label18)
        Me.GroupBox6.Controls.Add(Me.Label14)
        Me.GroupBox6.Location = New System.Drawing.Point(572, 476)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(277, 100)
        Me.GroupBox6.TabIndex = 161
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Summary"
        '
        'LblDebet
        '
        Me.LblDebet.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblDebet.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblDebet.Location = New System.Drawing.Point(144, 20)
        Me.LblDebet.Name = "LblDebet"
        Me.LblDebet.Size = New System.Drawing.Size(125, 20)
        Me.LblDebet.TabIndex = 61
        '
        'LblKredit
        '
        Me.LblKredit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblKredit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblKredit.Location = New System.Drawing.Point(144, 42)
        Me.LblKredit.Name = "LblKredit"
        Me.LblKredit.Size = New System.Drawing.Size(125, 20)
        Me.LblKredit.TabIndex = 65
        '
        'LblBalance
        '
        Me.LblBalance.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblBalance.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblBalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblBalance.Location = New System.Drawing.Point(144, 64)
        Me.LblBalance.Name = "LblBalance"
        Me.LblBalance.Size = New System.Drawing.Size(125, 20)
        Me.LblBalance.TabIndex = 62
        '
        'Label13
        '
        Me.Label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label13.Location = New System.Drawing.Point(6, 20)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(84, 20)
        Me.Label13.TabIndex = 60
        Me.Label13.Text = "Seldo Debet:"
        '
        'Label18
        '
        Me.Label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label18.Location = New System.Drawing.Point(6, 42)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(84, 20)
        Me.Label18.TabIndex = 63
        Me.Label18.Text = "Saldo Kredit:"
        '
        'Label14
        '
        Me.Label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(6, 64)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(84, 20)
        Me.Label14.TabIndex = 64
        Me.Label14.Text = "Balance"
        '
        'ToolStrip2
        '
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBTambah, Me.TSBSave, Me.TSBEdit, Me.TSBDelete})
        Me.ToolStrip2.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(910, 25)
        Me.ToolStrip2.TabIndex = 158
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label9)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.LblAkun)
        Me.GroupBox5.Controls.Add(Me.BtnAdd)
        Me.GroupBox5.Controls.Add(Me.TextBox2)
        Me.GroupBox5.Controls.Add(Me.TxtKredit)
        Me.GroupBox5.Controls.Add(Me.Label10)
        Me.GroupBox5.Controls.Add(Me.TxtNo)
        Me.GroupBox5.Controls.Add(Me.TxtDebet)
        Me.GroupBox5.Controls.Add(Me.CbAkun)
        Me.GroupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox5.Location = New System.Drawing.Point(6, 177)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(850, 76)
        Me.GroupBox5.TabIndex = 160
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Rincian Data Jurnal"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(593, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(34, 13)
        Me.Label9.TabIndex = 86
        Me.Label9.Text = "Kredit"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(431, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 13)
        Me.Label4.TabIndex = 85
        Me.Label4.Text = "Debet"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(121, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 84
        Me.Label3.Text = "Akun "
        '
        'LblAkun
        '
        Me.LblAkun.Location = New System.Drawing.Point(126, 56)
        Me.LblAkun.Name = "LblAkun"
        Me.LblAkun.Size = New System.Drawing.Size(100, 16)
        Me.LblAkun.TabIndex = 83
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Enabled = False
        Me.TextBox2.Location = New System.Drawing.Point(140, 71)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(63, 13)
        Me.TextBox2.TabIndex = 81
        '
        'TxtKredit
        '
        Me.TxtKredit.Location = New System.Drawing.Point(590, 32)
        Me.TxtKredit.Name = "TxtKredit"
        Me.TxtKredit.Size = New System.Drawing.Size(147, 20)
        Me.TxtKredit.TabIndex = 78
        Me.TxtKredit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(72, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(47, 13)
        Me.Label10.TabIndex = 75
        Me.Label10.Text = "No Urut:"
        '
        'TxtNo
        '
        Me.TxtNo.Location = New System.Drawing.Point(74, 32)
        Me.TxtNo.MaxLength = 3
        Me.TxtNo.Name = "TxtNo"
        Me.TxtNo.Size = New System.Drawing.Size(44, 20)
        Me.TxtNo.TabIndex = 74
        '
        'TxtDebet
        '
        Me.TxtDebet.Location = New System.Drawing.Point(434, 32)
        Me.TxtDebet.Name = "TxtDebet"
        Me.TxtDebet.Size = New System.Drawing.Size(147, 20)
        Me.TxtDebet.TabIndex = 76
        Me.TxtDebet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'CbAkun
        '
        Me.CbAkun.FormattingEnabled = True
        Me.CbAkun.Location = New System.Drawing.Point(124, 32)
        Me.CbAkun.Name = "CbAkun"
        Me.CbAkun.Size = New System.Drawing.Size(304, 21)
        Me.CbAkun.TabIndex = 77
        '
        'LVJU
        '
        Me.LVJU.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LVJU.FullRowSelect = True
        Me.LVJU.GridLines = True
        Me.LVJU.HideSelection = False
        Me.LVJU.Location = New System.Drawing.Point(13, 19)
        Me.LVJU.MultiSelect = False
        Me.LVJU.Name = "LVJU"
        Me.LVJU.Size = New System.Drawing.Size(827, 157)
        Me.LVJU.TabIndex = 1
        Me.LVJU.UseCompatibleStateImageBehavior = False
        Me.LVJU.View = System.Windows.Forms.View.Details
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.LblJasa)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.CbJasa)
        Me.GroupBox1.Controls.Add(Me.BtnCari)
        Me.GroupBox1.Controls.Add(Me.lblPeriode)
        Me.GroupBox1.Controls.Add(Me.DateTPJU)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.TxtKetJU)
        Me.GroupBox1.Controls.Add(Me.TxtNoBukti)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 48)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(850, 116)
        Me.GroupBox1.TabIndex = 157
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Konstruksi dan Pembiayaan"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LVJU)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.Highlight
        Me.GroupBox3.Location = New System.Drawing.Point(6, 267)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(850, 201)
        Me.GroupBox3.TabIndex = 159
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Jurnal Umum dan Penyesuaian"
        '
        'cmdPreview
        '
        Me.cmdPreview.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPreview.Image = CType(resources.GetObject("cmdPreview.Image"), System.Drawing.Image)
        Me.cmdPreview.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdPreview.Location = New System.Drawing.Point(359, 587)
        Me.cmdPreview.Name = "cmdPreview"
        Me.cmdPreview.Size = New System.Drawing.Size(73, 25)
        Me.cmdPreview.TabIndex = 163
        Me.cmdPreview.Text = "&Preview"
        Me.cmdPreview.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdPreview.UseVisualStyleBackColor = False
        '
        'cmdKeluar
        '
        Me.cmdKeluar.BackColor = System.Drawing.SystemColors.Control
        Me.cmdKeluar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdKeluar.Image = CType(resources.GetObject("cmdKeluar.Image"), System.Drawing.Image)
        Me.cmdKeluar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdKeluar.Location = New System.Drawing.Point(438, 587)
        Me.cmdKeluar.Name = "cmdKeluar"
        Me.cmdKeluar.Size = New System.Drawing.Size(73, 25)
        Me.cmdKeluar.TabIndex = 162
        Me.cmdKeluar.Text = "&Close"
        Me.cmdKeluar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdKeluar.UseVisualStyleBackColor = False
        '
        'TSBTambah
        '
        Me.TSBTambah.Image = CType(resources.GetObject("TSBTambah.Image"), System.Drawing.Image)
        Me.TSBTambah.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBTambah.Name = "TSBTambah"
        Me.TSBTambah.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TSBTambah.Size = New System.Drawing.Size(49, 22)
        Me.TSBTambah.Text = "Add"
        Me.TSBTambah.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'TSBSave
        '
        Me.TSBSave.Image = CType(resources.GetObject("TSBSave.Image"), System.Drawing.Image)
        Me.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSave.Name = "TSBSave"
        Me.TSBSave.Size = New System.Drawing.Size(51, 22)
        Me.TSBSave.Text = "Save"
        '
        'TSBEdit
        '
        Me.TSBEdit.Image = CType(resources.GetObject("TSBEdit.Image"), System.Drawing.Image)
        Me.TSBEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEdit.Name = "TSBEdit"
        Me.TSBEdit.Size = New System.Drawing.Size(47, 22)
        Me.TSBEdit.Text = "Edit"
        '
        'TSBDelete
        '
        Me.TSBDelete.Image = CType(resources.GetObject("TSBDelete.Image"), System.Drawing.Image)
        Me.TSBDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDelete.Name = "TSBDelete"
        Me.TSBDelete.Size = New System.Drawing.Size(60, 22)
        Me.TSBDelete.Text = "Delete"
        '
        'BtnAdd
        '
        Me.BtnAdd.FlatAppearance.BorderSize = 0
        Me.BtnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAdd.Image = Global.E_TaxAku.My.Resources.Resources.Actions_list_add_icon1
        Me.BtnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnAdd.Location = New System.Drawing.Point(743, 28)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(97, 23)
        Me.BtnAdd.TabIndex = 82
        Me.BtnAdd.Text = "&Add to List"
        Me.BtnAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnAdd.UseVisualStyleBackColor = True
        '
        'BtnCari
        '
        Me.BtnCari.Image = Global.E_TaxAku.My.Resources.Resources.find_02
        Me.BtnCari.Location = New System.Drawing.Point(596, 17)
        Me.BtnCari.Name = "BtnCari"
        Me.BtnCari.Size = New System.Drawing.Size(33, 23)
        Me.BtnCari.TabIndex = 48
        Me.BtnCari.UseVisualStyleBackColor = True
        '
        'FrmCCR
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(910, 619)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdPreview)
        Me.Controls.Add(Me.cmdKeluar)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.ToolStrip2)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmCCR"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Capital Cost Recovery"
        Me.GroupBox6.ResumeLayout(False)
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmdPreview As Button
    Friend WithEvents LblJasa As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents CbJasa As ComboBox
    Friend WithEvents BtnCari As Button
    Friend WithEvents lblPeriode As Label
    Friend WithEvents DateTPJU As DateTimePicker
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtKetJU As TextBox
    Friend WithEvents TxtNoBukti As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TSBTambah As ToolStripButton
    Friend WithEvents TSBSave As ToolStripButton
    Friend WithEvents TSBEdit As ToolStripButton
    Friend WithEvents TSBDelete As ToolStripButton
    Friend WithEvents BtnAdd As Button
    Friend WithEvents cmdKeluar As Button
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents LblDebet As Label
    Friend WithEvents LblKredit As Label
    Friend WithEvents LblBalance As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents ToolStrip2 As ToolStrip
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents LblAkun As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TxtKredit As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TxtNo As TextBox
    Friend WithEvents TxtDebet As TextBox
    Friend WithEvents CbAkun As ComboBox
    Friend WithEvents LVJU As ListView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
End Class
