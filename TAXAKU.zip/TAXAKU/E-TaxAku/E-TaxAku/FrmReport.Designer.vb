﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmReport))
        Me.RBPoskeu = New System.Windows.Forms.RadioButton()
        Me.GBoxReport = New System.Windows.Forms.GroupBox()
        Me.RBPer = New System.Windows.Forms.RadioButton()
        Me.RbLrFiscal = New System.Windows.Forms.RadioButton()
        Me.RBFisRec = New System.Windows.Forms.RadioButton()
        Me.RBBB = New System.Windows.Forms.RadioButton()
        Me.RBJurnal = New System.Windows.Forms.RadioButton()
        Me.RBLPE = New System.Windows.Forms.RadioButton()
        Me.RBLR = New System.Windows.Forms.RadioButton()
        Me.cmdKeluar = New System.Windows.Forms.Button()
        Me.cmdYa = New System.Windows.Forms.Button()
        Me.GBoxReport.SuspendLayout()
        Me.SuspendLayout()
        '
        'RBPoskeu
        '
        Me.RBPoskeu.AutoSize = True
        Me.RBPoskeu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBPoskeu.Location = New System.Drawing.Point(51, 50)
        Me.RBPoskeu.Margin = New System.Windows.Forms.Padding(4)
        Me.RBPoskeu.Name = "RBPoskeu"
        Me.RBPoskeu.Size = New System.Drawing.Size(134, 21)
        Me.RBPoskeu.TabIndex = 0
        Me.RBPoskeu.TabStop = True
        Me.RBPoskeu.Text = "Posisi Keuangan"
        Me.RBPoskeu.UseVisualStyleBackColor = True
        '
        'GBoxReport
        '
        Me.GBoxReport.Controls.Add(Me.RBPer)
        Me.GBoxReport.Controls.Add(Me.RbLrFiscal)
        Me.GBoxReport.Controls.Add(Me.RBFisRec)
        Me.GBoxReport.Controls.Add(Me.RBBB)
        Me.GBoxReport.Controls.Add(Me.RBJurnal)
        Me.GBoxReport.Controls.Add(Me.RBLPE)
        Me.GBoxReport.Controls.Add(Me.RBLR)
        Me.GBoxReport.Controls.Add(Me.RBPoskeu)
        Me.GBoxReport.Location = New System.Drawing.Point(85, 44)
        Me.GBoxReport.Margin = New System.Windows.Forms.Padding(4)
        Me.GBoxReport.Name = "GBoxReport"
        Me.GBoxReport.Padding = New System.Windows.Forms.Padding(4)
        Me.GBoxReport.Size = New System.Drawing.Size(354, 341)
        Me.GBoxReport.TabIndex = 1
        Me.GBoxReport.TabStop = False
        Me.GBoxReport.Text = "Pilih Jenis Laporan"
        '
        'RBPer
        '
        Me.RBPer.AutoSize = True
        Me.RBPer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBPer.ForeColor = System.Drawing.Color.MediumBlue
        Me.RBPer.Location = New System.Drawing.Point(51, 316)
        Me.RBPer.Margin = New System.Windows.Forms.Padding(4)
        Me.RBPer.Name = "RBPer"
        Me.RBPer.Size = New System.Drawing.Size(136, 21)
        Me.RBPer.TabIndex = 7
        Me.RBPer.TabStop = True
        Me.RBPer.Text = "Laporan Periodik"
        Me.RBPer.UseVisualStyleBackColor = True
        '
        'RbLrFiscal
        '
        Me.RbLrFiscal.AutoSize = True
        Me.RbLrFiscal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RbLrFiscal.Location = New System.Drawing.Point(51, 126)
        Me.RbLrFiscal.Margin = New System.Windows.Forms.Padding(4)
        Me.RbLrFiscal.Name = "RbLrFiscal"
        Me.RbLrFiscal.Size = New System.Drawing.Size(133, 21)
        Me.RbLrFiscal.TabIndex = 6
        Me.RbLrFiscal.TabStop = True
        Me.RbLrFiscal.Text = "Laba Rugi Fiskal"
        Me.RbLrFiscal.UseVisualStyleBackColor = True
        '
        'RBFisRec
        '
        Me.RBFisRec.AutoSize = True
        Me.RBFisRec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBFisRec.Location = New System.Drawing.Point(51, 202)
        Me.RBFisRec.Margin = New System.Windows.Forms.Padding(4)
        Me.RBFisRec.Name = "RBFisRec"
        Me.RBFisRec.Size = New System.Drawing.Size(143, 21)
        Me.RBFisRec.TabIndex = 5
        Me.RBFisRec.TabStop = True
        Me.RBFisRec.Text = "Rekonsiliasi Fiskal"
        Me.RBFisRec.UseVisualStyleBackColor = True
        '
        'RBBB
        '
        Me.RBBB.AutoSize = True
        Me.RBBB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBBB.Location = New System.Drawing.Point(51, 278)
        Me.RBBB.Margin = New System.Windows.Forms.Padding(4)
        Me.RBBB.Name = "RBBB"
        Me.RBBB.Size = New System.Drawing.Size(101, 21)
        Me.RBBB.TabIndex = 4
        Me.RBBB.TabStop = True
        Me.RBBB.Text = "Buku Besar"
        Me.RBBB.UseVisualStyleBackColor = True
        '
        'RBJurnal
        '
        Me.RBJurnal.AutoSize = True
        Me.RBJurnal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBJurnal.Location = New System.Drawing.Point(51, 240)
        Me.RBJurnal.Margin = New System.Windows.Forms.Padding(4)
        Me.RBJurnal.Name = "RBJurnal"
        Me.RBJurnal.Size = New System.Drawing.Size(71, 21)
        Me.RBJurnal.TabIndex = 3
        Me.RBJurnal.TabStop = True
        Me.RBJurnal.Text = "Jurnal "
        Me.RBJurnal.UseVisualStyleBackColor = True
        '
        'RBLPE
        '
        Me.RBLPE.AutoSize = True
        Me.RBLPE.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBLPE.Location = New System.Drawing.Point(51, 164)
        Me.RBLPE.Margin = New System.Windows.Forms.Padding(4)
        Me.RBLPE.Name = "RBLPE"
        Me.RBLPE.Size = New System.Drawing.Size(184, 21)
        Me.RBLPE.TabIndex = 2
        Me.RBLPE.TabStop = True
        Me.RBLPE.Text = "Laba Perubahan Ekuitas"
        Me.RBLPE.UseVisualStyleBackColor = True
        '
        'RBLR
        '
        Me.RBLR.AutoSize = True
        Me.RBLR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBLR.Location = New System.Drawing.Point(51, 88)
        Me.RBLR.Margin = New System.Windows.Forms.Padding(4)
        Me.RBLR.Name = "RBLR"
        Me.RBLR.Size = New System.Drawing.Size(154, 21)
        Me.RBLR.TabIndex = 1
        Me.RBLR.TabStop = True
        Me.RBLR.Text = "Laba Rugi Komersiil"
        Me.RBLR.UseVisualStyleBackColor = True
        '
        'cmdKeluar
        '
        Me.cmdKeluar.BackColor = System.Drawing.SystemColors.Control
        Me.cmdKeluar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdKeluar.Image = CType(resources.GetObject("cmdKeluar.Image"), System.Drawing.Image)
        Me.cmdKeluar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdKeluar.Location = New System.Drawing.Point(242, 472)
        Me.cmdKeluar.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdKeluar.Name = "cmdKeluar"
        Me.cmdKeluar.Size = New System.Drawing.Size(97, 31)
        Me.cmdKeluar.TabIndex = 126
        Me.cmdKeluar.Text = "&Close"
        Me.cmdKeluar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdKeluar.UseVisualStyleBackColor = False
        '
        'cmdYa
        '
        Me.cmdYa.BackColor = System.Drawing.SystemColors.Control
        Me.cmdYa.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdYa.Image = Global.E_TaxAku.My.Resources.Resources.onebit_34___Copy
        Me.cmdYa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdYa.Location = New System.Drawing.Point(104, 472)
        Me.cmdYa.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdYa.Name = "cmdYa"
        Me.cmdYa.Size = New System.Drawing.Size(97, 31)
        Me.cmdYa.TabIndex = 125
        Me.cmdYa.Text = "&Pilih"
        Me.cmdYa.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdYa.UseVisualStyleBackColor = False
        '
        'FrmReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(570, 541)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdKeluar)
        Me.Controls.Add(Me.cmdYa)
        Me.Controls.Add(Me.GBoxReport)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmReport"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Reporting"
        Me.GBoxReport.ResumeLayout(False)
        Me.GBoxReport.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents RBPoskeu As RadioButton
    Friend WithEvents GBoxReport As GroupBox
    Friend WithEvents cmdKeluar As Button
    Friend WithEvents cmdYa As Button
    Friend WithEvents RBFisRec As RadioButton
    Friend WithEvents RBBB As RadioButton
    Friend WithEvents RBJurnal As RadioButton
    Friend WithEvents RBLPE As RadioButton
    Friend WithEvents RBLR As RadioButton
    Friend WithEvents RbLrFiscal As RadioButton
    Friend WithEvents RBPer As RadioButton
End Class
