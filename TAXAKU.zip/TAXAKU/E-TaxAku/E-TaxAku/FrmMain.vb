﻿Public Class FrmMain

    Dim runtext(2) As String
    Dim i, j As Integer

    Dim slidingMenu As String = "close"

    Sub ClearTextMenu()
        BtnCCR.Text = ""
        BtnFOM.Text = ""
        BtnSawal.Text = ""
        BtnTax.Text = ""
        BtnReport.Text = ""
        BtnJurnal.Text = ""
        BtnRef.Text = ""
    End Sub

    Sub Terkunci()
        BtnUser.Enabled = True
        BtnLogout.Enabled = False
        BtnCCR.Enabled = False
        BtnFOM.Enabled = False
        BtnSawal.Enabled = False
        BtnTax.Enabled = False
        BtnReport.Enabled = False
        BtnJurnal.Enabled = False
        BtnRef.Enabled = False
        'WindowsToolStripMenuItem.Enabled = False
        'KeluarToolStripMenuItem.Enabled = True
    End Sub

    Sub SetTextMenu()
        BtnCCR.Text = "Capital Cost Recovery (A)"
        BtnFOM.Text = "Operation and Maintenance"
        BtnSawal.Text = "Opening Balance"
        BtnTax.Text = "Fiscal Adjustment"
        BtnReport.Text = "Financial Reporting"
        BtnJurnal.Text = "General and Adjustment"
        BtnRef.Text = "References"
    End Sub

    Private Sub BtnSliding_Click(sender As Object, e As EventArgs) Handles BtnSliding.Click
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If slidingMenu = "open" Then
            PanelSlide.Width += 25
            PanelUser.Width += 25
            PanelUser.Height += 10
            If PanelSlide.Width >= 200 Then
                SetTextMenu()
                PanelUser.Visible = True
                BtnLogout.Visible = True
                slidingMenu = "close"
                Timer1.Stop()
            End If

        Else
            PanelSlide.Width -= 25
            PanelUser.Width -= 25
            PanelUser.Height -= 25
            If PanelSlide.Width <= 50 Then
                ClearTextMenu()
                PanelUser.Visible = False
                BtnLogout.Visible = False
                slidingMenu = "open"
                Timer1.Stop()
            End If

        End If
    End Sub

    Private Sub BtnJurnal_Click(sender As Object, e As EventArgs) Handles BtnJurnal.Click
        FrmGAJ.ShowDialog()

    End Sub

    Private Sub BtnKoneksi_Click(sender As Object, e As EventArgs) Handles BtnRegistrasi.Click
        FrmUser.ShowDialog()
    End Sub

    Private Sub FrmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        Call Terkunci()
    End Sub

    Private Sub BtnUser_Click(sender As Object, e As EventArgs) Handles BtnUser.Click
        FrmLogin.ShowDialog()
    End Sub

    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click
        Dim result As Integer = MsgBox("Do You Really Want To Logout The Application.?", MsgBoxStyle.YesNo)
        If result = DialogResult.No Then

        ElseIf result = DialogResult.Yes Then
            'Timer1.Stop()
            'FrmHome.Show()
            Call Terkunci()
            'Me.Hide()
        End If
    End Sub

    Private Sub BtnFOM_Click(sender As Object, e As EventArgs) Handles BtnFOM.Click
        Try
            FrmOM.ShowDialog()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BtnCCR_Click(sender As Object, e As EventArgs) Handles BtnCCR.Click
        FrmCCR.ShowDialog()
    End Sub

    Private Sub TimerRun_Tick(sender As Object, e As EventArgs) Handles TimerRun.Tick
        If i.Equals(runtext(j).Length) Then
            Me.LblRun.Text = ""
            If j < runtext.Length - 1 Then
                j = j + 1
            Else
                j = 0
            End If
            i = 0
        End If
        LblRun.Text = runtext(j).Substring(0, i)
        i = i + 1
    End Sub

    Private Sub FrmMain_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        TimerRun.Enabled = True
        runtext(0) = "Welcome ....."
        runtext(1) = company & ".."
        runtext(2) = "Accounting and Tax Information. "
        LblRun.Text = runtext(j)
        LblRun.ForeColor = Color.AntiqueWhite
        TimerRun.Start()
    End Sub

    Private Sub BtnSawal_Click(sender As Object, e As EventArgs) Handles BtnSawal.Click
        FrmOB.ShowDialog()
    End Sub

    Private Sub BtnReport_Click(sender As Object, e As EventArgs) Handles BtnReport.Click
        FrmReport.ShowDialog()
    End Sub

    Private Sub BtnRef_Click(sender As Object, e As EventArgs) Handles BtnRef.Click
        FrmRef.ShowDialog()
    End Sub

    Private Sub BtnTax_Click(sender As Object, e As EventArgs) Handles BtnTax.Click
        'FrmFiscal.ShowDialog()
        FrmFisRec.ShowDialog()
    End Sub
End Class