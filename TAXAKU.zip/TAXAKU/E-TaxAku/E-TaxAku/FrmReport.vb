﻿Imports System.Data.Odbc
Public Class FrmReport
    Private Sub cmdKeluar_Click(sender As Object, e As EventArgs) Handles cmdKeluar.Click
        Dispose()
    End Sub

    Private Sub cmdYa_Click(sender As Object, e As EventArgs) Handles cmdYa.Click
        Try

            If Me.RBPoskeu.Checked = True Then
                FrmCRptPoskeu.ShowDialog()
            End If

            If Me.RBLR.Checked = True Then
                FrmCRptLRCom.ShowDialog()
            End If

            If Me.RbLrFiscal.Checked = True Then
                FrmCRptLrFiscal.ShowDialog()
            End If

            If Me.RBLPE.Checked = True Then
                FrmCRptLPE.ShowDialog()
            End If

            If Me.RBFisRec.Checked = True Then
                FrmCRptFisRec.ShowDialog()
            End If

            If Me.RBJurnal.Checked = True Then
                FrmCRptJurnal.ShowDialog()
            End If


            If Me.RBBB.Checked = True Then
                FrmCRptBB.ShowDialog()
            End If

            If Me.RBPer.Checked = True Then
                FrmReportPer.ShowDialog()
            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub FrmReport_LocationChanged(sender As Object, e As EventArgs) Handles MyBase.LocationChanged
        Try
            Me.Location = New Point(500, 60) 
            'Me.Location = New Point(140, 60)
        Catch ex As Exception

        End Try
    End Sub
    Private Sub CenterMe()
        Dim g As Graphics = Me.CreateGraphics()
        Dim startinPoint As Double = (Me.Width / 2) - (g.MeasureString(Me.Text.Trim, Me.Font).Width / 2)
        Dim widtOfSpase As Double = g.MeasureString(" ", Me.Font).Width
        Dim tmp As String = " "
        Dim tmpWidth As Double
        Do
            tmp += " "
            tmpWidth += widtOfSpase
        Loop While (tmpWidth + widtOfSpase) < startinPoint
        Me.Text = tmp & Me.Text.Trim & tmp
        Me.Refresh()

    End Sub

    Private Sub FrmReport_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        Try
            CenterMe()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FrmReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            CenterMe()
        Catch ex As Exception

        End Try
    End Sub
End Class