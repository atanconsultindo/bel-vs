﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFisRec
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmFisRec))
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LVFiscor = New System.Windows.Forms.ListView()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.TSBAdd = New System.Windows.Forms.ToolStripButton()
        Me.TSBSave = New System.Windows.Forms.ToolStripButton()
        Me.TSBEdit = New System.Windows.Forms.ToolStripButton()
        Me.TSBDelete = New System.Windows.Forms.ToolStripButton()
        Me.TSBCancel = New System.Windows.Forms.ToolStripButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.LblNo = New System.Windows.Forms.Label()
        Me.TxtKet = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LblFiscor = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CbPN = New System.Windows.Forms.ComboBox()
        Me.CBFiscor = New System.Windows.Forms.ComboBox()
        Me.TxtNilai = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.BtnClose = New System.Windows.Forms.Button()
        Me.BtnPreview = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.LblNiBTax = New System.Windows.Forms.Label()
        Me.LblFa = New System.Windows.Forms.Label()
        Me.LblNiATax = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TxtTarif = New System.Windows.Forms.TextBox()
        Me.LblPph = New System.Windows.Forms.Label()
        Me.GroupBox3.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LVFiscor)
        Me.GroupBox3.Location = New System.Drawing.Point(23, 164)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(662, 216)
        Me.GroupBox3.TabIndex = 39
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Data Koreksi Fiskal"
        '
        'LVFiscor
        '
        Me.LVFiscor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LVFiscor.FullRowSelect = True
        Me.LVFiscor.GridLines = True
        Me.LVFiscor.HideSelection = False
        Me.LVFiscor.Location = New System.Drawing.Point(17, 22)
        Me.LVFiscor.MultiSelect = False
        Me.LVFiscor.Name = "LVFiscor"
        Me.LVFiscor.Size = New System.Drawing.Size(624, 179)
        Me.LVFiscor.TabIndex = 0
        Me.LVFiscor.UseCompatibleStateImageBehavior = False
        Me.LVFiscor.View = System.Windows.Forms.View.Details
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBAdd, Me.TSBSave, Me.TSBEdit, Me.TSBDelete, Me.TSBCancel})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(712, 25)
        Me.ToolStrip1.TabIndex = 38
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'TSBAdd
        '
        Me.TSBAdd.Image = CType(resources.GetObject("TSBAdd.Image"), System.Drawing.Image)
        Me.TSBAdd.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBAdd.Name = "TSBAdd"
        Me.TSBAdd.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TSBAdd.Size = New System.Drawing.Size(49, 22)
        Me.TSBAdd.Text = "Add"
        Me.TSBAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'TSBSave
        '
        Me.TSBSave.Image = CType(resources.GetObject("TSBSave.Image"), System.Drawing.Image)
        Me.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSave.Name = "TSBSave"
        Me.TSBSave.Size = New System.Drawing.Size(51, 22)
        Me.TSBSave.Text = "Save"
        '
        'TSBEdit
        '
        Me.TSBEdit.Image = CType(resources.GetObject("TSBEdit.Image"), System.Drawing.Image)
        Me.TSBEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEdit.Name = "TSBEdit"
        Me.TSBEdit.Size = New System.Drawing.Size(47, 22)
        Me.TSBEdit.Text = "Edit"
        '
        'TSBDelete
        '
        Me.TSBDelete.Image = CType(resources.GetObject("TSBDelete.Image"), System.Drawing.Image)
        Me.TSBDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDelete.Name = "TSBDelete"
        Me.TSBDelete.Size = New System.Drawing.Size(60, 22)
        Me.TSBDelete.Text = "Delete"
        '
        'TSBCancel
        '
        Me.TSBCancel.Image = CType(resources.GetObject("TSBCancel.Image"), System.Drawing.Image)
        Me.TSBCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCancel.Name = "TSBCancel"
        Me.TSBCancel.Size = New System.Drawing.Size(63, 22)
        Me.TSBCancel.Text = "Cancel"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.LblNo)
        Me.GroupBox1.Controls.Add(Me.TxtKet)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.LblFiscor)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.CbPN)
        Me.GroupBox1.Controls.Add(Me.CBFiscor)
        Me.GroupBox1.Controls.Add(Me.TxtNilai)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Location = New System.Drawing.Point(23, 30)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(662, 128)
        Me.GroupBox1.TabIndex = 37
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Formulir Isian Koreksi Fiskal"
        '
        'LblNo
        '
        Me.LblNo.Location = New System.Drawing.Point(628, 24)
        Me.LblNo.Name = "LblNo"
        Me.LblNo.Size = New System.Drawing.Size(28, 16)
        Me.LblNo.TabIndex = 88
        '
        'TxtKet
        '
        Me.TxtKet.Location = New System.Drawing.Point(117, 101)
        Me.TxtKet.Name = "TxtKet"
        Me.TxtKet.Size = New System.Drawing.Size(494, 20)
        Me.TxtKet.TabIndex = 87
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(21, 99)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 13)
        Me.Label2.TabIndex = 86
        Me.Label2.Text = "Keterangan:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LblFiscor
        '
        Me.LblFiscor.Location = New System.Drawing.Point(593, 24)
        Me.LblFiscor.Name = "LblFiscor"
        Me.LblFiscor.Size = New System.Drawing.Size(28, 16)
        Me.LblFiscor.TabIndex = 85
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(21, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 13)
        Me.Label1.TabIndex = 63
        Me.Label1.Text = "Positif/Negatif:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'CbPN
        '
        Me.CbPN.DisplayMember = """P"",""N"""
        Me.CbPN.FormattingEnabled = True
        Me.CbPN.Items.AddRange(New Object() {"Positif", "Negatif"})
        Me.CbPN.Location = New System.Drawing.Point(117, 48)
        Me.CbPN.Name = "CbPN"
        Me.CbPN.Size = New System.Drawing.Size(494, 21)
        Me.CbPN.TabIndex = 62
        Me.CbPN.ValueMember = """P"",""N"""
        '
        'CBFiscor
        '
        Me.CBFiscor.FormattingEnabled = True
        Me.CBFiscor.Location = New System.Drawing.Point(117, 21)
        Me.CBFiscor.Name = "CBFiscor"
        Me.CBFiscor.Size = New System.Drawing.Size(470, 21)
        Me.CBFiscor.TabIndex = 61
        '
        'TxtNilai
        '
        Me.TxtNilai.Location = New System.Drawing.Point(117, 75)
        Me.TxtNilai.Name = "TxtNilai"
        Me.TxtNilai.Size = New System.Drawing.Size(494, 20)
        Me.TxtNilai.TabIndex = 52
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(21, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(91, 13)
        Me.Label3.TabIndex = 51
        Me.Label3.Text = "Nilai:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(21, 21)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(91, 13)
        Me.Label7.TabIndex = 42
        Me.Label7.Text = "Jenis Koreksi:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'BtnClose
        '
        Me.BtnClose.BackColor = System.Drawing.SystemColors.Control
        Me.BtnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClose.Image = CType(resources.GetObject("BtnClose.Image"), System.Drawing.Image)
        Me.BtnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnClose.Location = New System.Drawing.Point(308, 546)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(73, 25)
        Me.BtnClose.TabIndex = 121
        Me.BtnClose.Text = "&Close"
        Me.BtnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnClose.UseVisualStyleBackColor = False
        '
        'BtnPreview
        '
        Me.BtnPreview.BackColor = System.Drawing.SystemColors.Control
        Me.BtnPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPreview.Image = CType(resources.GetObject("BtnPreview.Image"), System.Drawing.Image)
        Me.BtnPreview.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPreview.Location = New System.Drawing.Point(348, 515)
        Me.BtnPreview.Name = "BtnPreview"
        Me.BtnPreview.Size = New System.Drawing.Size(73, 25)
        Me.BtnPreview.TabIndex = 122
        Me.BtnPreview.Text = "&Preview"
        Me.BtnPreview.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnPreview.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(268, 515)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(73, 25)
        Me.Button1.TabIndex = 123
        Me.Button1.Text = "&Posting"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.UseVisualStyleBackColor = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.LblPph)
        Me.GroupBox6.Controls.Add(Me.TxtTarif)
        Me.GroupBox6.Controls.Add(Me.Label4)
        Me.GroupBox6.Controls.Add(Me.LblNiBTax)
        Me.GroupBox6.Controls.Add(Me.LblFa)
        Me.GroupBox6.Controls.Add(Me.LblNiATax)
        Me.GroupBox6.Controls.Add(Me.Label13)
        Me.GroupBox6.Controls.Add(Me.Label18)
        Me.GroupBox6.Controls.Add(Me.Label14)
        Me.GroupBox6.Location = New System.Drawing.Point(269, 386)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(417, 123)
        Me.GroupBox6.TabIndex = 162
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Summary"
        '
        'LblNiBTax
        '
        Me.LblNiBTax.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblNiBTax.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblNiBTax.Location = New System.Drawing.Point(257, 20)
        Me.LblNiBTax.Name = "LblNiBTax"
        Me.LblNiBTax.Size = New System.Drawing.Size(125, 20)
        Me.LblNiBTax.TabIndex = 61
        Me.LblNiBTax.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LblFa
        '
        Me.LblFa.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblFa.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblFa.Location = New System.Drawing.Point(257, 42)
        Me.LblFa.Name = "LblFa"
        Me.LblFa.Size = New System.Drawing.Size(125, 20)
        Me.LblFa.TabIndex = 65
        Me.LblFa.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LblNiATax
        '
        Me.LblNiATax.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblNiATax.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblNiATax.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNiATax.Location = New System.Drawing.Point(257, 64)
        Me.LblNiATax.Name = "LblNiATax"
        Me.LblNiATax.Size = New System.Drawing.Size(125, 20)
        Me.LblNiATax.TabIndex = 62
        Me.LblNiATax.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label13
        '
        Me.Label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label13.Location = New System.Drawing.Point(6, 20)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(131, 20)
        Me.Label13.TabIndex = 60
        Me.Label13.Text = "Laba Sebelum Pajak:"
        '
        'Label18
        '
        Me.Label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label18.Location = New System.Drawing.Point(6, 42)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(131, 20)
        Me.Label18.TabIndex = 63
        Me.Label18.Text = "Koreksi Fiskal:"
        '
        'Label14
        '
        Me.Label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(6, 64)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(131, 20)
        Me.Label14.TabIndex = 64
        Me.Label14.Text = "Laba Setelah Pajak:"
        '
        'Label4
        '
        Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(6, 100)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(138, 20)
        Me.Label4.TabIndex = 66
        Me.Label4.Text = "Estimasi PPH (% tarif):"
        '
        'TxtTarif
        '
        Me.TxtTarif.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtTarif.Location = New System.Drawing.Point(166, 97)
        Me.TxtTarif.MaxLength = 2
        Me.TxtTarif.Name = "TxtTarif"
        Me.TxtTarif.Size = New System.Drawing.Size(63, 20)
        Me.TxtTarif.TabIndex = 67
        Me.TxtTarif.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblPph
        '
        Me.LblPph.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblPph.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LblPph.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPph.Location = New System.Drawing.Point(257, 97)
        Me.LblPph.Name = "LblPph"
        Me.LblPph.Size = New System.Drawing.Size(125, 20)
        Me.LblPph.TabIndex = 68
        Me.LblPph.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'FrmFisRec
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(712, 578)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.BtnPreview)
        Me.Controls.Add(Me.BtnClose)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmFisRec"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Fiscal Correction"
        Me.GroupBox3.ResumeLayout(False)
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents LVFiscor As ListView
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents TSBAdd As ToolStripButton
    Friend WithEvents TSBSave As ToolStripButton
    Friend WithEvents TSBEdit As ToolStripButton
    Friend WithEvents TSBDelete As ToolStripButton
    Friend WithEvents TSBCancel As ToolStripButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TxtNilai As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents BtnClose As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents CbPN As ComboBox
    Friend WithEvents CBFiscor As ComboBox
    Friend WithEvents LblFiscor As Label
    Friend WithEvents TxtKet As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents LblNo As Label
    Friend WithEvents BtnPreview As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents LblNiBTax As Label
    Friend WithEvents LblFa As Label
    Friend WithEvents LblNiATax As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents LblPph As Label
    Friend WithEvents TxtTarif As TextBox
    Friend WithEvents Label4 As Label
End Class
