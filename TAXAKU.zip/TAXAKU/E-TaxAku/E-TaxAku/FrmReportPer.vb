﻿Public Class FrmReportPer
    Private Sub BtnPilih_Click(sender As Object, e As EventArgs) Handles BtnPilih.Click
        Dim mAwal As Date = DateTPAwal.Value.ToShortDateString
        Dim mAkhir As Date = DateTPAkhir.Value.ToShortDateString
        Dim mTglAwal As String = FormatTgl(mAwal)
        Dim mTglAkhir As String = FormatTgl(mAkhir)

        If mAkhir < mAwal.ToShortDateString Then
            MsgBox("Tanggal akhir '" & mAkhir & "' mendahului tanggal awal'" & mAwal & "' ")
            DateTPAkhir.Focus()
        Else
            If RBPoskeu.Checked = True Then
                Try
                    '    
                    FrmCRptPoskeuPer.ShowDialog()
                    DateTPAwal.Focus()
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

                'FrmCRptPosKeu.ShowDialog()
            End If

            If RBLR.Checked = True Then
                FrmCRptLrComPer.ShowDialog()
                DateTPAwal.Focus()

            End If

            If RbLrFiscal.Checked = True Then
                FrmCRptLrFiscalPer.ShowDialog()
                DateTPAwal.Focus()

            End If

            If Me.RBLPE.Checked = True Then
                FrmCRptLPEPer.ShowDialog()
            End If

            If RBJurnal.Checked = True Then
                FrmCRptJurnalPer.ShowDialog()
                DateTPAwal.Focus()

            End If

            If RBBB.Checked = True Then
                FrmCRptBBPer.ShowDialog()
                DateTPAwal.Focus()

            End If



        End If
    End Sub

    Private Sub FrmReportPer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            'Lblprovinsi.Text = prov
            'LblKabupaten.Text = kab

            DateTPAwal.Value = Now
            DateTPAkhir.Value = Now
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FrmReportPer_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        DateTPAwal.Focus()
    End Sub

    Private Sub DateTPAwal_KeyPress(sender As Object, e As KeyPressEventArgs) Handles DateTPAwal.KeyPress
        If e.KeyChar = Chr(13) Then
            DateTPAkhir.Focus()
        End If
    End Sub

    Private Sub DateTPAkhir_KeyPress(sender As Object, e As KeyPressEventArgs) Handles DateTPAkhir.KeyPress
        If e.KeyChar = Chr(13) Then
            RBPoskeu.Focus()
        End If
    End Sub

    Private Sub BtnKeluar_Click(sender As Object, e As EventArgs) Handles BtnKeluar.Click
        Dispose()
    End Sub
End Class