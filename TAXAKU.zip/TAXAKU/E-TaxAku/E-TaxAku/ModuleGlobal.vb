﻿Module ModuleGlobal
    Public Function FormatTgl(ByVal Input As Date)
        Dim Day As String = CStr(Input.Day)
        Dim Month As String = CStr(Input.Month)

        If Len(CStr(Input.Day)) = 1 Then
            Day = "0" & Input.Day
        ElseIf Len(CStr(Input.Day)) = 0 Then
            Day = "00"
        End If
        If Len(CStr(Input.Month)) = 1 Then
            Month = "0" & Input.Month
        ElseIf Len(CStr(Input.Month)) = 0 Then
            Month = "00"
        End If
        FormatTgl = CStr(Input.Year & "-" & Month & "-" & Day & " ")

    End Function

End Module
