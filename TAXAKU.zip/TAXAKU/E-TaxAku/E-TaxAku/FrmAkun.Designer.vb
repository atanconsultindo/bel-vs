﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAkun
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmAkun))
        Me.LVRek = New System.Windows.Forms.ListView()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TxtKdAKun = New System.Windows.Forms.TextBox()
        Me.LblKel = New System.Windows.Forms.Label()
        Me.LblGroup = New System.Windows.Forms.Label()
        Me.CbKel = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtUraian = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CbGroup = New System.Windows.Forms.ComboBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.TSBAdd = New System.Windows.Forms.ToolStripButton()
        Me.TSBSave = New System.Windows.Forms.ToolStripButton()
        Me.TSBEdit = New System.Windows.Forms.ToolStripButton()
        Me.TSBDelete = New System.Windows.Forms.ToolStripButton()
        Me.TSBCancel = New System.Windows.Forms.ToolStripButton()
        Me.TSBPrint = New System.Windows.Forms.ToolStripButton()
        Me.BtnClose = New System.Windows.Forms.Button()
        Me.GroupBox3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LVRek
        '
        Me.LVRek.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LVRek.FullRowSelect = True
        Me.LVRek.GridLines = True
        Me.LVRek.HideSelection = False
        Me.LVRek.Location = New System.Drawing.Point(13, 25)
        Me.LVRek.MultiSelect = False
        Me.LVRek.Name = "LVRek"
        Me.LVRek.Size = New System.Drawing.Size(839, 365)
        Me.LVRek.TabIndex = 0
        Me.LVRek.UseCompatibleStateImageBehavior = False
        Me.LVRek.View = System.Windows.Forms.View.Details
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LVRek)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 172)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(857, 404)
        Me.GroupBox3.TabIndex = 134
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Bagan Akun Standar"
        '
        'TxtKdAKun
        '
        Me.TxtKdAKun.Location = New System.Drawing.Point(145, 72)
        Me.TxtKdAKun.MaxLength = 6
        Me.TxtKdAKun.Name = "TxtKdAKun"
        Me.TxtKdAKun.Size = New System.Drawing.Size(553, 20)
        Me.TxtKdAKun.TabIndex = 33
        '
        'LblKel
        '
        Me.LblKel.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.LblKel.Location = New System.Drawing.Point(704, 40)
        Me.LblKel.Name = "LblKel"
        Me.LblKel.Size = New System.Drawing.Size(136, 20)
        Me.LblKel.TabIndex = 32
        Me.LblKel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'LblGroup
        '
        Me.LblGroup.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.LblGroup.Location = New System.Drawing.Point(704, 13)
        Me.LblGroup.Name = "LblGroup"
        Me.LblGroup.Size = New System.Drawing.Size(136, 20)
        Me.LblGroup.TabIndex = 29
        Me.LblGroup.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CbKel
        '
        Me.CbKel.DropDownHeight = 400
        Me.CbKel.DropDownWidth = 50
        Me.CbKel.FormattingEnabled = True
        Me.CbKel.IntegralHeight = False
        Me.CbKel.ItemHeight = 13
        Me.CbKel.Location = New System.Drawing.Point(145, 41)
        Me.CbKel.Name = "CbKel"
        Me.CbKel.Size = New System.Drawing.Size(553, 21)
        Me.CbKel.TabIndex = 27
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(32, 102)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(69, 13)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Uraian Akun:"
        '
        'TxtUraian
        '
        Me.TxtUraian.Location = New System.Drawing.Point(145, 102)
        Me.TxtUraian.Name = "TxtUraian"
        Me.TxtUraian.Size = New System.Drawing.Size(553, 20)
        Me.TxtUraian.TabIndex = 24
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Kode Akun:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Kelompok Akun:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(34, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Group Akun:"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.CbGroup)
        Me.Panel1.Controls.Add(Me.TxtKdAKun)
        Me.Panel1.Controls.Add(Me.LblKel)
        Me.Panel1.Controls.Add(Me.LblGroup)
        Me.Panel1.Controls.Add(Me.CbKel)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.TxtUraian)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(9, 31)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(859, 133)
        Me.Panel1.TabIndex = 132
        '
        'CbGroup
        '
        Me.CbGroup.FormattingEnabled = True
        Me.CbGroup.Location = New System.Drawing.Point(145, 10)
        Me.CbGroup.Name = "CbGroup"
        Me.CbGroup.Size = New System.Drawing.Size(553, 21)
        Me.CbGroup.TabIndex = 34
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBAdd, Me.TSBSave, Me.TSBEdit, Me.TSBDelete, Me.TSBCancel, Me.TSBPrint})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(901, 25)
        Me.ToolStrip1.TabIndex = 131
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'TSBAdd
        '
        Me.TSBAdd.Image = CType(resources.GetObject("TSBAdd.Image"), System.Drawing.Image)
        Me.TSBAdd.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBAdd.Name = "TSBAdd"
        Me.TSBAdd.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TSBAdd.Size = New System.Drawing.Size(49, 22)
        Me.TSBAdd.Text = "Add"
        Me.TSBAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'TSBSave
        '
        Me.TSBSave.Image = CType(resources.GetObject("TSBSave.Image"), System.Drawing.Image)
        Me.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSave.Name = "TSBSave"
        Me.TSBSave.Size = New System.Drawing.Size(51, 22)
        Me.TSBSave.Text = "Save"
        '
        'TSBEdit
        '
        Me.TSBEdit.Image = CType(resources.GetObject("TSBEdit.Image"), System.Drawing.Image)
        Me.TSBEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEdit.Name = "TSBEdit"
        Me.TSBEdit.Size = New System.Drawing.Size(47, 22)
        Me.TSBEdit.Text = "Edit"
        '
        'TSBDelete
        '
        Me.TSBDelete.Image = CType(resources.GetObject("TSBDelete.Image"), System.Drawing.Image)
        Me.TSBDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDelete.Name = "TSBDelete"
        Me.TSBDelete.Size = New System.Drawing.Size(60, 22)
        Me.TSBDelete.Text = "Delete"
        '
        'TSBCancel
        '
        Me.TSBCancel.Image = CType(resources.GetObject("TSBCancel.Image"), System.Drawing.Image)
        Me.TSBCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCancel.Name = "TSBCancel"
        Me.TSBCancel.Size = New System.Drawing.Size(63, 22)
        Me.TSBCancel.Text = "Cancel"
        '
        'TSBPrint
        '
        Me.TSBPrint.Image = CType(resources.GetObject("TSBPrint.Image"), System.Drawing.Image)
        Me.TSBPrint.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBPrint.Name = "TSBPrint"
        Me.TSBPrint.Size = New System.Drawing.Size(52, 22)
        Me.TSBPrint.Text = "Print"
        '
        'BtnClose
        '
        Me.BtnClose.BackColor = System.Drawing.SystemColors.Control
        Me.BtnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClose.Image = CType(resources.GetObject("BtnClose.Image"), System.Drawing.Image)
        Me.BtnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnClose.Location = New System.Drawing.Point(415, 585)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(73, 25)
        Me.BtnClose.TabIndex = 130
        Me.BtnClose.Text = "&Close"
        Me.BtnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnClose.UseVisualStyleBackColor = False
        '
        'FrmAkun
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 619)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.BtnClose)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmAkun"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Chart Of Account"
        Me.GroupBox3.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BtnClose As Button
    Friend WithEvents LVRek As ListView
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents TxtKdAKun As TextBox
    Friend WithEvents LblKel As Label
    Friend WithEvents LblGroup As Label
    Friend WithEvents CbKel As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtUraian As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TSBPrint As ToolStripButton
    Friend WithEvents TSBCancel As ToolStripButton
    Friend WithEvents TSBDelete As ToolStripButton
    Friend WithEvents TSBEdit As ToolStripButton
    Friend WithEvents TSBSave As ToolStripButton
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents CbGroup As ComboBox
    Friend WithEvents TSBAdd As ToolStripButton
End Class
