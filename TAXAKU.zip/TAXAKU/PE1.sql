SELECT '1' AS Kode, 'Saldo Awal Ekuitas' AS EkuitasUraian, ta_djurnal.`id_akun3`, akun3.`nama_akun3`, SUM(ta_djurnal.Kredit) - SUM(ta_djurnal.Debet) AS Nilai, ta_hjurnal.`id_djt`
FROM ta_djurnal 
LEFT JOIN akun3 ON ta_djurnal.`id_akun3` = akun3.`id_akun3`
LEFT JOIN ta_hjurnal ON ta_djurnal.`no_bukti` = ta_hjurnal.`no_bukti`	
GROUP BY '1', 'Ekuitas Awal', ta_djurnal.`id_akun3`
HAVING (((ta_djurnal.`id_akun3`) LIKE '3%') AND ((ta_hjurnal.`id_djt`)='51'));
