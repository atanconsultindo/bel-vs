SELECT '3' AS Kode, 'Laba (Rugi) Berjalan ' AS EkuitasUraian, '35020' AS KodeRek, 'Laba (Rugi) Periode Berjalan' AS Uraian, SUM(ta_djurnal.`kredit`-ta_djurnal.`debet`) AS Nilai, ta_hjurnal.`id_djt`
FROM ta_djurnal
LEFT JOIN ta_hjurnal ON ta_djurnal.`no_bukti` = ta_hjurnal.`no_bukti`
WHERE LEFT(ta_djurnal.`id_akun3`,'1')='4' OR LEFT(ta_djurnal.`id_akun3`,'1')= '5'
