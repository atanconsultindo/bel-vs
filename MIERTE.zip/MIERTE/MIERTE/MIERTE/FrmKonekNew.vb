﻿Imports System.Configuration
Imports System.Windows.Forms
Imports System.Data.OleDb
Public Class FrmKonekNew
    Private Sub BtnProses_Click(sender As Object, e As EventArgs) Handles BtnProses.Click
        Try
            'If DatabaseConnected(TxtDriver.Text, TxtServer.Text, TxtDB.Text, TxtPass.Text, TxtUser.Text) = False Then
            If DatabaseConnected(TxtProvider.Text, TxtSource.Text) = False Then
                'MsgBox("Konfigurasi ulang...", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
                Try
                    'Dim newdbDriver As String = TxtDriver.Text
                    'Dim newdbServer As String = TxtServer.Text
                    'Dim newdbDatabase As String = TxtDB.Text
                    'Dim newdbPassword As String = TxtPass.Text
                    'Dim newdbUID As String = TxtUser.Text
                    Dim newdbProvider As String = TxtProvider.Text
                    Dim newdbSource As String = TxtSource.Text

                    With My.Settings
                        .dbProvider = newdbProvider
                        .dbSource = newdbSource
                        .Save()
                    End With
                    MsgBox("Konfigurasi Tersimpan")
                Catch ex As Exception
                    MsgBox("Konfigurasi tidak tersimpan")
                End Try
                'GetDatabaseSetting()
            Else
                'My.Settings.Save()
                With My.Settings
                    .dbProvider = TxtProvider.Text
                    .dbSource = TxtSource.Text
                    .Save()
                End With
                GetDatabaseSetting()
                Me.DialogResult = DialogResult.OK
                Me.Close()
            End If
            'FrmLogin.Show()
            FrmMain.ToolStripStatusDriver.Text = Me.TxtProvider.Text
            FrmMain.ToolStripStatusDb.Text = Me.TxtDB.Text
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub FrmKonekNew_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            TxtProvider.Enabled = False
            GetDatabaseSetting()
            'Me.TxtDriver.Text = dbDriver
            Me.TxtProvider.Text = dbProviders
            'Me.TxtServer.Text = dbServer
            'Me.TxtSource.Text = ""
            Me.TxtSource.Text = dbSources
            'Me.TxtDB.Text = dbDatabase
            'TxtPass.Text = dbPassword
            'Me.TxtUser.Text = dbUID
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Try
            Dispose()
        Catch ex As Exception

        End Try
    End Sub
End Class