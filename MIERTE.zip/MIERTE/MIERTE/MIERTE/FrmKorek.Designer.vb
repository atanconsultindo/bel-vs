﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmKorek
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmKorek))
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.LVRek = New System.Windows.Forms.ListView()
        Me.LblKel = New System.Windows.Forms.Label()
        Me.LblJenis = New System.Windows.Forms.Label()
        Me.LblAkun = New System.Windows.Forms.Label()
        Me.CbAkun = New System.Windows.Forms.ComboBox()
        Me.CbKel = New System.Windows.Forms.ComboBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtUraian = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TxtKdJenis = New System.Windows.Forms.TextBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.TSBSave = New System.Windows.Forms.ToolStripButton()
        Me.TSBEdit = New System.Windows.Forms.ToolStripButton()
        Me.TSBDelete = New System.Windows.Forms.ToolStripButton()
        Me.TSBCancel = New System.Windows.Forms.ToolStripButton()
        Me.TSBPrint = New System.Windows.Forms.ToolStripButton()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Image = CType(resources.GetObject("BtnKeluar.Image"), System.Drawing.Image)
        Me.BtnKeluar.Location = New System.Drawing.Point(391, 579)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(75, 25)
        Me.BtnKeluar.TabIndex = 41
        Me.BtnKeluar.Text = "Keluar"
        Me.BtnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'LVRek
        '
        Me.LVRek.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LVRek.FullRowSelect = True
        Me.LVRek.GridLines = True
        Me.LVRek.HideSelection = False
        Me.LVRek.Location = New System.Drawing.Point(13, 21)
        Me.LVRek.MultiSelect = False
        Me.LVRek.Name = "LVRek"
        Me.LVRek.Size = New System.Drawing.Size(839, 244)
        Me.LVRek.TabIndex = 0
        Me.LVRek.UseCompatibleStateImageBehavior = False
        Me.LVRek.View = System.Windows.Forms.View.Details
        '
        'LblKel
        '
        Me.LblKel.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.LblKel.Location = New System.Drawing.Point(704, 40)
        Me.LblKel.Name = "LblKel"
        Me.LblKel.Size = New System.Drawing.Size(136, 20)
        Me.LblKel.TabIndex = 32
        Me.LblKel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'LblJenis
        '
        Me.LblJenis.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.LblJenis.Location = New System.Drawing.Point(704, 69)
        Me.LblJenis.Name = "LblJenis"
        Me.LblJenis.Size = New System.Drawing.Size(136, 20)
        Me.LblJenis.TabIndex = 30
        Me.LblJenis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'LblAkun
        '
        Me.LblAkun.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.LblAkun.Location = New System.Drawing.Point(704, 13)
        Me.LblAkun.Name = "LblAkun"
        Me.LblAkun.Size = New System.Drawing.Size(136, 20)
        Me.LblAkun.TabIndex = 29
        Me.LblAkun.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CbAkun
        '
        Me.CbAkun.DropDownHeight = 400
        Me.CbAkun.DropDownWidth = 50
        Me.CbAkun.FormattingEnabled = True
        Me.CbAkun.IntegralHeight = False
        Me.CbAkun.ItemHeight = 13
        Me.CbAkun.Location = New System.Drawing.Point(145, 10)
        Me.CbAkun.Name = "CbAkun"
        Me.CbAkun.Size = New System.Drawing.Size(553, 21)
        Me.CbAkun.TabIndex = 28
        '
        'CbKel
        '
        Me.CbKel.DropDownHeight = 400
        Me.CbKel.DropDownWidth = 50
        Me.CbKel.FormattingEnabled = True
        Me.CbKel.IntegralHeight = False
        Me.CbKel.ItemHeight = 13
        Me.CbKel.Location = New System.Drawing.Point(145, 37)
        Me.CbKel.Name = "CbKel"
        Me.CbKel.Size = New System.Drawing.Size(553, 21)
        Me.CbKel.TabIndex = 27
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LVRek)
        Me.GroupBox3.Location = New System.Drawing.Point(17, 261)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(873, 287)
        Me.GroupBox3.TabIndex = 34
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Master Perkiraan Akuntansi"
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Location = New System.Drawing.Point(13, -3)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(856, 23)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "DATA PERKIRAAN (LEVEL 3)"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(32, 91)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 13)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Uraian:"
        '
        'TxtUraian
        '
        Me.TxtUraian.Location = New System.Drawing.Point(145, 91)
        Me.TxtUraian.Name = "TxtUraian"
        Me.TxtUraian.Size = New System.Drawing.Size(553, 20)
        Me.TxtUraian.TabIndex = 24
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(32, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Kode Kelompok"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 13)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Kode Akun"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TxtKdJenis)
        Me.Panel1.Controls.Add(Me.LblKel)
        Me.Panel1.Controls.Add(Me.LblJenis)
        Me.Panel1.Controls.Add(Me.LblAkun)
        Me.Panel1.Controls.Add(Me.CbAkun)
        Me.Panel1.Controls.Add(Me.CbKel)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.ToolStrip1)
        Me.Panel1.Controls.Add(Me.TxtUraian)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(10, 32)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(859, 195)
        Me.Panel1.TabIndex = 32
        '
        'TxtKdJenis
        '
        Me.TxtKdJenis.Location = New System.Drawing.Point(145, 65)
        Me.TxtKdJenis.Name = "TxtKdJenis"
        Me.TxtKdJenis.Size = New System.Drawing.Size(553, 20)
        Me.TxtKdJenis.TabIndex = 33
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBSave, Me.TSBEdit, Me.TSBDelete, Me.TSBCancel, Me.TSBPrint})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 168)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(859, 27)
        Me.ToolStrip1.TabIndex = 16
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'TSBSave
        '
        Me.TSBSave.Image = CType(resources.GetObject("TSBSave.Image"), System.Drawing.Image)
        Me.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSave.Name = "TSBSave"
        Me.TSBSave.Size = New System.Drawing.Size(71, 24)
        Me.TSBSave.Text = "Simpan"
        '
        'TSBEdit
        '
        Me.TSBEdit.Image = CType(resources.GetObject("TSBEdit.Image"), System.Drawing.Image)
        Me.TSBEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEdit.Name = "TSBEdit"
        Me.TSBEdit.Size = New System.Drawing.Size(51, 24)
        Me.TSBEdit.Text = "Edit"
        '
        'TSBDelete
        '
        Me.TSBDelete.Image = CType(resources.GetObject("TSBDelete.Image"), System.Drawing.Image)
        Me.TSBDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDelete.Name = "TSBDelete"
        Me.TSBDelete.Size = New System.Drawing.Size(65, 24)
        Me.TSBDelete.Text = "Hapus"
        '
        'TSBCancel
        '
        Me.TSBCancel.Image = CType(resources.GetObject("TSBCancel.Image"), System.Drawing.Image)
        Me.TSBCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCancel.Name = "TSBCancel"
        Me.TSBCancel.Size = New System.Drawing.Size(57, 24)
        Me.TSBCancel.Text = "Batal"
        '
        'TSBPrint
        '
        Me.TSBPrint.Image = CType(resources.GetObject("TSBPrint.Image"), System.Drawing.Image)
        Me.TSBPrint.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBPrint.Name = "TSBPrint"
        Me.TSBPrint.Size = New System.Drawing.Size(56, 24)
        Me.TSBPrint.Text = "Print"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(32, 65)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 13)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Kode Jenis"
        '
        'FrmKorek
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 609)
        Me.Controls.Add(Me.BtnKeluar)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmKorek"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Kode Perkiraan"
        Me.GroupBox3.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnKeluar As Button
    Friend WithEvents LVRek As ListView
    Friend WithEvents LblKel As Label
    Friend WithEvents LblJenis As Label
    Friend WithEvents LblAkun As Label
    Friend WithEvents CbAkun As ComboBox
    Friend WithEvents CbKel As ComboBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtUraian As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents TSBSave As ToolStripButton
    Friend WithEvents TSBEdit As ToolStripButton
    Friend WithEvents TSBDelete As ToolStripButton
    Friend WithEvents TSBCancel As ToolStripButton
    Friend WithEvents TSBPrint As ToolStripButton
    Friend WithEvents Label4 As Label
    Friend WithEvents TxtKdJenis As TextBox
End Class
