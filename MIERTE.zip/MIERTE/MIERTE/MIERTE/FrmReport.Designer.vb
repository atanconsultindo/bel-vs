﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmReport))
        Me.GBoxReport = New System.Windows.Forms.GroupBox()
        Me.RBHari = New System.Windows.Forms.RadioButton()
        Me.RBLak = New System.Windows.Forms.RadioButton()
        Me.RBProyek = New System.Windows.Forms.RadioButton()
        Me.RBBulan = New System.Windows.Forms.RadioButton()
        Me.RBOper = New System.Windows.Forms.RadioButton()
        Me.RBNeraca = New System.Windows.Forms.RadioButton()
        Me.cmdKeluar = New System.Windows.Forms.Button()
        Me.BtnPilih = New System.Windows.Forms.Button()
        Me.GBoxReport.SuspendLayout()
        Me.SuspendLayout()
        '
        'GBoxReport
        '
        Me.GBoxReport.Controls.Add(Me.RBHari)
        Me.GBoxReport.Controls.Add(Me.RBLak)
        Me.GBoxReport.Controls.Add(Me.RBProyek)
        Me.GBoxReport.Controls.Add(Me.RBBulan)
        Me.GBoxReport.Controls.Add(Me.RBOper)
        Me.GBoxReport.Controls.Add(Me.RBNeraca)
        Me.GBoxReport.Location = New System.Drawing.Point(32, 21)
        Me.GBoxReport.Name = "GBoxReport"
        Me.GBoxReport.Size = New System.Drawing.Size(280, 277)
        Me.GBoxReport.TabIndex = 133
        Me.GBoxReport.TabStop = False
        Me.GBoxReport.Text = "Pilih Jenis Laporan"
        '
        'RBHari
        '
        Me.RBHari.AutoSize = True
        Me.RBHari.Enabled = False
        Me.RBHari.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBHari.Location = New System.Drawing.Point(38, 191)
        Me.RBHari.Name = "RBHari"
        Me.RBHari.Size = New System.Drawing.Size(55, 17)
        Me.RBHari.TabIndex = 5
        Me.RBHari.TabStop = True
        Me.RBHari.Text = "Harian"
        Me.RBHari.UseVisualStyleBackColor = True
        '
        'RBLak
        '
        Me.RBLak.AutoSize = True
        Me.RBLak.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBLak.Location = New System.Drawing.Point(38, 101)
        Me.RBLak.Name = "RBLak"
        Me.RBLak.Size = New System.Drawing.Size(66, 17)
        Me.RBLak.TabIndex = 4
        Me.RBLak.TabStop = True
        Me.RBLak.Text = "Arus Kas"
        Me.RBLak.UseVisualStyleBackColor = True
        '
        'RBProyek
        '
        Me.RBProyek.AutoSize = True
        Me.RBProyek.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBProyek.Location = New System.Drawing.Point(38, 131)
        Me.RBProyek.Name = "RBProyek"
        Me.RBProyek.Size = New System.Drawing.Size(57, 17)
        Me.RBProyek.TabIndex = 3
        Me.RBProyek.TabStop = True
        Me.RBProyek.Text = "Proyek"
        Me.RBProyek.UseVisualStyleBackColor = True
        '
        'RBBulan
        '
        Me.RBBulan.AutoSize = True
        Me.RBBulan.Enabled = False
        Me.RBBulan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBBulan.Location = New System.Drawing.Point(38, 161)
        Me.RBBulan.Name = "RBBulan"
        Me.RBBulan.Size = New System.Drawing.Size(63, 17)
        Me.RBBulan.TabIndex = 2
        Me.RBBulan.TabStop = True
        Me.RBBulan.Text = "Bulanan"
        Me.RBBulan.UseVisualStyleBackColor = True
        '
        'RBOper
        '
        Me.RBOper.AutoSize = True
        Me.RBOper.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBOper.Location = New System.Drawing.Point(38, 71)
        Me.RBOper.Name = "RBOper"
        Me.RBOper.Size = New System.Drawing.Size(80, 17)
        Me.RBOper.TabIndex = 1
        Me.RBOper.TabStop = True
        Me.RBOper.Text = "Operasional"
        Me.RBOper.UseVisualStyleBackColor = True
        '
        'RBNeraca
        '
        Me.RBNeraca.AutoSize = True
        Me.RBNeraca.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBNeraca.Location = New System.Drawing.Point(38, 41)
        Me.RBNeraca.Name = "RBNeraca"
        Me.RBNeraca.Size = New System.Drawing.Size(59, 17)
        Me.RBNeraca.TabIndex = 0
        Me.RBNeraca.TabStop = True
        Me.RBNeraca.Text = "Neraca"
        Me.RBNeraca.UseVisualStyleBackColor = True
        '
        'cmdKeluar
        '
        Me.cmdKeluar.BackColor = System.Drawing.SystemColors.Control
        Me.cmdKeluar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdKeluar.Image = CType(resources.GetObject("cmdKeluar.Image"), System.Drawing.Image)
        Me.cmdKeluar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdKeluar.Location = New System.Drawing.Point(141, 326)
        Me.cmdKeluar.Name = "cmdKeluar"
        Me.cmdKeluar.Size = New System.Drawing.Size(73, 25)
        Me.cmdKeluar.TabIndex = 135
        Me.cmdKeluar.Text = "&Close"
        Me.cmdKeluar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdKeluar.UseVisualStyleBackColor = False
        '
        'BtnPilih
        '
        Me.BtnPilih.BackColor = System.Drawing.SystemColors.Control
        Me.BtnPilih.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPilih.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPilih.Location = New System.Drawing.Point(62, 326)
        Me.BtnPilih.Name = "BtnPilih"
        Me.BtnPilih.Size = New System.Drawing.Size(73, 25)
        Me.BtnPilih.TabIndex = 134
        Me.BtnPilih.Text = "&Pilih"
        Me.BtnPilih.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnPilih.UseVisualStyleBackColor = False
        '
        'FrmReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(345, 372)
        Me.Controls.Add(Me.GBoxReport)
        Me.Controls.Add(Me.cmdKeluar)
        Me.Controls.Add(Me.BtnPilih)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmReport"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Laporan"
        Me.GBoxReport.ResumeLayout(False)
        Me.GBoxReport.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GBoxReport As GroupBox
    Friend WithEvents RBHari As RadioButton
    Friend WithEvents RBLak As RadioButton
    Friend WithEvents RBProyek As RadioButton
    Friend WithEvents RBBulan As RadioButton
    Friend WithEvents RBOper As RadioButton
    Friend WithEvents RBNeraca As RadioButton
    Friend WithEvents cmdKeluar As Button
    Friend WithEvents BtnPilih As Button
End Class
