﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmRef
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmRef))
        Me.GBoxReport = New System.Windows.Forms.GroupBox()
        Me.RBFisRec = New System.Windows.Forms.RadioButton()
        Me.RBWarga = New System.Windows.Forms.RadioButton()
        Me.RBHapus = New System.Windows.Forms.RadioButton()
        Me.RBFA = New System.Windows.Forms.RadioButton()
        Me.RBBas = New System.Windows.Forms.RadioButton()
        Me.RBPerush = New System.Windows.Forms.RadioButton()
        Me.cmdKeluar = New System.Windows.Forms.Button()
        Me.BtnPilih = New System.Windows.Forms.Button()
        Me.GBoxReport.SuspendLayout()
        Me.SuspendLayout()
        '
        'GBoxReport
        '
        Me.GBoxReport.Controls.Add(Me.RBFisRec)
        Me.GBoxReport.Controls.Add(Me.RBWarga)
        Me.GBoxReport.Controls.Add(Me.RBHapus)
        Me.GBoxReport.Controls.Add(Me.RBFA)
        Me.GBoxReport.Controls.Add(Me.RBBas)
        Me.GBoxReport.Controls.Add(Me.RBPerush)
        Me.GBoxReport.Location = New System.Drawing.Point(27, 12)
        Me.GBoxReport.Name = "GBoxReport"
        Me.GBoxReport.Size = New System.Drawing.Size(280, 277)
        Me.GBoxReport.TabIndex = 130
        Me.GBoxReport.TabStop = False
        Me.GBoxReport.Text = "Pilih Jenis Referensi"
        '
        'RBFisRec
        '
        Me.RBFisRec.AutoSize = True
        Me.RBFisRec.Enabled = False
        Me.RBFisRec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBFisRec.Location = New System.Drawing.Point(38, 191)
        Me.RBFisRec.Name = "RBFisRec"
        Me.RBFisRec.Size = New System.Drawing.Size(110, 17)
        Me.RBFisRec.TabIndex = 5
        Me.RBFisRec.TabStop = True
        Me.RBFisRec.Text = "Rekonsiliasi Fiskal"
        Me.RBFisRec.UseVisualStyleBackColor = True
        '
        'RBWarga
        '
        Me.RBWarga.AutoSize = True
        Me.RBWarga.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBWarga.Location = New System.Drawing.Point(38, 101)
        Me.RBWarga.Name = "RBWarga"
        Me.RBWarga.Size = New System.Drawing.Size(56, 17)
        Me.RBWarga.TabIndex = 4
        Me.RBWarga.TabStop = True
        Me.RBWarga.Text = "Warga"
        Me.RBWarga.UseVisualStyleBackColor = True
        '
        'RBHapus
        '
        Me.RBHapus.AutoSize = True
        Me.RBHapus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBHapus.Location = New System.Drawing.Point(38, 131)
        Me.RBHapus.Name = "RBHapus"
        Me.RBHapus.Size = New System.Drawing.Size(81, 17)
        Me.RBHapus.TabIndex = 3
        Me.RBHapus.TabStop = True
        Me.RBHapus.Text = "Hapus Data"
        Me.RBHapus.UseVisualStyleBackColor = True
        '
        'RBFA
        '
        Me.RBFA.AutoSize = True
        Me.RBFA.Enabled = False
        Me.RBFA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBFA.Location = New System.Drawing.Point(38, 161)
        Me.RBFA.Name = "RBFA"
        Me.RBFA.Size = New System.Drawing.Size(130, 17)
        Me.RBFA.TabIndex = 2
        Me.RBFA.TabStop = True
        Me.RBFA.Text = "Jenis Fiscal Adjusment"
        Me.RBFA.UseVisualStyleBackColor = True
        '
        'RBBas
        '
        Me.RBBas.AutoSize = True
        Me.RBBas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBBas.Location = New System.Drawing.Point(38, 71)
        Me.RBBas.Name = "RBBas"
        Me.RBBas.Size = New System.Drawing.Size(131, 17)
        Me.RBBas.TabIndex = 1
        Me.RBBas.TabStop = True
        Me.RBBas.Text = "Bagan Kode Perkiraan"
        Me.RBBas.UseVisualStyleBackColor = True
        '
        'RBPerush
        '
        Me.RBPerush.AutoSize = True
        Me.RBPerush.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RBPerush.Location = New System.Drawing.Point(38, 41)
        Me.RBPerush.Name = "RBPerush"
        Me.RBPerush.Size = New System.Drawing.Size(137, 17)
        Me.RBPerush.TabIndex = 0
        Me.RBPerush.TabStop = True
        Me.RBPerush.Text = "Profile Rukun Tetangga"
        Me.RBPerush.UseVisualStyleBackColor = True
        '
        'cmdKeluar
        '
        Me.cmdKeluar.BackColor = System.Drawing.SystemColors.Control
        Me.cmdKeluar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdKeluar.Image = CType(resources.GetObject("cmdKeluar.Image"), System.Drawing.Image)
        Me.cmdKeluar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdKeluar.Location = New System.Drawing.Point(136, 317)
        Me.cmdKeluar.Name = "cmdKeluar"
        Me.cmdKeluar.Size = New System.Drawing.Size(73, 25)
        Me.cmdKeluar.TabIndex = 132
        Me.cmdKeluar.Text = "&Close"
        Me.cmdKeluar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdKeluar.UseVisualStyleBackColor = False
        '
        'BtnPilih
        '
        Me.BtnPilih.BackColor = System.Drawing.SystemColors.Control
        Me.BtnPilih.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPilih.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPilih.Location = New System.Drawing.Point(57, 317)
        Me.BtnPilih.Name = "BtnPilih"
        Me.BtnPilih.Size = New System.Drawing.Size(73, 25)
        Me.BtnPilih.TabIndex = 131
        Me.BtnPilih.Text = "&Pilih"
        Me.BtnPilih.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnPilih.UseVisualStyleBackColor = False
        '
        'FrmRef
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(345, 372)
        Me.Controls.Add(Me.GBoxReport)
        Me.Controls.Add(Me.cmdKeluar)
        Me.Controls.Add(Me.BtnPilih)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmRef"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Referensi"
        Me.GBoxReport.ResumeLayout(False)
        Me.GBoxReport.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GBoxReport As GroupBox
    Friend WithEvents RBFisRec As RadioButton
    Friend WithEvents RBWarga As RadioButton
    Friend WithEvents RBHapus As RadioButton
    Friend WithEvents RBFA As RadioButton
    Friend WithEvents RBBas As RadioButton
    Friend WithEvents RBPerush As RadioButton
    Friend WithEvents cmdKeluar As Button
    Friend WithEvents BtnPilih As Button
End Class
