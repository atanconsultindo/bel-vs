﻿Public Class FrmRef
    Private Sub BtnPilih_Click(sender As Object, e As EventArgs) Handles BtnPilih.Click
        Try

            If Me.RBPerush.Checked = True Then
                FrmCompany.ShowDialog()
            End If

            If Me.RBBas.Checked = True Then
                FrmKorek.ShowDialog()
            End If

            If Me.RBWarga.Checked = True Then
                FrmWarga.ShowDialog()
                'FrmCRptJurnal.ShowDialog()
            End If

            If Me.RBHapus.Checked = True Then
                'FrmCRptJurnal.ShowDialog()
                FrmKosong.ShowDialog()
            End If

            If Me.RBFA.Checked = True Then
                'FrmReFiscor.ShowDialog()
                MsgBox("under development", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
            End If

            If Me.RBFisRec.Checked = True Then
                'FrmCRptFisRec.ShowDialog()
            End If




            If Me.RBWarga.Checked = True Then
                'FrmCRptBB.ShowDialog()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmdKeluar_Click(sender As Object, e As EventArgs) Handles cmdKeluar.Click
        Dispose()
    End Sub
End Class