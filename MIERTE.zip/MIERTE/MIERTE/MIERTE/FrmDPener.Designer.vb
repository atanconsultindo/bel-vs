﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmDPener
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmDPener))
        Me.TxtAkun = New System.Windows.Forms.TextBox()
        Me.TxtBlnDPener = New System.Windows.Forms.TextBox()
        Me.TxtMgDPener = New System.Windows.Forms.TextBox()
        Me.TxtJenisAkun = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.TSBSave = New System.Windows.Forms.ToolStripButton()
        Me.TSBEdit = New System.Windows.Forms.ToolStripButton()
        Me.TSBDelete = New System.Windows.Forms.ToolStripButton()
        Me.TSBCancel = New System.Windows.Forms.ToolStripButton()
        Me.BtnCariRek = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DateTPDPener = New System.Windows.Forms.DateTimePicker()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.LblCabay = New System.Windows.Forms.Label()
        Me.TxtKelAkun = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtBukti = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TxtNilai = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TxtHarga = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TxtSat = New System.Windows.Forms.TextBox()
        Me.TxtVol = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CbCabay = New System.Windows.Forms.ComboBox()
        Me.TxtUrDPener = New System.Windows.Forms.TextBox()
        Me.LVDPener = New System.Windows.Forms.ListView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TxtThDPener = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.TxtPPN = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TxtTotal = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TxtDPP = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.LblTerbilang = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.MyTooltip = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'TxtAkun
        '
        Me.TxtAkun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtAkun.Location = New System.Drawing.Point(97, 74)
        Me.TxtAkun.Name = "TxtAkun"
        Me.TxtAkun.Size = New System.Drawing.Size(262, 20)
        Me.TxtAkun.TabIndex = 81
        '
        'TxtBlnDPener
        '
        Me.TxtBlnDPener.Enabled = False
        Me.TxtBlnDPener.Location = New System.Drawing.Point(226, 22)
        Me.TxtBlnDPener.Name = "TxtBlnDPener"
        Me.TxtBlnDPener.Size = New System.Drawing.Size(54, 20)
        Me.TxtBlnDPener.TabIndex = 48
        '
        'TxtMgDPener
        '
        Me.TxtMgDPener.Enabled = False
        Me.TxtMgDPener.Location = New System.Drawing.Point(343, 22)
        Me.TxtMgDPener.Name = "TxtMgDPener"
        Me.TxtMgDPener.Size = New System.Drawing.Size(70, 20)
        Me.TxtMgDPener.TabIndex = 47
        '
        'TxtJenisAkun
        '
        Me.TxtJenisAkun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtJenisAkun.Enabled = False
        Me.TxtJenisAkun.Location = New System.Drawing.Point(97, 130)
        Me.TxtJenisAkun.Name = "TxtJenisAkun"
        Me.TxtJenisAkun.Size = New System.Drawing.Size(296, 20)
        Me.TxtJenisAkun.TabIndex = 83
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(180, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 13)
        Me.Label6.TabIndex = 42
        Me.Label6.Text = "Bulan:"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBSave, Me.TSBEdit, Me.TSBDelete, Me.TSBCancel})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 156)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(852, 25)
        Me.ToolStrip1.TabIndex = 50
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'TSBSave
        '
        Me.TSBSave.Image = CType(resources.GetObject("TSBSave.Image"), System.Drawing.Image)
        Me.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSave.Name = "TSBSave"
        Me.TSBSave.Size = New System.Drawing.Size(67, 22)
        Me.TSBSave.Text = "Simpan"
        '
        'TSBEdit
        '
        Me.TSBEdit.Image = CType(resources.GetObject("TSBEdit.Image"), System.Drawing.Image)
        Me.TSBEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEdit.Name = "TSBEdit"
        Me.TSBEdit.Size = New System.Drawing.Size(47, 22)
        Me.TSBEdit.Text = "Edit"
        '
        'TSBDelete
        '
        Me.TSBDelete.Image = CType(resources.GetObject("TSBDelete.Image"), System.Drawing.Image)
        Me.TSBDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDelete.Name = "TSBDelete"
        Me.TSBDelete.Size = New System.Drawing.Size(61, 22)
        Me.TSBDelete.Text = "Hapus"
        '
        'TSBCancel
        '
        Me.TSBCancel.Image = CType(resources.GetObject("TSBCancel.Image"), System.Drawing.Image)
        Me.TSBCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCancel.Name = "TSBCancel"
        Me.TSBCancel.Size = New System.Drawing.Size(53, 22)
        Me.TSBCancel.Text = "Batal"
        '
        'BtnCariRek
        '
        Me.BtnCariRek.Image = CType(resources.GetObject("BtnCariRek.Image"), System.Drawing.Image)
        Me.BtnCariRek.Location = New System.Drawing.Point(361, 74)
        Me.BtnCariRek.Name = "BtnCariRek"
        Me.BtnCariRek.Size = New System.Drawing.Size(32, 20)
        Me.BtnCariRek.TabIndex = 80
        Me.BtnCariRek.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.DateTPDPener)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.LblCabay)
        Me.GroupBox2.Controls.Add(Me.ToolStrip1)
        Me.GroupBox2.Controls.Add(Me.TxtJenisAkun)
        Me.GroupBox2.Controls.Add(Me.TxtKelAkun)
        Me.GroupBox2.Controls.Add(Me.TxtAkun)
        Me.GroupBox2.Controls.Add(Me.BtnCariRek)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.TxtBukti)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.TxtNilai)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.TxtHarga)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.TxtSat)
        Me.GroupBox2.Controls.Add(Me.TxtVol)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.CbCabay)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 103)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(858, 184)
        Me.GroupBox2.TabIndex = 57
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Rincian Penerimaan"
        '
        'DateTPDPener
        '
        Me.DateTPDPener.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTPDPener.Location = New System.Drawing.Point(97, 21)
        Me.DateTPDPener.Name = "DateTPDPener"
        Me.DateTPDPener.Size = New System.Drawing.Size(296, 20)
        Me.DateTPDPener.TabIndex = 88
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(33, 19)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(52, 13)
        Me.Label11.TabIndex = 87
        Me.Label11.Text = "Tanggal :"
        '
        'LblCabay
        '
        Me.LblCabay.Location = New System.Drawing.Point(744, 103)
        Me.LblCabay.Name = "LblCabay"
        Me.LblCabay.Size = New System.Drawing.Size(96, 20)
        Me.LblCabay.TabIndex = 86
        Me.LblCabay.Text = "Cash/Bank/Kredit"
        '
        'TxtKelAkun
        '
        Me.TxtKelAkun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtKelAkun.Enabled = False
        Me.TxtKelAkun.Location = New System.Drawing.Point(97, 103)
        Me.TxtKelAkun.Name = "TxtKelAkun"
        Me.TxtKelAkun.Size = New System.Drawing.Size(296, 20)
        Me.TxtKelAkun.TabIndex = 82
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(14, 47)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 13)
        Me.Label7.TabIndex = 75
        Me.Label7.Text = "No Urut/Bkt :"
        '
        'TxtBukti
        '
        Me.TxtBukti.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtBukti.Location = New System.Drawing.Point(97, 47)
        Me.TxtBukti.MaxLength = 25
        Me.TxtBukti.Name = "TxtBukti"
        Me.TxtBukti.Size = New System.Drawing.Size(296, 20)
        Me.TxtBukti.TabIndex = 74
        Me.TxtBukti.Tag = ""
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.Location = New System.Drawing.Point(414, 103)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(79, 13)
        Me.Label14.TabIndex = 73
        Me.Label14.Text = "Metode Bayar :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(460, 130)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(33, 13)
        Me.Label13.TabIndex = 72
        Me.Label13.Text = "Nilai :"
        '
        'TxtNilai
        '
        Me.TxtNilai.Enabled = False
        Me.TxtNilai.Location = New System.Drawing.Point(499, 130)
        Me.TxtNilai.Name = "TxtNilai"
        Me.TxtNilai.Size = New System.Drawing.Size(323, 20)
        Me.TxtNilai.TabIndex = 71
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(451, 77)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(42, 13)
        Me.Label12.TabIndex = 70
        Me.Label12.Text = "Harga :"
        '
        'TxtHarga
        '
        Me.TxtHarga.Location = New System.Drawing.Point(499, 74)
        Me.TxtHarga.Name = "TxtHarga"
        Me.TxtHarga.Size = New System.Drawing.Size(323, 20)
        Me.TxtHarga.TabIndex = 69
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label10.Location = New System.Drawing.Point(51, 130)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(34, 13)
        Me.Label10.TabIndex = 66
        Me.Label10.Text = "Jenis:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(446, 47)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(47, 13)
        Me.Label9.TabIndex = 64
        Me.Label9.Text = "Satuan :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(407, 19)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(86, 13)
        Me.Label8.TabIndex = 63
        Me.Label8.Text = "Jumlah/Volume :"
        '
        'TxtSat
        '
        Me.TxtSat.Location = New System.Drawing.Point(499, 47)
        Me.TxtSat.Name = "TxtSat"
        Me.TxtSat.Size = New System.Drawing.Size(323, 20)
        Me.TxtSat.TabIndex = 62
        '
        'TxtVol
        '
        Me.TxtVol.Location = New System.Drawing.Point(499, 19)
        Me.TxtVol.Name = "TxtVol"
        Me.TxtVol.Size = New System.Drawing.Size(323, 20)
        Me.TxtVol.TabIndex = 61
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label5.Location = New System.Drawing.Point(28, 97)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 13)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "Kelompok:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(50, 70)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "Akun:"
        '
        'CbCabay
        '
        Me.CbCabay.AllowDrop = True
        Me.CbCabay.FormattingEnabled = True
        Me.CbCabay.Location = New System.Drawing.Point(499, 103)
        Me.CbCabay.Name = "CbCabay"
        Me.CbCabay.Size = New System.Drawing.Size(243, 21)
        Me.CbCabay.TabIndex = 56
        '
        'TxtUrDPener
        '
        Me.TxtUrDPener.Enabled = False
        Me.TxtUrDPener.Location = New System.Drawing.Point(93, 53)
        Me.TxtUrDPener.Name = "TxtUrDPener"
        Me.TxtUrDPener.Size = New System.Drawing.Size(729, 20)
        Me.TxtUrDPener.TabIndex = 39
        '
        'LVDPener
        '
        Me.LVDPener.FullRowSelect = True
        Me.LVDPener.GridLines = True
        Me.LVDPener.HideSelection = False
        Me.LVDPener.Location = New System.Drawing.Point(6, 20)
        Me.LVDPener.Name = "LVDPener"
        Me.LVDPener.Size = New System.Drawing.Size(842, 161)
        Me.LVDPener.TabIndex = 0
        Me.LVDPener.UseCompatibleStateImageBehavior = False
        Me.LVDPener.View = System.Windows.Forms.View.Details
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(289, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 13)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Minggu:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LVDPener)
        Me.GroupBox3.Location = New System.Drawing.Point(9, 300)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(856, 187)
        Me.GroupBox3.TabIndex = 58
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Data Rincian Penerimaan"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TxtThDPener)
        Me.GroupBox1.Controls.Add(Me.TxtBlnDPener)
        Me.GroupBox1.Controls.Add(Me.TxtMgDPener)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.TxtUrDPener)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 7)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(858, 90)
        Me.GroupBox1.TabIndex = 56
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Master Penerimaan"
        '
        'TxtThDPener
        '
        Me.TxtThDPener.Enabled = False
        Me.TxtThDPener.Location = New System.Drawing.Point(92, 22)
        Me.TxtThDPener.Name = "TxtThDPener"
        Me.TxtThDPener.Size = New System.Drawing.Size(79, 20)
        Me.TxtThDPener.TabIndex = 49
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(44, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Uraian:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(42, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Tahun:"
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Image = CType(resources.GetObject("BtnKeluar.Image"), System.Drawing.Image)
        Me.BtnKeluar.Location = New System.Drawing.Point(382, 631)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(75, 25)
        Me.BtnKeluar.TabIndex = 60
        Me.BtnKeluar.Text = "Keluar"
        Me.BtnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'TxtPPN
        '
        Me.TxtPPN.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtPPN.Location = New System.Drawing.Point(139, 35)
        Me.TxtPPN.Name = "TxtPPN"
        Me.TxtPPN.Size = New System.Drawing.Size(186, 13)
        Me.TxtPPN.TabIndex = 28
        Me.TxtPPN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.TxtPPN)
        Me.GroupBox4.Controls.Add(Me.TxtTotal)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.TxtDPP)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.LblTerbilang)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Location = New System.Drawing.Point(499, 495)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(344, 144)
        Me.GroupBox4.TabIndex = 59
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Resume"
        '
        'TxtTotal
        '
        Me.TxtTotal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtTotal.Enabled = False
        Me.TxtTotal.Location = New System.Drawing.Point(139, 62)
        Me.TxtTotal.Name = "TxtTotal"
        Me.TxtTotal.Size = New System.Drawing.Size(186, 13)
        Me.TxtTotal.TabIndex = 48
        Me.TxtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(33, 15)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(100, 20)
        Me.Label15.TabIndex = 24
        Me.Label15.Text = "DPP:"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'TxtDPP
        '
        Me.TxtDPP.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtDPP.Enabled = False
        Me.TxtDPP.Location = New System.Drawing.Point(139, 15)
        Me.TxtDPP.Name = "TxtDPP"
        Me.TxtDPP.Size = New System.Drawing.Size(186, 13)
        Me.TxtDPP.TabIndex = 47
        Me.TxtDPP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(33, 88)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(100, 20)
        Me.Label18.TabIndex = 27
        Me.Label18.Text = "Terbilang:"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LblTerbilang
        '
        Me.LblTerbilang.Enabled = False
        Me.LblTerbilang.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTerbilang.Location = New System.Drawing.Point(139, 88)
        Me.LblTerbilang.Name = "LblTerbilang"
        Me.LblTerbilang.Size = New System.Drawing.Size(186, 44)
        Me.LblTerbilang.TabIndex = 32
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(33, 36)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(100, 20)
        Me.Label20.TabIndex = 30
        Me.Label20.Text = "PPN:"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(33, 57)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(100, 20)
        Me.Label21.TabIndex = 31
        Me.Label21.Text = "Grand Total:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'FrmDPener
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(874, 663)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.BtnKeluar)
        Me.Controls.Add(Me.GroupBox4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmDPener"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Penerimaan Rinci"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TxtAkun As TextBox
    Friend WithEvents TxtBlnDPener As TextBox
    Friend WithEvents TxtMgDPener As TextBox
    Friend WithEvents TxtJenisAkun As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents TSBSave As ToolStripButton
    Friend WithEvents TSBEdit As ToolStripButton
    Friend WithEvents TSBDelete As ToolStripButton
    Friend WithEvents TSBCancel As ToolStripButton
    Friend WithEvents BtnCariRek As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents LblCabay As Label
    Friend WithEvents TxtKelAkun As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TxtBukti As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents TxtNilai As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents TxtHarga As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents TxtSat As TextBox
    Friend WithEvents TxtVol As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents CbCabay As ComboBox
    Friend WithEvents TxtUrDPener As TextBox
    Friend WithEvents LVDPener As ListView
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents BtnKeluar As Button
    Friend WithEvents TxtPPN As TextBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents TxtTotal As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents TxtDPP As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents LblTerbilang As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents TxtThDPener As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents DateTPDPener As DateTimePicker
    Friend WithEvents MyTooltip As ToolTip
End Class
