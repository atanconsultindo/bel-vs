﻿'Imports System.Data.OleDb
Imports System.Data.OleDb

Public Class FrmUser
    Private Sub FrmUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetDatabaseSetting()
        tampilComboBox() 'menampilkan combobox
        PosisiList()
        IsiList()
        'Aturgrid()
    End Sub

    Private Sub PosisiList()

        With LVUser.Columns
            .Add("Kode", 60)
            .Add("Nama User", 150)
            '.Add("Nama User", 90, HorizontalAlignment.Right)
            .Add("Password", 100)
            .Add("Jabatan", 100)
            .Add("Level", 100)

        End With
    End Sub

    Private Sub IsiList()
        Dim a As Integer
        Try
            query = "SELECT * FROM users  "

            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            LVUser.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVUser
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    '.Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(1), "yyyy-MM-dd"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))

                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.LightBlue
                    End If
                End With
            Next
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.OkOnly)
        End Try
    End Sub



    Private Sub TampilComboBox()
        Dim datacombo As DataTable
        datacombo = New DataTable()
        datacombo.Columns.Add("user_level")
        datacombo.Columns.Add("nama_level")

        datacombo.Rows.Add("1", "Super Admin")
        datacombo.Rows.Add("2", "Admin")
        datacombo.Rows.Add("3", "User")
        datacombo.Rows.Add("4", "Tamu")

        'datatable.Rows.Add("", "Admin")
        'datatable.Rows.Add("Supervisor")
        'datatable.Rows.Add("User")
        'datatable.Rows.Add("Operator")
        'If cbLevelUser.Items.Count > 0 Then
        '    cbLevelUser.SelectedIndex = 3   ' The first item has index 0 '
        'End If

        cbTipeUser.DataSource = datacombo
        cbTipeUser.DisplayMember = "nama_level"
        cbTipeUser.ValueMember = "user_level"
        'Me.cbLevelUser.Text = Me.cbLevelUser.Items(0).ToString
        If cbTipeUser.Items.Count > 0 Then
            cbTipeUser.SelectedIndex = 3   ' The first item has index 0 '
        End If

        'cbLevelUser.Text = "Operator"
    End Sub



    Private Sub SimpanData_User()
        Try

            query = "INSERT INTO users(username,pass,jabatan,leveluser) VALUES('" & TxtNamaUser.Text & "', '" & Kryptografi(TxtPass.Text) & "', '" & TxtJabat.Text & "', '" & Kryptografi(cbTipeUser.Text) & "') "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            'Return query
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "kenapa")
        End Try
    End Sub

    Private Sub BersihkanIsian()
        TxtNamaUser.Text = String.Empty
        TxtPass.Text = String.Empty
        TxtJabat.Text = String.Empty
        cbTipeUser.Text = String.Empty

    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Dispose()
    End Sub

    Private Sub TSBEdit_Click(sender As Object, e As EventArgs) Handles TSBEdit.Click
        Dim A As String

        'If mPosted = "UnPosted" Then
        A = MsgBox("Benar akan di-Edit", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Informasi Edit")
        Select Case A
            Case vbCancel
                TxtNamaUser.Focus()
                TSBEdit.Text = "&Edit"
                TSBSave.Enabled = True
                TSBAdd.Enabled = True
                BersihkanIsian()

                Exit Sub
            Case vbOK
                Try
                    EditUser()
                    IsiList()
                    BersihkanIsian()
                    TSBEdit.Text = "&Edit"
                    TSBSave.Enabled = True
                    TSBAdd.Enabled = True

                Catch ex As Exception
                    MsgBox("Terjadi kesalahan")
                End Try
        End Select

    End Sub
    Private Sub EditUser()
        Try
            If TxtNamaUser.Text = "" Then
                MessageBox.Show("Nama USer tidak boleh kosong", "warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TxtNamaUser.Focus()
            Else
                If TxtPass.Text = "" Then
                    MsgBox("Password tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                    TxtPass.Focus()
                Else
                    If cbTipeUser.Text = "" Then
                        MsgBox("Level user tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                        cbTipeUser.Focus()
                    Else
                        query = "UPDATE users SET password = '" & Kryptografi(TxtPass.Text) & "', jabatan = '" & TxtJabat.Text & "', level = '" & Kryptografi(cbTipeUser.Text) &
                                "' WHERE username = '" & TxtNamaUser.Text & "';"
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                    End If
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub LVUser_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVUser.SelectedIndexChanged
        Try
            AmbilDataListUser()
            TxtNamaUser.Enabled = False
            TSBSave.Enabled = False
            TSBEdit.Enabled = True
            TSBDelete.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AmbilDataListUser()
        '.Add("Kode", 60)
        '.Add("Nama User", 150)

        '.Add("Password", 100)
        '.Add("Level", 100)

        Try
            With LVUser.SelectedItems
                Try
                    'TxtNamaUser.Text = .Item(0).SubItems(0).Text
                    TxtNamaUser.Text = .Item(0).SubItems(1).Text
                    TxtPass.Text = .Item(0).SubItems(2).Text
                    TxtJabat.Text = .Item(0).SubItems(3).Text
                    cbTipeUser.Text = .Item(0).SubItems(4).Text
                Catch ex As Exception

                End Try
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBDelete_Click(sender As Object, e As EventArgs) Handles TSBDelete.Click
        Dim A As String

        'If mPosted = "UnPosted" Then
        Try
            If Len(TxtNamaUser.Text) = 0 Then
                MsgBox("Pilih data yang dihapus", MsgBoxStyle.Information, "Informasi hapus")
                TxtNamaUser.Enabled = True
                TxtNamaUser.Focus()
                TSBSave.Enabled = True
                TSBAdd.Enabled = True
                Exit Sub
            Else

                'untuk menghapus record jurnal
                A = MsgBox("Benar akan dihapus...", MsgBoxStyle.OkCancel, "Informasi")
                Select Case A
                    Case vbCancel
                        TxtNamaUser.Focus()
                        TSBEdit.Text = "&Edit"
                        TSBAdd.Text = "&New Item"
                        TxtNamaUser.Enabled = True
                        TSBSave.Enabled = True
                        TSBAdd.Enabled = True
                        Exit Sub
                    Case vbOK
                        HapusUser()
                        'HapusIsiOMDetail()
                        IsiList()
                        BersihkanIsian()
                        TxtNamaUser.Focus()

                        TSBEdit.Text = "&Edit"
                        TSBAdd.Text = "&New Item"
                        TxtNamaUser.Enabled = True
                        TSBSave.Enabled = True
                        TSBAdd.Enabled = True
                End Select
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, "Perhatian")
        End Try
        'Else
        '    MsgBox("Data ini sudah diposting, tidak bisa dihapus...", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Hapus data")
        '    tsbsave.Enabled = True
        'End If
    End Sub
    Private Sub HapusUser()
        Try

            query = "DELETE FROM users WHERE username = '" & TxtNamaUser.Text & "'"
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBAdd_Click(sender As Object, e As EventArgs) Handles TSBAdd.Click
        TxtNamaUser.Enabled = True
        TSBSave.Enabled = True
        TSBEdit.Enabled = False
        TSBDelete.Enabled = False
        BersihkanIsian()

    End Sub

    Private Sub LVUser_Click(sender As Object, e As EventArgs) Handles LVUser.Click
        TxtNamaUser.Enabled = False
        TSBSave.Enabled = False
        TSBEdit.Enabled = True
        TSBDelete.Enabled = True
    End Sub

    Private Sub TSBCancel_Click(sender As Object, e As EventArgs) Handles TSBCancel.Click
        BersihkanIsian()
    End Sub

    Private Sub TSBSave_Click(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            If TxtNamaUser.Text = "" Then
                MessageBox.Show("Nama USer tidak boleh kosong", "warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TxtNamaUser.Focus()
            Else
                If TxtPass.Text = "" Then
                    MsgBox("Password tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                    TxtPass.Focus()
                Else
                    If cbTipeUser.Text = "" Then
                        MsgBox("Level user tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                        cbTipeUser.Focus()
                    Else
                        SimpanData_User()
                        BersihkanIsian()
                        IsiList()
                        MsgBox("Data user baru tersimpan", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Pesan")

                    End If
                End If

            End If

        Catch ex As Exception
            MsgBox("Data tidak bisa tersimpan karena user sudah ada...", MsgBoxStyle.Exclamation, "Error")
            'frmPerkiraan.txtNo.Focus()
        End Try
    End Sub
End Class