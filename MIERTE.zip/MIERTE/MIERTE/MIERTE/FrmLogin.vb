﻿Imports System.Data.OleDb
Public Class FrmLogin
    Sub Terbuka()
        FrmMain.BtnUser.Enabled = False
        FrmMain.BtnLogout.Enabled = True
        'FrmMain.BtnCCR.Enabled = True
        FrmMain.BtnPro.Enabled = True
        FrmMain.BtnSawal.Enabled = True
        FrmMain.BtnTrans.Enabled = True
        FrmMain.BtnReport.Enabled = True
        'FrmMain.BtnPener.Enabled = True
        FrmMain.BtnRef.Enabled = True
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        Try
            If txtUser.Text = "" Or txtPass.Text = "" Then
                MsgBox("Kode user dan password tidak boleh kosong")
                txtUser.Focus()
            Else
                Try
                    'If conn.State = ConnectionState.Closed Then conn.Open()

                    Call GetDatabaseSetting()
                    'conn.Open()
                    cmd = New OleDbCommand("SELECT * FROM users WHERE username = '" & txtUser.Text & " ' and pass = '" & Kryptografi(txtPass.Text) & "'", conn)
                    dr = cmd.ExecuteReader
                    dr.Read()
                    If dr.HasRows Then
                        MsgBox("Login Sukses, Selamat Datang " & txtUser.Text & "!", MsgBoxStyle.Information, "Me ErTe")
                        Me.Hide()
                        FrmMain.BtnLogout.Enabled = True
                        FrmMain.BtnLogout.ForeColor = Color.White
                        FrmMain.BtnLogout.Text = txtUser.Text & " - Logout"
                        'FrmMain.ToolStripStatusUser.Text = rMe.txtUser.Text
                        FrmMain.ToolStripStatusDriver.Visible = False
                        FrmMain.ToolStripStatusLabel1.Visible = False
                        FrmMain.ToolStripStatusLabel2.Visible = False
                        'FrmMain.ToolStripStatusDriver.Font.Italic
                        'FrmMain.ToolStripStatusDriver.ForeColor = Color.DarkOrange
                        FrmMain.ToolStripStatusDb.Text = dbSources
                        FrmMain.ToolStripStatusDb.ForeColor = Color.DarkOrange

                        Call Terbuka()
                    Else
                        'Munculkan messagebox pesan salah
                        MessageBox.Show("Kombinasi Username  dan Password Salah", "E-MANSET", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        txtUser.Focus()
                    End If

                    'FrmUtama.BtnLogout.Text = CbUser.Text & " - Logout"
                    'FrmUtama.TxtProvider.Text = FrmGetDatabaseSetting.TxtProvider.Text
                    'FrmUtama.TxtDatabase.Text = FrmGetDatabaseSetting.TxtDataSource.Text
                Catch ex As Exception
                    MsgBox(ex.Message, "Pesan satu")
                End Try

            End If
        Catch ex As Exception
            'MsgBox(ex.Message, "Pesan satu")
        End Try

    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
        Me.Close()

    End Sub

    Private Sub BtnSetKon_Click(sender As Object, e As EventArgs) Handles BtnSetKon.Click
        'FrmKonekNew.ShowDialog()
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'If conn.State = ConnectionState.Open Then
        '    conn.Close()
        'End If
        GetDatabaseSetting()

        Me.txtUser.Text = "1"
        Me.txtPass.Text = "1"
    End Sub
End Class