﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmTransaksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmTransaksi))
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.TabPageKredit = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.LblBulanK = New System.Windows.Forms.Label()
        Me.CbBulanK = New System.Windows.Forms.ComboBox()
        Me.LblMingguK = New System.Windows.Forms.Label()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.TSBTambahK = New System.Windows.Forms.ToolStripButton()
        Me.TSBSaveK = New System.Windows.Forms.ToolStripButton()
        Me.TSBEditK = New System.Windows.Forms.ToolStripButton()
        Me.TSBDeleteK = New System.Windows.Forms.ToolStripButton()
        Me.TSBCancelK = New System.Windows.Forms.ToolStripButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtUraianK = New System.Windows.Forms.TextBox()
        Me.TxtTahunK = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CbMingguK = New System.Windows.Forms.ComboBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.LVHKel = New System.Windows.Forms.ListView()
        Me.TabPageTunai = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LVHPener = New System.Windows.Forms.ListView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.LblBulan = New System.Windows.Forms.Label()
        Me.CBBulan = New System.Windows.Forms.ComboBox()
        Me.LblMinggu = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.TSBTambah = New System.Windows.Forms.ToolStripButton()
        Me.TSBSave = New System.Windows.Forms.ToolStripButton()
        Me.TSBEdit = New System.Windows.Forms.ToolStripButton()
        Me.TSBDelete = New System.Windows.Forms.ToolStripButton()
        Me.TSBCancel = New System.Windows.Forms.ToolStripButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtUraian = New System.Windows.Forms.TextBox()
        Me.TxtTahun = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CbMinggu = New System.Windows.Forms.ComboBox()
        Me.TCTransaksi = New System.Windows.Forms.TabControl()
        Me.TabPageKredit.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPageTunai.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.TCTransaksi.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Image = CType(resources.GetObject("BtnKeluar.Image"), System.Drawing.Image)
        Me.BtnKeluar.Location = New System.Drawing.Point(419, 579)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(75, 25)
        Me.BtnKeluar.TabIndex = 25
        Me.BtnKeluar.Text = "Keluar"
        Me.BtnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'TabPageKredit
        '
        Me.TabPageKredit.Controls.Add(Me.GroupBox2)
        Me.TabPageKredit.Controls.Add(Me.GroupBox4)
        Me.TabPageKredit.Location = New System.Drawing.Point(4, 22)
        Me.TabPageKredit.Name = "TabPageKredit"
        Me.TabPageKredit.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageKredit.Size = New System.Drawing.Size(882, 540)
        Me.TabPageKredit.TabIndex = 1
        Me.TabPageKredit.Text = "Pengeluaran"
        Me.TabPageKredit.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.LblBulanK)
        Me.GroupBox2.Controls.Add(Me.CbBulanK)
        Me.GroupBox2.Controls.Add(Me.LblMingguK)
        Me.GroupBox2.Controls.Add(Me.ToolStrip2)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.TxtUraianK)
        Me.GroupBox2.Controls.Add(Me.TxtTahunK)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.CbMingguK)
        Me.GroupBox2.Location = New System.Drawing.Point(26, 21)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(850, 150)
        Me.GroupBox2.TabIndex = 26
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Master Pengeluaran"
        '
        'LblBulanK
        '
        Me.LblBulanK.ForeColor = System.Drawing.Color.Red
        Me.LblBulanK.Location = New System.Drawing.Point(743, 37)
        Me.LblBulanK.Name = "LblBulanK"
        Me.LblBulanK.Size = New System.Drawing.Size(100, 23)
        Me.LblBulanK.TabIndex = 49
        '
        'CbBulanK
        '
        Me.CbBulanK.FormattingEnabled = True
        Me.CbBulanK.Location = New System.Drawing.Point(150, 41)
        Me.CbBulanK.Name = "CbBulanK"
        Me.CbBulanK.Size = New System.Drawing.Size(580, 21)
        Me.CbBulanK.TabIndex = 48
        '
        'LblMingguK
        '
        Me.LblMingguK.ForeColor = System.Drawing.Color.Red
        Me.LblMingguK.Location = New System.Drawing.Point(736, 66)
        Me.LblMingguK.Name = "LblMingguK"
        Me.LblMingguK.Size = New System.Drawing.Size(100, 23)
        Me.LblMingguK.TabIndex = 47
        '
        'ToolStrip2
        '
        Me.ToolStrip2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBTambahK, Me.TSBSaveK, Me.TSBEditK, Me.TSBDeleteK, Me.TSBCancelK})
        Me.ToolStrip2.Location = New System.Drawing.Point(3, 122)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(844, 25)
        Me.ToolStrip2.TabIndex = 20
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'TSBTambahK
        '
        Me.TSBTambahK.Image = CType(resources.GetObject("TSBTambahK.Image"), System.Drawing.Image)
        Me.TSBTambahK.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBTambahK.Name = "TSBTambahK"
        Me.TSBTambahK.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TSBTambahK.Size = New System.Drawing.Size(69, 22)
        Me.TSBTambahK.Text = "Tambah"
        Me.TSBTambahK.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'TSBSaveK
        '
        Me.TSBSaveK.Image = CType(resources.GetObject("TSBSaveK.Image"), System.Drawing.Image)
        Me.TSBSaveK.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSaveK.Name = "TSBSaveK"
        Me.TSBSaveK.Size = New System.Drawing.Size(67, 22)
        Me.TSBSaveK.Text = "Simpan"
        '
        'TSBEditK
        '
        Me.TSBEditK.Image = CType(resources.GetObject("TSBEditK.Image"), System.Drawing.Image)
        Me.TSBEditK.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEditK.Name = "TSBEditK"
        Me.TSBEditK.Size = New System.Drawing.Size(47, 22)
        Me.TSBEditK.Text = "Edit"
        '
        'TSBDeleteK
        '
        Me.TSBDeleteK.Image = CType(resources.GetObject("TSBDeleteK.Image"), System.Drawing.Image)
        Me.TSBDeleteK.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDeleteK.Name = "TSBDeleteK"
        Me.TSBDeleteK.Size = New System.Drawing.Size(61, 22)
        Me.TSBDeleteK.Text = "Hapus"
        '
        'TSBCancelK
        '
        Me.TSBCancelK.Image = CType(resources.GetObject("TSBCancelK.Image"), System.Drawing.Image)
        Me.TSBCancelK.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCancelK.Name = "TSBCancelK"
        Me.TSBCancelK.Size = New System.Drawing.Size(53, 22)
        Me.TSBCancelK.Text = "Batal"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(96, 23)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 13)
        Me.Label7.TabIndex = 42
        Me.Label7.Text = "Tahun:"
        '
        'TxtUraianK
        '
        Me.TxtUraianK.Location = New System.Drawing.Point(150, 91)
        Me.TxtUraianK.Name = "TxtUraianK"
        Me.TxtUraianK.Size = New System.Drawing.Size(580, 20)
        Me.TxtUraianK.TabIndex = 39
        '
        'TxtTahunK
        '
        Me.TxtTahunK.Enabled = False
        Me.TxtTahunK.Location = New System.Drawing.Point(150, 17)
        Me.TxtTahunK.Name = "TxtTahunK"
        Me.TxtTahunK.Size = New System.Drawing.Size(580, 20)
        Me.TxtTahunK.TabIndex = 38
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(92, 69)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 13)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = "Minggu:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(96, 92)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(41, 13)
        Me.Label9.TabIndex = 34
        Me.Label9.Text = "Uraian:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(100, 46)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(37, 13)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "Bulan:"
        '
        'CbMingguK
        '
        Me.CbMingguK.FormattingEnabled = True
        Me.CbMingguK.Location = New System.Drawing.Point(150, 66)
        Me.CbMingguK.Name = "CbMingguK"
        Me.CbMingguK.Size = New System.Drawing.Size(580, 21)
        Me.CbMingguK.TabIndex = 28
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.LVHKel)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.Red
        Me.GroupBox4.Location = New System.Drawing.Point(23, 177)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(850, 357)
        Me.GroupBox4.TabIndex = 25
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Data Pengeluaran (Klik 2x Pada Baris Untuk Rincian)"
        '
        'LVHKel
        '
        Me.LVHKel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LVHKel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LVHKel.FullRowSelect = True
        Me.LVHKel.GridLines = True
        Me.LVHKel.HideSelection = False
        Me.LVHKel.Location = New System.Drawing.Point(16, 20)
        Me.LVHKel.MultiSelect = False
        Me.LVHKel.Name = "LVHKel"
        Me.LVHKel.Size = New System.Drawing.Size(827, 331)
        Me.LVHKel.TabIndex = 0
        Me.LVHKel.UseCompatibleStateImageBehavior = False
        Me.LVHKel.View = System.Windows.Forms.View.Details
        '
        'TabPageTunai
        '
        Me.TabPageTunai.Controls.Add(Me.GroupBox3)
        Me.TabPageTunai.Controls.Add(Me.GroupBox1)
        Me.TabPageTunai.Location = New System.Drawing.Point(4, 22)
        Me.TabPageTunai.Name = "TabPageTunai"
        Me.TabPageTunai.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageTunai.Size = New System.Drawing.Size(882, 540)
        Me.TabPageTunai.TabIndex = 0
        Me.TabPageTunai.Text = "Penerimaan"
        Me.TabPageTunai.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LVHPener)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.Red
        Me.GroupBox3.Location = New System.Drawing.Point(7, 170)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(850, 357)
        Me.GroupBox3.TabIndex = 23
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Data Penerimaan (Klik 2x Pada Baris Untuk Rincian)"
        '
        'LVHPener
        '
        Me.LVHPener.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LVHPener.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LVHPener.FullRowSelect = True
        Me.LVHPener.GridLines = True
        Me.LVHPener.HideSelection = False
        Me.LVHPener.Location = New System.Drawing.Point(16, 20)
        Me.LVHPener.MultiSelect = False
        Me.LVHPener.Name = "LVHPener"
        Me.LVHPener.Size = New System.Drawing.Size(827, 331)
        Me.LVHPener.TabIndex = 0
        Me.LVHPener.UseCompatibleStateImageBehavior = False
        Me.LVHPener.View = System.Windows.Forms.View.Details
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.LblBulan)
        Me.GroupBox1.Controls.Add(Me.CBBulan)
        Me.GroupBox1.Controls.Add(Me.LblMinggu)
        Me.GroupBox1.Controls.Add(Me.ToolStrip1)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.TxtUraian)
        Me.GroupBox1.Controls.Add(Me.TxtTahun)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.CbMinggu)
        Me.GroupBox1.Location = New System.Drawing.Point(7, 11)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(850, 150)
        Me.GroupBox1.TabIndex = 21
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Master Penerimaan"
        '
        'LblBulan
        '
        Me.LblBulan.ForeColor = System.Drawing.Color.Red
        Me.LblBulan.Location = New System.Drawing.Point(743, 37)
        Me.LblBulan.Name = "LblBulan"
        Me.LblBulan.Size = New System.Drawing.Size(100, 23)
        Me.LblBulan.TabIndex = 49
        '
        'CBBulan
        '
        Me.CBBulan.FormattingEnabled = True
        Me.CBBulan.Location = New System.Drawing.Point(150, 41)
        Me.CBBulan.Name = "CBBulan"
        Me.CBBulan.Size = New System.Drawing.Size(580, 21)
        Me.CBBulan.TabIndex = 48
        '
        'LblMinggu
        '
        Me.LblMinggu.ForeColor = System.Drawing.Color.Red
        Me.LblMinggu.Location = New System.Drawing.Point(736, 66)
        Me.LblMinggu.Name = "LblMinggu"
        Me.LblMinggu.Size = New System.Drawing.Size(100, 23)
        Me.LblMinggu.TabIndex = 47
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBTambah, Me.TSBSave, Me.TSBEdit, Me.TSBDelete, Me.TSBCancel})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 122)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(844, 25)
        Me.ToolStrip1.TabIndex = 20
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'TSBTambah
        '
        Me.TSBTambah.Image = CType(resources.GetObject("TSBTambah.Image"), System.Drawing.Image)
        Me.TSBTambah.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBTambah.Name = "TSBTambah"
        Me.TSBTambah.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TSBTambah.Size = New System.Drawing.Size(69, 22)
        Me.TSBTambah.Text = "Tambah"
        Me.TSBTambah.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'TSBSave
        '
        Me.TSBSave.Image = CType(resources.GetObject("TSBSave.Image"), System.Drawing.Image)
        Me.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSave.Name = "TSBSave"
        Me.TSBSave.Size = New System.Drawing.Size(67, 22)
        Me.TSBSave.Text = "Simpan"
        '
        'TSBEdit
        '
        Me.TSBEdit.Image = CType(resources.GetObject("TSBEdit.Image"), System.Drawing.Image)
        Me.TSBEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEdit.Name = "TSBEdit"
        Me.TSBEdit.Size = New System.Drawing.Size(47, 22)
        Me.TSBEdit.Text = "Edit"
        '
        'TSBDelete
        '
        Me.TSBDelete.Image = CType(resources.GetObject("TSBDelete.Image"), System.Drawing.Image)
        Me.TSBDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDelete.Name = "TSBDelete"
        Me.TSBDelete.Size = New System.Drawing.Size(61, 22)
        Me.TSBDelete.Text = "Hapus"
        '
        'TSBCancel
        '
        Me.TSBCancel.Image = CType(resources.GetObject("TSBCancel.Image"), System.Drawing.Image)
        Me.TSBCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCancel.Name = "TSBCancel"
        Me.TSBCancel.Size = New System.Drawing.Size(53, 22)
        Me.TSBCancel.Text = "Batal"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(96, 23)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 13)
        Me.Label6.TabIndex = 42
        Me.Label6.Text = "Tahun:"
        '
        'TxtUraian
        '
        Me.TxtUraian.Location = New System.Drawing.Point(150, 91)
        Me.TxtUraian.Name = "TxtUraian"
        Me.TxtUraian.Size = New System.Drawing.Size(580, 20)
        Me.TxtUraian.TabIndex = 39
        '
        'TxtTahun
        '
        Me.TxtTahun.Enabled = False
        Me.TxtTahun.Location = New System.Drawing.Point(150, 17)
        Me.TxtTahun.Name = "TxtTahun"
        Me.TxtTahun.Size = New System.Drawing.Size(580, 20)
        Me.TxtTahun.TabIndex = 38
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(92, 69)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 13)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Minggu:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(96, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Uraian:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(100, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Bulan:"
        '
        'CbMinggu
        '
        Me.CbMinggu.FormattingEnabled = True
        Me.CbMinggu.Location = New System.Drawing.Point(150, 66)
        Me.CbMinggu.Name = "CbMinggu"
        Me.CbMinggu.Size = New System.Drawing.Size(580, 21)
        Me.CbMinggu.TabIndex = 28
        '
        'TCTransaksi
        '
        Me.TCTransaksi.Controls.Add(Me.TabPageTunai)
        Me.TCTransaksi.Controls.Add(Me.TabPageKredit)
        Me.TCTransaksi.Location = New System.Drawing.Point(5, 11)
        Me.TCTransaksi.Name = "TCTransaksi"
        Me.TCTransaksi.SelectedIndex = 0
        Me.TCTransaksi.Size = New System.Drawing.Size(890, 566)
        Me.TCTransaksi.TabIndex = 24
        '
        'FrmTransaksi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 614)
        Me.Controls.Add(Me.BtnKeluar)
        Me.Controls.Add(Me.TCTransaksi)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmTransaksi"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Transaksi"
        Me.TabPageKredit.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.TabPageTunai.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.TCTransaksi.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BtnKeluar As Button
    Friend WithEvents TabPageKredit As TabPage
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents LVHKel As ListView
    Friend WithEvents TabPageTunai As TabPage
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents LVHPener As ListView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents LblMinggu As Label
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents TSBTambah As ToolStripButton
    Friend WithEvents TSBSave As ToolStripButton
    Friend WithEvents TSBEdit As ToolStripButton
    Friend WithEvents TSBDelete As ToolStripButton
    Friend WithEvents TSBCancel As ToolStripButton
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtUraian As TextBox
    Friend WithEvents TxtTahun As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents CbMinggu As ComboBox
    Friend WithEvents TCTransaksi As TabControl
    Friend WithEvents CBBulan As ComboBox
    Friend WithEvents LblBulan As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents LblBulanK As Label
    Friend WithEvents CbBulanK As ComboBox
    Friend WithEvents LblMingguK As Label
    Friend WithEvents ToolStrip2 As ToolStrip
    Friend WithEvents TSBTambahK As ToolStripButton
    Friend WithEvents TSBSaveK As ToolStripButton
    Friend WithEvents TSBEditK As ToolStripButton
    Friend WithEvents TSBDeleteK As ToolStripButton
    Friend WithEvents TSBCancelK As ToolStripButton
    Friend WithEvents Label7 As Label
    Friend WithEvents TxtUraianK As TextBox
    Friend WithEvents TxtTahunK As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents CbMingguK As ComboBox
End Class
