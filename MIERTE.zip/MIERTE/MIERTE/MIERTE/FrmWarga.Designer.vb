﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmWarga
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmWarga))
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.TSBTambah = New System.Windows.Forms.ToolStripButton()
        Me.TSBSave = New System.Windows.Forms.ToolStripButton()
        Me.TSBEdit = New System.Windows.Forms.ToolStripButton()
        Me.TSBDelete = New System.Windows.Forms.ToolStripButton()
        Me.TSBCancel = New System.Windows.Forms.ToolStripButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LVAg = New System.Windows.Forms.ListView()
        Me.LblStatus = New System.Windows.Forms.Label()
        Me.CbJk = New System.Windows.Forms.ComboBox()
        Me.TxtTelp = New System.Windows.Forms.MaskedTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtJumlah = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtAlamat = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtNama = New System.Windows.Forms.TextBox()
        Me.TxtNoKK = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CbStatus = New System.Windows.Forms.ComboBox()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Image = CType(resources.GetObject("BtnKeluar.Image"), System.Drawing.Image)
        Me.BtnKeluar.Location = New System.Drawing.Point(395, 560)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(75, 25)
        Me.BtnKeluar.TabIndex = 28
        Me.BtnKeluar.Text = "Keluar"
        Me.BtnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBTambah, Me.TSBSave, Me.TSBEdit, Me.TSBDelete, Me.TSBCancel})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 199)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(844, 25)
        Me.ToolStrip1.TabIndex = 56
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'TSBTambah
        '
        Me.TSBTambah.Image = CType(resources.GetObject("TSBTambah.Image"), System.Drawing.Image)
        Me.TSBTambah.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBTambah.Name = "TSBTambah"
        Me.TSBTambah.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TSBTambah.Size = New System.Drawing.Size(69, 22)
        Me.TSBTambah.Text = "Tambah"
        Me.TSBTambah.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'TSBSave
        '
        Me.TSBSave.Image = CType(resources.GetObject("TSBSave.Image"), System.Drawing.Image)
        Me.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSave.Name = "TSBSave"
        Me.TSBSave.Size = New System.Drawing.Size(67, 22)
        Me.TSBSave.Text = "Simpan"
        '
        'TSBEdit
        '
        Me.TSBEdit.Image = CType(resources.GetObject("TSBEdit.Image"), System.Drawing.Image)
        Me.TSBEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEdit.Name = "TSBEdit"
        Me.TSBEdit.Size = New System.Drawing.Size(47, 22)
        Me.TSBEdit.Text = "Edit"
        '
        'TSBDelete
        '
        Me.TSBDelete.Image = CType(resources.GetObject("TSBDelete.Image"), System.Drawing.Image)
        Me.TSBDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDelete.Name = "TSBDelete"
        Me.TSBDelete.Size = New System.Drawing.Size(61, 22)
        Me.TSBDelete.Text = "Hapus"
        '
        'TSBCancel
        '
        Me.TSBCancel.Image = CType(resources.GetObject("TSBCancel.Image"), System.Drawing.Image)
        Me.TSBCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCancel.Name = "TSBCancel"
        Me.TSBCancel.Size = New System.Drawing.Size(53, 22)
        Me.TSBCancel.Text = "Batal"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LVAg)
        Me.GroupBox3.Location = New System.Drawing.Point(13, 244)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(850, 288)
        Me.GroupBox3.TabIndex = 27
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Data Anggota SPP"
        '
        'LVAg
        '
        Me.LVAg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LVAg.FullRowSelect = True
        Me.LVAg.GridLines = True
        Me.LVAg.HideSelection = False
        Me.LVAg.Location = New System.Drawing.Point(16, 26)
        Me.LVAg.MultiSelect = False
        Me.LVAg.Name = "LVAg"
        Me.LVAg.Size = New System.Drawing.Size(827, 240)
        Me.LVAg.TabIndex = 0
        Me.LVAg.UseCompatibleStateImageBehavior = False
        Me.LVAg.View = System.Windows.Forms.View.Details
        '
        'LblStatus
        '
        Me.LblStatus.Location = New System.Drawing.Point(504, 136)
        Me.LblStatus.Name = "LblStatus"
        Me.LblStatus.Size = New System.Drawing.Size(142, 23)
        Me.LblStatus.TabIndex = 55
        '
        'CbJk
        '
        Me.CbJk.FormattingEnabled = True
        Me.CbJk.Items.AddRange(New Object() {"Laki-Laki", "Perempuan"})
        Me.CbJk.Location = New System.Drawing.Point(140, 65)
        Me.CbJk.Name = "CbJk"
        Me.CbJk.Size = New System.Drawing.Size(358, 21)
        Me.CbJk.TabIndex = 54
        '
        'TxtTelp
        '
        Me.TxtTelp.Location = New System.Drawing.Point(140, 114)
        Me.TxtTelp.Name = "TxtTelp"
        Me.TxtTelp.Size = New System.Drawing.Size(358, 20)
        Me.TxtTelp.TabIndex = 53
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(38, 166)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(86, 13)
        Me.Label7.TabIndex = 52
        Me.Label7.Text = "Jumlah Anggota:"
        '
        'TxtJumlah
        '
        Me.TxtJumlah.Location = New System.Drawing.Point(140, 163)
        Me.TxtJumlah.Name = "TxtJumlah"
        Me.TxtJumlah.Size = New System.Drawing.Size(358, 20)
        Me.TxtJumlah.TabIndex = 51
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(50, 66)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 13)
        Me.Label5.TabIndex = 49
        Me.Label5.Text = "Jenis Kalamin:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(75, 116)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 46
        Me.Label4.Text = "Telepon:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(82, 91)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "Alamat:"
        '
        'TxtAlamat
        '
        Me.TxtAlamat.Location = New System.Drawing.Point(140, 90)
        Me.TxtAlamat.Name = "TxtAlamat"
        Me.TxtAlamat.Size = New System.Drawing.Size(358, 20)
        Me.TxtAlamat.TabIndex = 43
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(83, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 13)
        Me.Label6.TabIndex = 42
        Me.Label6.Text = "No KK:"
        '
        'TxtNama
        '
        Me.TxtNama.Location = New System.Drawing.Point(140, 41)
        Me.TxtNama.Name = "TxtNama"
        Me.TxtNama.Size = New System.Drawing.Size(358, 20)
        Me.TxtNama.TabIndex = 39
        '
        'TxtNoKK
        '
        Me.TxtNoKK.Location = New System.Drawing.Point(140, 17)
        Me.TxtNoKK.Name = "TxtNoKK"
        Me.TxtNoKK.Size = New System.Drawing.Size(358, 20)
        Me.TxtNoKK.TabIndex = 38
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(69, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Nama KK:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CbStatus)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.ToolStrip1)
        Me.GroupBox1.Controls.Add(Me.LblStatus)
        Me.GroupBox1.Controls.Add(Me.CbJk)
        Me.GroupBox1.Controls.Add(Me.TxtTelp)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.TxtJumlah)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TxtAlamat)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.TxtNama)
        Me.GroupBox1.Controls.Add(Me.TxtNoKK)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(850, 227)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Warga RT"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(84, 141)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 57
        Me.Label3.Text = "Status:"
        '
        'CbStatus
        '
        Me.CbStatus.FormattingEnabled = True
        Me.CbStatus.Location = New System.Drawing.Point(140, 138)
        Me.CbStatus.Name = "CbStatus"
        Me.CbStatus.Size = New System.Drawing.Size(358, 21)
        Me.CbStatus.TabIndex = 58
        '
        'FrmWarga
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(877, 590)
        Me.Controls.Add(Me.BtnKeluar)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmWarga"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Daftar Warga"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnKeluar As Button
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents TSBTambah As ToolStripButton
    Friend WithEvents TSBSave As ToolStripButton
    Friend WithEvents TSBEdit As ToolStripButton
    Friend WithEvents TSBDelete As ToolStripButton
    Friend WithEvents TSBCancel As ToolStripButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents LVAg As ListView
    Friend WithEvents LblStatus As Label
    Friend WithEvents CbJk As ComboBox
    Friend WithEvents TxtTelp As MaskedTextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TxtJumlah As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtAlamat As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtNama As TextBox
    Friend WithEvents TxtNoKK As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents CbStatus As ComboBox
End Class
