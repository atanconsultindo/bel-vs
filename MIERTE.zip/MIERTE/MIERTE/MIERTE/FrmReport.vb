﻿Public Class FrmReport
    Private Sub BtnPilih_Click(sender As Object, e As EventArgs) Handles BtnPilih.Click
        Try

            If Me.RBNeraca.Checked = True Then
                'MsgBox("Under construction", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
                'FrmCompany.ShowDialog()
                FrmCRptPoskeu.ShowDialog()
            End If

            If Me.RBOper.Checked = True Then
                FrmCRptTranKas.ShowDialog()
                'FrmKorek.ShowDialog()
            End If

            If Me.RBLak.Checked = True Then
                MsgBox("Under construction", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
                'FrmWarga.ShowDialog()
                'FrmCRptJurnal.ShowDialog()
            End If

            If Me.RBProyek.Checked = True Then
                MsgBox("Under construction", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
                'FrmCRptJurnal.ShowDialog()
                'FrmKosong.ShowDialog()
            End If

            If Me.RBBulan.Checked = True Then
                'FrmReFiscor.ShowDialog()
                MsgBox("under development", MsgBoxStyle.Information + MsgBoxStyle.OkOnly)
            End If

            If Me.RBHari.Checked = True Then
                'FrmCRptFisRec.ShowDialog()
            End If




            If Me.RBLak.Checked = True Then
                'FrmCRptBB.ShowDialog()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmdKeluar_Click(sender As Object, e As EventArgs) Handles cmdKeluar.Click
        Dispose()
    End Sub
End Class