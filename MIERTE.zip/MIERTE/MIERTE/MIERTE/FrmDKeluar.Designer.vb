﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmDKeluar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmDKeluar))
        Me.Label20 = New System.Windows.Forms.Label()
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.TxtPPN = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TxtTotal = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TxtDPP = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.LblTerbilang = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.LVKeluarD = New System.Windows.Forms.ListView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TxtThKeluarD = New System.Windows.Forms.TextBox()
        Me.TxtBlnKeluarD = New System.Windows.Forms.TextBox()
        Me.TxtMgKeluarD = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtUrKeluarD = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.DateTPKeluarD = New System.Windows.Forms.DateTimePicker()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.LblCabay = New System.Windows.Forms.Label()
        Me.TxtKelAkun = New System.Windows.Forms.TextBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.TSBSave = New System.Windows.Forms.ToolStripButton()
        Me.TSBEdit = New System.Windows.Forms.ToolStripButton()
        Me.TSBDelete = New System.Windows.Forms.ToolStripButton()
        Me.TSBCancel = New System.Windows.Forms.ToolStripButton()
        Me.TxtJenisAkun = New System.Windows.Forms.TextBox()
        Me.TxtAkun = New System.Windows.Forms.TextBox()
        Me.TxtBukti = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TxtNilai = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TxtHarga = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.BtnCariRek = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TxtSat = New System.Windows.Forms.TextBox()
        Me.TxtVol = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.CbCabay = New System.Windows.Forms.ComboBox()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(33, 36)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(100, 20)
        Me.Label20.TabIndex = 30
        Me.Label20.Text = "PPN:"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Image = CType(resources.GetObject("BtnKeluar.Image"), System.Drawing.Image)
        Me.BtnKeluar.Location = New System.Drawing.Point(382, 631)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(75, 25)
        Me.BtnKeluar.TabIndex = 65
        Me.BtnKeluar.Text = "Keluar"
        Me.BtnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'TxtPPN
        '
        Me.TxtPPN.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtPPN.Location = New System.Drawing.Point(139, 35)
        Me.TxtPPN.Name = "TxtPPN"
        Me.TxtPPN.Size = New System.Drawing.Size(186, 13)
        Me.TxtPPN.TabIndex = 28
        Me.TxtPPN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.TxtPPN)
        Me.GroupBox4.Controls.Add(Me.TxtTotal)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.TxtDPP)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.LblTerbilang)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Location = New System.Drawing.Point(513, 493)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(344, 144)
        Me.GroupBox4.TabIndex = 64
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Resume"
        '
        'TxtTotal
        '
        Me.TxtTotal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtTotal.Enabled = False
        Me.TxtTotal.Location = New System.Drawing.Point(139, 62)
        Me.TxtTotal.Name = "TxtTotal"
        Me.TxtTotal.Size = New System.Drawing.Size(186, 13)
        Me.TxtTotal.TabIndex = 48
        Me.TxtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(33, 15)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(100, 20)
        Me.Label15.TabIndex = 24
        Me.Label15.Text = "DPP:"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'TxtDPP
        '
        Me.TxtDPP.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtDPP.Enabled = False
        Me.TxtDPP.Location = New System.Drawing.Point(139, 15)
        Me.TxtDPP.Name = "TxtDPP"
        Me.TxtDPP.Size = New System.Drawing.Size(186, 13)
        Me.TxtDPP.TabIndex = 47
        Me.TxtDPP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(33, 88)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(100, 20)
        Me.Label18.TabIndex = 27
        Me.Label18.Text = "Terbilang:"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LblTerbilang
        '
        Me.LblTerbilang.Enabled = False
        Me.LblTerbilang.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTerbilang.Location = New System.Drawing.Point(139, 88)
        Me.LblTerbilang.Name = "LblTerbilang"
        Me.LblTerbilang.Size = New System.Drawing.Size(186, 44)
        Me.LblTerbilang.TabIndex = 32
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(33, 57)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(100, 20)
        Me.Label21.TabIndex = 31
        Me.Label21.Text = "Grand Total:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LVKeluarD
        '
        Me.LVKeluarD.FullRowSelect = True
        Me.LVKeluarD.GridLines = True
        Me.LVKeluarD.HideSelection = False
        Me.LVKeluarD.Location = New System.Drawing.Point(6, 20)
        Me.LVKeluarD.Name = "LVKeluarD"
        Me.LVKeluarD.Size = New System.Drawing.Size(842, 161)
        Me.LVKeluarD.TabIndex = 0
        Me.LVKeluarD.UseCompatibleStateImageBehavior = False
        Me.LVKeluarD.View = System.Windows.Forms.View.Details
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(289, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 13)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Minggu:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LVKeluarD)
        Me.GroupBox3.Location = New System.Drawing.Point(7, 293)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(856, 187)
        Me.GroupBox3.TabIndex = 68
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Data Rincian Penerimaan"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TxtThKeluarD)
        Me.GroupBox1.Controls.Add(Me.TxtBlnKeluarD)
        Me.GroupBox1.Controls.Add(Me.TxtMgKeluarD)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.TxtUrKeluarD)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 7)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(858, 90)
        Me.GroupBox1.TabIndex = 66
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Master Pengeluaran"
        '
        'TxtThKeluarD
        '
        Me.TxtThKeluarD.Enabled = False
        Me.TxtThKeluarD.Location = New System.Drawing.Point(92, 22)
        Me.TxtThKeluarD.Name = "TxtThKeluarD"
        Me.TxtThKeluarD.Size = New System.Drawing.Size(79, 20)
        Me.TxtThKeluarD.TabIndex = 49
        '
        'TxtBlnKeluarD
        '
        Me.TxtBlnKeluarD.Enabled = False
        Me.TxtBlnKeluarD.Location = New System.Drawing.Point(226, 22)
        Me.TxtBlnKeluarD.Name = "TxtBlnKeluarD"
        Me.TxtBlnKeluarD.Size = New System.Drawing.Size(54, 20)
        Me.TxtBlnKeluarD.TabIndex = 48
        '
        'TxtMgKeluarD
        '
        Me.TxtMgKeluarD.Enabled = False
        Me.TxtMgKeluarD.Location = New System.Drawing.Point(343, 22)
        Me.TxtMgKeluarD.Name = "TxtMgKeluarD"
        Me.TxtMgKeluarD.Size = New System.Drawing.Size(70, 20)
        Me.TxtMgKeluarD.TabIndex = 47
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(180, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 13)
        Me.Label6.TabIndex = 42
        Me.Label6.Text = "Bulan:"
        '
        'TxtUrKeluarD
        '
        Me.TxtUrKeluarD.Enabled = False
        Me.TxtUrKeluarD.Location = New System.Drawing.Point(93, 53)
        Me.TxtUrKeluarD.Name = "TxtUrKeluarD"
        Me.TxtUrKeluarD.Size = New System.Drawing.Size(729, 20)
        Me.TxtUrKeluarD.TabIndex = 39
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(44, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Uraian:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(42, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "Tahun:"
        '
        'DateTPKeluarD
        '
        Me.DateTPKeluarD.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTPKeluarD.Location = New System.Drawing.Point(97, 21)
        Me.DateTPKeluarD.Name = "DateTPKeluarD"
        Me.DateTPKeluarD.Size = New System.Drawing.Size(296, 20)
        Me.DateTPKeluarD.TabIndex = 88
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(33, 19)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(52, 13)
        Me.Label11.TabIndex = 87
        Me.Label11.Text = "Tanggal :"
        '
        'LblCabay
        '
        Me.LblCabay.Location = New System.Drawing.Point(744, 103)
        Me.LblCabay.Name = "LblCabay"
        Me.LblCabay.Size = New System.Drawing.Size(96, 20)
        Me.LblCabay.TabIndex = 86
        Me.LblCabay.Text = "Cash/Bank/Kredit"
        '
        'TxtKelAkun
        '
        Me.TxtKelAkun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtKelAkun.Enabled = False
        Me.TxtKelAkun.Location = New System.Drawing.Point(97, 103)
        Me.TxtKelAkun.Name = "TxtKelAkun"
        Me.TxtKelAkun.Size = New System.Drawing.Size(296, 20)
        Me.TxtKelAkun.TabIndex = 82
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBSave, Me.TSBEdit, Me.TSBDelete, Me.TSBCancel})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 156)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(852, 25)
        Me.ToolStrip1.TabIndex = 50
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'TSBSave
        '
        Me.TSBSave.Image = CType(resources.GetObject("TSBSave.Image"), System.Drawing.Image)
        Me.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSave.Name = "TSBSave"
        Me.TSBSave.Size = New System.Drawing.Size(67, 22)
        Me.TSBSave.Text = "Simpan"
        '
        'TSBEdit
        '
        Me.TSBEdit.Image = CType(resources.GetObject("TSBEdit.Image"), System.Drawing.Image)
        Me.TSBEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEdit.Name = "TSBEdit"
        Me.TSBEdit.Size = New System.Drawing.Size(47, 22)
        Me.TSBEdit.Text = "Edit"
        '
        'TSBDelete
        '
        Me.TSBDelete.Image = CType(resources.GetObject("TSBDelete.Image"), System.Drawing.Image)
        Me.TSBDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDelete.Name = "TSBDelete"
        Me.TSBDelete.Size = New System.Drawing.Size(61, 22)
        Me.TSBDelete.Text = "Hapus"
        '
        'TSBCancel
        '
        Me.TSBCancel.Image = CType(resources.GetObject("TSBCancel.Image"), System.Drawing.Image)
        Me.TSBCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCancel.Name = "TSBCancel"
        Me.TSBCancel.Size = New System.Drawing.Size(53, 22)
        Me.TSBCancel.Text = "Batal"
        '
        'TxtJenisAkun
        '
        Me.TxtJenisAkun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtJenisAkun.Enabled = False
        Me.TxtJenisAkun.Location = New System.Drawing.Point(97, 130)
        Me.TxtJenisAkun.Name = "TxtJenisAkun"
        Me.TxtJenisAkun.Size = New System.Drawing.Size(296, 20)
        Me.TxtJenisAkun.TabIndex = 83
        '
        'TxtAkun
        '
        Me.TxtAkun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtAkun.Location = New System.Drawing.Point(97, 74)
        Me.TxtAkun.Name = "TxtAkun"
        Me.TxtAkun.Size = New System.Drawing.Size(262, 20)
        Me.TxtAkun.TabIndex = 81
        '
        'TxtBukti
        '
        Me.TxtBukti.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtBukti.Location = New System.Drawing.Point(97, 47)
        Me.TxtBukti.MaxLength = 25
        Me.TxtBukti.Name = "TxtBukti"
        Me.TxtBukti.Size = New System.Drawing.Size(296, 20)
        Me.TxtBukti.TabIndex = 74
        Me.TxtBukti.Tag = ""
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 47)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(71, 13)
        Me.Label10.TabIndex = 75
        Me.Label10.Text = "No Urut/Bkt :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.Location = New System.Drawing.Point(414, 103)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(79, 13)
        Me.Label14.TabIndex = 73
        Me.Label14.Text = "Metode Bayar :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(460, 130)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(33, 13)
        Me.Label13.TabIndex = 72
        Me.Label13.Text = "Nilai :"
        '
        'TxtNilai
        '
        Me.TxtNilai.Enabled = False
        Me.TxtNilai.Location = New System.Drawing.Point(499, 130)
        Me.TxtNilai.Name = "TxtNilai"
        Me.TxtNilai.Size = New System.Drawing.Size(323, 20)
        Me.TxtNilai.TabIndex = 71
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(451, 77)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(42, 13)
        Me.Label12.TabIndex = 70
        Me.Label12.Text = "Harga :"
        '
        'TxtHarga
        '
        Me.TxtHarga.Location = New System.Drawing.Point(499, 74)
        Me.TxtHarga.Name = "TxtHarga"
        Me.TxtHarga.Size = New System.Drawing.Size(323, 20)
        Me.TxtHarga.TabIndex = 69
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label16.Location = New System.Drawing.Point(51, 130)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(34, 13)
        Me.Label16.TabIndex = 66
        Me.Label16.Text = "Jenis:"
        '
        'BtnCariRek
        '
        Me.BtnCariRek.Image = CType(resources.GetObject("BtnCariRek.Image"), System.Drawing.Image)
        Me.BtnCariRek.Location = New System.Drawing.Point(361, 74)
        Me.BtnCariRek.Name = "BtnCariRek"
        Me.BtnCariRek.Size = New System.Drawing.Size(32, 20)
        Me.BtnCariRek.TabIndex = 80
        Me.BtnCariRek.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(446, 47)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(47, 13)
        Me.Label17.TabIndex = 64
        Me.Label17.Text = "Satuan :"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.DateTPKeluarD)
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Controls.Add(Me.LblCabay)
        Me.GroupBox5.Controls.Add(Me.ToolStrip1)
        Me.GroupBox5.Controls.Add(Me.TxtJenisAkun)
        Me.GroupBox5.Controls.Add(Me.TxtKelAkun)
        Me.GroupBox5.Controls.Add(Me.TxtAkun)
        Me.GroupBox5.Controls.Add(Me.BtnCariRek)
        Me.GroupBox5.Controls.Add(Me.Label10)
        Me.GroupBox5.Controls.Add(Me.TxtBukti)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Controls.Add(Me.TxtNilai)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.TxtHarga)
        Me.GroupBox5.Controls.Add(Me.Label16)
        Me.GroupBox5.Controls.Add(Me.Label17)
        Me.GroupBox5.Controls.Add(Me.Label19)
        Me.GroupBox5.Controls.Add(Me.TxtSat)
        Me.GroupBox5.Controls.Add(Me.TxtVol)
        Me.GroupBox5.Controls.Add(Me.Label22)
        Me.GroupBox5.Controls.Add(Me.Label23)
        Me.GroupBox5.Controls.Add(Me.CbCabay)
        Me.GroupBox5.Location = New System.Drawing.Point(8, 103)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(858, 184)
        Me.GroupBox5.TabIndex = 67
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Rincian Pengeluaran"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(407, 19)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(86, 13)
        Me.Label19.TabIndex = 63
        Me.Label19.Text = "Jumlah/Volume :"
        '
        'TxtSat
        '
        Me.TxtSat.Location = New System.Drawing.Point(499, 47)
        Me.TxtSat.Name = "TxtSat"
        Me.TxtSat.Size = New System.Drawing.Size(323, 20)
        Me.TxtSat.TabIndex = 62
        '
        'TxtVol
        '
        Me.TxtVol.Location = New System.Drawing.Point(499, 19)
        Me.TxtVol.Name = "TxtVol"
        Me.TxtVol.Size = New System.Drawing.Size(323, 20)
        Me.TxtVol.TabIndex = 61
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label22.Location = New System.Drawing.Point(28, 97)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(57, 13)
        Me.Label22.TabIndex = 60
        Me.Label22.Text = "Kelompok:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(50, 70)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(35, 13)
        Me.Label23.TabIndex = 59
        Me.Label23.Text = "Akun:"
        '
        'CbCabay
        '
        Me.CbCabay.AllowDrop = True
        Me.CbCabay.FormattingEnabled = True
        Me.CbCabay.Location = New System.Drawing.Point(499, 103)
        Me.CbCabay.Name = "CbCabay"
        Me.CbCabay.Size = New System.Drawing.Size(243, 21)
        Me.CbCabay.TabIndex = 56
        '
        'FrmDKeluar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(874, 663)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.BtnKeluar)
        Me.Controls.Add(Me.GroupBox4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmDKeluar"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Rincian Pengeluaran"
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label20 As Label
    Friend WithEvents BtnKeluar As Button
    Friend WithEvents TxtPPN As TextBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents TxtTotal As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents TxtDPP As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents LblTerbilang As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents LVKeluarD As ListView
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TxtThKeluarD As TextBox
    Friend WithEvents TxtBlnKeluarD As TextBox
    Friend WithEvents TxtMgKeluarD As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtUrKeluarD As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents DateTPKeluarD As DateTimePicker
    Friend WithEvents Label11 As Label
    Friend WithEvents LblCabay As Label
    Friend WithEvents TxtKelAkun As TextBox
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents TSBSave As ToolStripButton
    Friend WithEvents TSBEdit As ToolStripButton
    Friend WithEvents TSBDelete As ToolStripButton
    Friend WithEvents TSBCancel As ToolStripButton
    Friend WithEvents TxtJenisAkun As TextBox
    Friend WithEvents TxtAkun As TextBox
    Friend WithEvents TxtBukti As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents TxtNilai As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents TxtHarga As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents BtnCariRek As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label19 As Label
    Friend WithEvents TxtSat As TextBox
    Friend WithEvents TxtVol As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents CbCabay As ComboBox
End Class
