﻿Imports System.Data.OleDb
Public Class FrmKorek
    Private Sub PosisiListRek()
        Try
            With LVRek.Columns
                .Add("Akun", 140)
                .Add("Kelompok", 150)
                .Add("Jenis", 150)
                '.Add("Kode Perkiraan", 100)
                .Add("Nama Perkiraan (Rekening)", 200)
            End With
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub
    '//pembelian tunai
    Sub IsiListRek()
        Dim a As Integer
        Try
            query = "SELECT Rek1.Uraian, Rek2.Uraian, Rek3.idrek3,  Rek3.Uraian" &
                    " FROM ((rek3 LEFT JOIN Rek1 ON rek3.IDRek1 = Rek1.IDRek1) LEFT JOIN Rek2 ON rek3.IDRek2 = Rek2.IDRek2)  " &
                    " ORDER BY Rek3.IDRek1, Rek3.IDRek2, Rek3.IDRek3;"

            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVRek.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVRek
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    '.Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))

                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.Orange
                    End If
                End With

            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub FrmKorek_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Akun_load() 'menampilkan combobox
            'Kel_load()
            'Jenis_load()
            PosisiListRek()
            IsiListRek()

            TSBSave.Enabled = True
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            TSBCancel.Enabled = True
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Akun_load()
        Dim a As Integer
        Try
            query = "SELECT * FROM rek1 ORDER BY IDRek1 "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbAkun.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbAkun
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2)
                    .Items.Add(dsData.Tables(0).Rows(a).Item(1))
                End With
            Next
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Kel_load()
        Dim a As Integer
        Try
            query = "SELECT * FROM rek2 WHERE  rek2.IDRek1 = '" & LblAkun.Text & "' ORDER BY rek2.IDRek1, rek2.IDRek2 "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbKel.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbKel
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2)
                    .Items.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TSBSave_Click(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            If CbAkun.Text = "" Then
                MsgBox("Akun tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                CbAkun.Focus()
            Else
                If CbKel.Text = "" Then
                    MsgBox("Kelompok tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                    CbKel.Focus()
                Else
                    If TxtKdJenis.Text = "" Then
                        MsgBox("Jenis tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                        TxtKdJenis.Focus()
                    Else


                        query = "INSERT INTO rek3(IdRek1, IdRek2, IdRek3, uraian) VALUES('" & LblAkun.Text &
                                "' , '" & LblKel.Text & "', '" & TxtKdJenis.Text & "', '" & TxtUraian.Text & "' );"
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)

                        IsiListRek()
                        BersihkanIsianRek()

                        MsgBox("Simpan data berhasil", , "Pesan")

                    End If
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub BersihkanIsianRek()
        CbAkun.Enabled = True
        TxtKdJenis.Enabled = True
        CbKel.Enabled = True
        'TxtKdObyek.Enabled = True
        TSBSave.Enabled = True
        CbAkun.Text = ""
        LblAkun.Text = ""
        CbKel.Text = ""
        LblKel.Text = ""
        TxtKdJenis.Text = ""
        LblJenis.Text = ""
        'TxtKdObyek.Text = ""
        TxtUraian.Text = ""
    End Sub

    Private Sub TSBEdit_Click(sender As Object, e As EventArgs) Handles TSBEdit.Click
        Try
            If CbAkun.Text = "" Then
                MsgBox("Akun tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                CbAkun.Focus()
            Else
                If CbKel.Text = "" Then
                    MsgBox("Kelompok tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                    CbKel.Focus()
                Else
                    If TxtKdJenis.Text = "" Then
                        MsgBox("Jenis tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                        TxtKdJenis.Focus()
                    Else
                        'If TxtKdObyek.Text = "" Then
                        '    MsgBox("Kode obtyek rekening tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                        '    TxtKdObyek.Focus()
                        'Else
                        Hapusrek()

                        query = "INSERT INTO rek3(IdRek1, IdRek2, IdRek3,  uraian) VALUES('" & LblAkun.Text &
                            "' , '" & LblKel.Text & "', '" & TxtKdJenis.Text & "', '" & TxtUraian.Text & "' );"
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)

                        IsiListRek()
                        BersihkanIsianRek()

                        MsgBox("Simpan data berhasil", , "Pesan")

                    End If
                End If
            End If
            'End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub Hapusrek()
        Try
            query = "DELETE FROM rek3 WHERE (IDRek1 = '" & LblAkun.Text & "' AND IDRek2 = '" & LblKel.Text & "' AND IDRek3 = '" & TxtKdJenis.Text & "' )  "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBDelete_Click(sender As Object, e As EventArgs) Handles TSBDelete.Click
        Try
            Dim delete As String
            delete = MsgBox("Yakin hapus...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus")
            Select Case delete
                Case vbCancel
                    TxtKdJenis.Enabled = True
                    TxtKdJenis.Focus()
                    BersihkanIsianRek()
                    Exit Sub
                Case vbOK
                    If TxtKdJenis.Text = "" Then
                        MsgBox("Kode jenis tidak boleh kosong", MsgBoxStyle.Critical, "Error")
                        TxtKdJenis.Enabled = True
                        TxtKdJenis.Focus()
                    Else
                        Try
                            'query = "DELETE FROM rek3 WHERE (IDRek1 = '" & LblAkun.Text & "' AND IDRek2 = '" & LblKel.Text & "' AND IDRek3 = '" & TxtKdJenis.Text & "')  "
                            query = "DELETE FROM rek3 WHERE (IDRek1 = '" & LblAkun.Text & "' AND IDRek2 = '" & LblKel.Text & "' AND IDRek3 = '" & TxtKdJenis.Text & "')  "
                            daData = New OleDbDataAdapter(query, conn)
                            dsData = New DataSet
                            daData.Fill(dsData)
                            IsiListRek()
                            BersihkanIsianRek()
                            MsgBox("Hapus data berhasil", , "Pesan")
                        Catch ex As Exception
                            MsgBox("Hapus data gagal", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
                            TxtKdJenis.Focus()
                        End Try
                    End If
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    'End Sub

    Private Sub TSBCancel_Click(sender As Object, e As EventArgs) Handles TSBCancel.Click
        Try
            BersihkanIsianRek()
            TSBSave.Enabled = True
            TSBDelete.Enabled = False
            TSBEdit.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub CbAkun_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbAkun.SelectedIndexChanged
        Try

            query = "SELECT * FROM rek1 WHERE rek1.Uraian = '" & CbAkun.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbKel.Items.Clear()
            With dsData.Tables(0).Rows(0)
                LblAkun.Text = .Item(0)
            End With

            Kel_load()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub CbKel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbKel.SelectedIndexChanged
        Try
            query = "SELECT * FROM rek2 WHERE IDRek1 = '" & LblAkun.Text & "' AND rek2.uraian = '" & CbKel.Text & "'  "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            With dsData.Tables(0).Rows(0)
                LblKel.Text = .Item(1)
            End With

            'Jenis_load()
        Catch ex As Exception
            'MsgBox(ex.Message, "Set")
        End Try
    End Sub

    Private Sub CbAkun_SelectedValueChanged(sender As Object, e As EventArgs) Handles CbAkun.SelectedValueChanged
        Try
            CbKel.Text = ""
            'CbJenis.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TxtKdJenis_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtKdJenis.KeyPress
        Try
            If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = "," Or e.KeyChar = ".") Then
                e.Handled = True
            End If

            If e.KeyChar = Chr(13) Then

                TxtUraian.Focus()

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub LVRek_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVRek.SelectedIndexChanged
        Try
            CbAkun.Enabled = False
            TxtKdJenis.Enabled = False
            CbKel.Enabled = False
            'TxtKdObyek.Enabled = False
            AmbilDataListViewRek()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub AmbilDataListViewRek()
        'Add("Akun", 140)
        '.Add("Kelompok", 150)
        '.Add("Jenis", 150)
        '.Add("Kode Perkiraan", 100)
        '.Add("Nama Perkiraan (Rekening)", 200)

        With LVRek.SelectedItems
            Try
                CbAkun.Text = .Item(0).SubItems(0).Text
                CbKel.Text = .Item(0).SubItems(1).Text
                TxtKdJenis.Text = .Item(0).SubItems(2).Text
                'TxtKdObyek.Text = .Item(0).SubItems(3).Text
                TxtUraian.Text = .Item(0).SubItems(3).Text
            Catch ex As Exception

            End Try
        End With
    End Sub

    Private Sub LVRek_Click(sender As Object, e As EventArgs) Handles LVRek.Click
        Try

            TSBSave.Enabled = False
            TSBEdit.Enabled = True
            TSBDelete.Enabled = True
            TSBCancel.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BtnKeluar_Click(sender As Object, e As EventArgs) Handles BtnKeluar.Click
        Try
            Dispose()
        Catch ex As Exception

        End Try
    End Sub
End Class