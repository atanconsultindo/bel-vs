﻿Imports System.Data.OleDb
Public Class FrmKosong
    Private Sub Proses()
        Timer.Enabled = True
        ProgressBarKos.Minimum = 0
        ProgressBarKos.Maximum = 100
        If ChkBSawal.Checked = True Then

            query = "DELETE FROM ta_saldoawal "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            ProgressBarKos.Value = ProgressBarKos.Value + 10

            MsgBox("Hapus data '" & ChkBSawal.Text & "'  berhasil", , "Pesan")


            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkBSawal.Text & " Sukses!" & vbCrLf

        End If
        If ChkPener.Checked = True Then

            query = "DELETE FROM ta_dpener "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            str = "DELETE FROM ta_hpener "
            da = New OleDbDataAdapter(str, conn)
            ds = New DataSet
            da.Fill(ds)

            'str1 = "DELETE FROM t_penjualan "
            'da1 = New OleDbDataAdapter(str1, conn)
            'ds1 = New DataSet
            'da1.Fill(ds1)

            'str2 = "DELETE FROM ta_penjtunairinc "
            'da2 = New OleDbDataAdapter(str2, conn)
            'ds2 = New DataSet
            'da2.Fill(ds2)

            'str3 = "DELETE FROM ta_penjtunai "
            'da3 = New OleDbDataAdapter(str3, conn)
            'ds3 = New DataSet
            'da3.Fill(ds3)

            MsgBox("Hapus data '" & ChkPener.Text & "'  berhasil", , "Pesan")
            ProgressBarKos.Value = ProgressBarKos.Value + 25

            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkPener.Text & " Sukses!" & vbCrLf

        End If
        If ChkKeluar.Checked = True Then
            query = "DELETE FROM ta_dkeluar "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            str = "DELETE FROM ta_hkeluar "
            da = New OleDbDataAdapter(str, conn)
            ds = New DataSet
            da.Fill(ds)

            'str1 = "DELETE FROM t_pembelian "
            'da1 = New OleDbDataAdapter(str1, conn)
            'ds1 = New DataSet
            'da1.Fill(ds1)

            'str2 = "DELETE FROM ta_pembeliantunairinc "
            'da2 = New OleDbDataAdapter(str2, conn)
            'ds2 = New DataSet
            'da2.Fill(ds2)

            'str3 = "DELETE FROM ta_pembeliantunai "
            'da3 = New OleDbDataAdapter(str3, conn)
            'ds3 = New DataSet
            'da3.Fill(ds3)

            MsgBox("Hapus data '" & ChkKeluar.Text & "'  berhasil", , "Pesan")
            ProgressBarKos.Value = ProgressBarKos.Value + 25
            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkKeluar.Text & " Sukses!" & vbCrLf


            'TxtKosong.Text = TxtKosong.Text & ChkBBeli.Text & vbCrLf
        End If
        If ChkProyek.Checked = True Then
            'query = "DELETE FROM ta_penpmd "
            'daData = New OleDbDataAdapter(query, conn)
            'dsData = New DataSet
            'daData.Fill(dsData)

            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkProyek.Text & " Sukses!" & vbCrLf
            ProgressBarKos.Value = ProgressBarKos.Value + 25
        End If
        If ChkWarga.Checked = True Then
            'query = "DELETE FROM ta_utang_bayar "
            'daData = New OleDbDataAdapter(query, conn)
            'dsData = New DataSet
            'daData.Fill(dsData)


            'str = "DELETE FROM ta_utang "
            'da = New OleDbDataAdapter(str, conn)
            'ds = New DataSet
            'da.Fill(ds)
            MsgBox("Hapus data '" & ChkWarga.Text & "'  berhasil", , "Pesan")
            ProgressBarKos.Value = ProgressBarKos.Value + 25

            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkWarga.Text & " Sukses!" & vbCrLf

        End If

        If ChkBAset.Checked = True Then
            query = "DELETE FROM ta_aset_peroleh "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)


            str = "DELETE FROM ta_aset_lepas "
            da = New OleDbDataAdapter(str, conn)
            ds = New DataSet
            da.Fill(ds)
            MsgBox("Hapus data '" & ChkBAset.Text & "'  berhasil", , "Pesan")
            ProgressBarKos.Value = ProgressBarKos.Value + 10

            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkBAset.Text & " Sukses!" & vbCrLf

        End If

        If ChkBSPP.Checked = True Then

            query = "DELETE FROM ta_pinjaman_cicil "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)


            str = "DELETE FROM ta_pinjaman "
            da = New OleDbDataAdapter(str, conn)
            ds = New DataSet
            da.Fill(ds)
            MsgBox("Hapus data '" & ChkBSPP.Text & "'  berhasil", , "Pesan")
            ProgressBarKos.Value = ProgressBarKos.Value + 10

            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkBSPP.Text & " Sukses!" & vbCrLf


        End If
        If ChkBBasil.Checked = True Then
            query = "DELETE FROM ta_pengelbasil "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            MsgBox("Hapus data '" & ChkBBasil.Text & "'  berhasil", , "Pesan")
            ProgressBarKos.Value = ProgressBarKos.Value + 5

            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkBBasil.Text & " Sukses!" & vbCrLf

        End If
        If ChkMKI.Checked = True Then
            query = "DELETE FROM ta_Journal_child WHERE NoTipe =  'GLJ02' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)


            str = "DELETE FROM ta_Journal_parent WHERE Deskripsi Like  'Mutasi kas' & '%'  "
            da = New OleDbDataAdapter(str, conn)
            ds = New DataSet
            da.Fill(ds)
            MsgBox("Hapus data '" & ChkMKI.Text & "'  berhasil", , "Pesan")

            ProgressBarKos.Value = ProgressBarKos.Value + 5
            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkBJurnal.Text & " Sukses!" & vbCrLf

        End If

        If ChkBJurnal.Checked = True Then
            query = "DELETE FROM ta_journal_child "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)


            str = "DELETE FROM ta_Journal_parent "
            da = New OleDbDataAdapter(str, conn)
            ds = New DataSet
            da.Fill(ds)
            MsgBox("Hapus data '" & ChkBJurnal.Text & "'  berhasil", , "Pesan")

            ProgressBarKos.Value = ProgressBarKos.Value + 10
            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkBJurnal.Text & " Sukses!" & vbCrLf

        End If
        If ChkBFiskal.Checked = True Then

            TxtKosong.Text = TxtKosong.Text & ChkBFiskal.Text & vbCrLf
        End If
        If ChkBSusut.Checked = True Then
            query = "DELETE FROM ta_aset_susut "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            MsgBox("Hapus data '" & ChkBSusut.Text & "'  berhasil", , "Pesan")
            ProgressBarKos.Value = ProgressBarKos.Value + 10
            TxtKosong.Text = TxtKosong.Text & "Penghapusan:" & ChkBSusut.Text & " Sukses!" & vbCrLf

        End If


    End Sub

    Private Sub CenterMe()
        Dim g As Graphics = Me.CreateGraphics()
        Dim startingPoint As Double = (Me.Width / 2) - (g.MeasureString(Me.Text.Trim, Me.Font).Width / 2)
        Dim widthOfASpace As Double = g.MeasureString(" ", Me.Font).Width
        Dim tmp As String = " "
        Dim tmpWidth As Double = 0
        Do
            tmp += " "
            tmpWidth += widthOfASpace
        Loop While (tmpWidth + widthOfASpace) < startingPoint

        Me.Text = tmp & Me.Text.Trim & tmp

        Me.Refresh()
    End Sub
    Private Sub BtnKeluar_Click(sender As Object, e As EventArgs) Handles BtnKeluar.Click
        Dispose()
    End Sub


    Private Sub BtbProses_Click(sender As Object, e As EventArgs) Handles BtbProses.Click
        Proses()
        'TxtKosong.Text = ""
    End Sub



    Private Sub FrmKos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TxtKosong.Text = ""
        CenterMe()
    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs) Handles Timer.Tick

        LblProgress.Text = ProgressBarKos.Value & " % " & " completed"
        If ProgressBarKos.Value >= 100 Then
            Timer.Enabled = False
            BtbProses.Enabled = False
            'If TextBox1.Text = "admin" And TextBox2.Text = "admin" Then
            '    MsgBox("Welcome", MsgBoxStyle.Information, "Sarfaraz")
            '    ProgressBar1.Value = 0

            'Else
            '    MsgBox("Invalid username or password", MsgBoxStyle.Information, "Sarfaraz")
            '    Label1.Text = ""
            '    ProgressBar1.Value = 0
            '    TextBox1.Focus()
            'End If


        End If
    End Sub

    Private Sub FrmKos_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        CenterMe()
    End Sub
End Class