﻿Imports System.Data.OleDb
Public Class FrmSawal
    Sub PosisiListSawal()
        Try
            With LVSawal.Columns
                .Add("No", 40)
                .Add("Akun", 70)
                .Add("Kelompok", 100)
                .Add("Jenis", 100)
                .Add("Nama Rekening", 150)
                .Add("Debet", 100, HorizontalAlignment.Right)
                .Add("Kredit", 100, HorizontalAlignment.Right)
                .Add("Periode", 40)
            End With
        Catch ex As Exception

        End Try

    End Sub

    Sub IsiListSawal()
        Dim a As Integer
        Try
            'query = " SELECT ta_saldoawal.NoUrut, Rek1.uraian, Rek2.uraian,  Rek3.uraian, ta_saldoawal.KodeRek, Rek4.uraian, ta_saldoawal.Debet, ta_saldoawal.Kredit, ta_saldoawal.Periode  " &
            '        " FROM (((ta_saldoawal left join Rek1 on  Left(ta_saldoawal.KodeRek,1) = Rek1.idrek1) left join Rek2 on  Left(ta_saldoawal.KodeRek,2) = Rek2.idrek2) left join Rek3 on  Left(ta_saldoawal.KodeRek,4) = Rek3.idrek3)  left join Rek4 on  ta_saldoawal.KodeRek = Rek4.idrek4 " &
            '        " GROUP BY ta_saldoawal.NoUrut, Rek1.uraian, Rek2.uraian, Rek3.uraian, ta_saldoawal.KodeRek, Rek4.uraian, ta_saldoawal.Debet, ta_saldoawal.Kredit, ta_saldoawal.Periode " &
            '        " ORDER BY ta_saldoawal.NoUrut, ta_saldoawal.KodeRek;"
            query = " SELECT ta_saldoawal.NoUrut, Rek1.uraian, Rek2.uraian,  ta_saldoawal.KodeRek, Rek3.uraian, ta_saldoawal.Debet, ta_saldoawal.Kredit, ta_saldoawal.Periode " &
                    " FROM ((ta_saldoawal left join Rek1 on  Left(ta_saldoawal.KodeRek,1) = Rek1.idrek1) left join Rek2 on Left(ta_saldoawal.KodeRek,2) = Rek2.idrek2) left join Rek3 on ta_saldoawal.KodeRek = Rek3.idrek3" &
                    " GROUP BY ta_saldoawal.NoUrut, Rek1.uraian, Rek2.uraian, ta_saldoawal.KodeRek, Rek3.uraian, ta_saldoawal.Debet, ta_saldoawal.Kredit, ta_saldoawal.Periode " &
                    " ORDER BY ta_saldoawal.NoUrut, ta_saldoawal.KodeRek;"


            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVSawal.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVSawal
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    '.Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(5), "###,##0"))
                    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(6), "###,##0"))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))

                    '.Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(12), "###,###"))

                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.Orange
                    End If
                End With
            Next
            'LblNamaDokter.Text = dsData.Tables(0).Rows(0).Item(1)
            'TxtNoBuktiDetail.Text = UCase(FrmPenjualan.TxtNoBukti.Text)
            'TxtUnit.Text = UCase(FrmPenjualan.CbUnit.Text)
            'DTPTglJual.Text = UCase(FrmPenjualan.DateTPMasPenjualan.Text)
            'TxtKet.Text = LCase(FrmPenjualan.TxtKet.Text)
            'TxtNoBuktiDetail.BackColor = Color.AliceBlue
            'TxtUnit.BackColor = Color.AliceBlue
            'TxtKet.BackColor = Color.AliceBlue
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub BersihkanIsianSawal()
        Try
            'CbPeriode.Text = ""
            TxtNoUrut.Text = ""
            TxtNoUrut.Enabled = True
            TxtAkun.Text = ""
            TxtKelAkun.Text = ""
            TxtJenisAkun.Text = ""
            'TxtObyekAkun.Text = ""
            TxtNilaiDebet.Text = 0
            TxtNilaiKredit.Text = 0
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FrmSawal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            PosisiListSawal()
            IsiListSawal()
            TxtNilaiDebet.Text = 0
            TxtNilaiKredit.Text = 0
            JumlahDebetKrredit()
            CbPeriode.Focus()
            BersihkanIsianSawal()
            CenterMe()
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            TSBTambah.Enabled = True
            TSBSave.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BersihkanIsiRekening()
        Try
            TxtAkun.Text = ""
            TxtKelAkun.Text = ""
            TxtJenisAkun.Text = ""
            'TxtObyekAkun.Text = ""
            TxtNilaiDebet.Text = 0
            TxtNilaiKredit.Text = 0
        Catch ex As Exception

        End Try

    End Sub

    Private Sub BtnCariRek_Click(sender As Object, e As EventArgs) Handles BtnCariRek.Click
        Try
            BersihkanIsiRekening()
            FrmCariRekSawal.ShowDialog()

            If Len(TxtAkun.Text) = 0 Then
                TxtAkun.Focus()
            Else
                TxtNilaiDebet.Focus()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub JumlahDebetKrredit()
        Try
            query = " SELECT Sum(ta_saldoawal.Debet) AS SumOfDebet, Sum(ta_saldoawal.Kredit) AS SumOfKredit " &
                    "FROM ta_saldoawal;"


            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LblTotalDebet.Text = Format(dsData.Tables(0).Rows(0).Item(0), "#,#0")
            LblTotalKredit.Text = Format(dsData.Tables(0).Rows(0).Item(1), "#,#0")
            LblBalance.Text = Format(dsData.Tables(0).Rows(0).Item(0), "#,#0") - Format(dsData.Tables(0).Rows(0).Item(1), "#,#0")
        Catch ex As Exception

        End Try
    End Sub




    Private Sub InsertJurnalParent()
        Try
            Dim jurnalparent As String

            'jurnalparent = "INSERT INTO ta_jurnalh(JurnalId, TglTransaksi,IDUnit,Deskripsi) values('" & CbPeriode.Text &
            '                "', '1/1/1900', '00', 'Saldo awal: " & CbPeriode.Text & "'); "

            jurnalparent = "INSERT INTO ta_jurnalh(JurnalId, tahun,kd_bulan,kd_minggu,TipeId,uraian) values('" & CbPeriode.Text &
                            "', '" & Microsoft.VisualBasic.Left(CbPeriode.Text, 4) & "', '" & Microsoft.VisualBasic.Right(CbPeriode.Text, 2) &
                            "', '0', 'GLJ00', 'Saldo awal: " & CbPeriode.Text & "'); "
            daData = New OleDbDataAdapter(jurnalparent, conn)
            dsData = New DataSet
            daData.Fill(dsData)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub InsertJurnalChild()
        Try
            Dim jurnaldebetkredit As String

            jurnaldebetkredit = "INSERT INTO ta_jurnald(JurnalId, NoTipe, tanggal, NoUrut,rek1, rek2, rek3, NamaRek, Debet, Kredit) values('" & CbPeriode.Text &
                               "', 'GLJ00', '1/1/1900', '" & TxtNoUrut.Text & "' , '" & lblAk.Text & "' ,'" & lblKel.Text &
                                "' ,  '" & lblJn.Text & "' ,   '" & TxtJenisAkun.Text &
                               "' ,  '" & TxtNilaiDebet.Text & "' , '" & TxtNilaiKredit.Text & "')"
            daData = New OleDbDataAdapter(jurnaldebetkredit, conn)
            dsData = New DataSet
            daData.Fill(dsData)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    '.Add("No", 40)
    '.Add("Akun", 70)
    '.Add("Kelompok", 100)
    '.Add("Jenis", 100)
    '.Add("Nama Rekening", 150)
    '.Add("Debet", 100, HorizontalAlignment.Right)
    '.Add("Kredit", 100, HorizontalAlignment.Right)
    '.Add("Periode", 40)
    Private Sub AmbilDataListViewSawal()
        With LVSawal.SelectedItems
            Try
                TxtNoUrut.Text = .Item(0).SubItems(0).Text
                TxtAkun.Text = .Item(0).SubItems(1).Text
                TxtKelAkun.Text = .Item(0).SubItems(2).Text
                TxtJenisAkun.Text = .Item(0).SubItems(3).Text
                'TxtObyekAkun.Text = .Item(0).SubItems(5).Text
                'TxtKelAkun.Text = .Item
                TxtNilaiDebet.Text = .Item(0).SubItems(5).Text
                TxtNilaiKredit.Text = .Item(0).SubItems(6).Text
                CbPeriode.Text = .Item(0).SubItems(7).Text
                ''TxtUmur.Text = .Item(0).SubItems(8).Text
                'LokasiGambar()

            Catch ex As Exception
                'MsgBox(ex.Message)
            End Try
        End With
    End Sub

    Private Sub LVSawal_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVSawal.SelectedIndexChanged
        Try
            AmbilDataListViewSawal()
            TxtNoUrut.Enabled = False
            TSBTambah.Enabled = False
            TSBSave.Enabled = False
            TSBEdit.Enabled = True
            TSBDelete.Enabled = True
            TSBCancel.Enabled = True
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub deleteTabel()
        Try
            query = "DELETE FROM ta_saldoawal WHERE NoUrut = '" & TxtNoUrut.Text & "'"
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub deleteJurnalChild()
        Try
            query = "DELETE FROM ta_jurnald WHERE JurnalId = '" & CbPeriode.Text & "' AND NoUrut = '" & TxtNoUrut.Text & "'"
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub deleteJurnalParent()
        Try
            query = "DELETE FROM ta_jurnalh WHERE JurnalId = '" & CbPeriode.Text & "'"
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub




    Private Sub CbPeriode_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CbPeriode.KeyPress
        If e.KeyChar = Chr(13) Then
            TxtNoUrut.Focus()
        End If
    End Sub

    Private Sub TxtNoUrut_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNoUrut.KeyPress
        If e.KeyChar = Chr(13) Then
            BtnCariRek.Focus()
        End If
        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack) Then
            e.Handled = True
        End If
    End Sub

    Private Sub BtnCariRek_KeyPress(sender As Object, e As KeyPressEventArgs) Handles BtnCariRek.KeyPress
        If e.KeyChar = Chr(13) Then
            TxtNilaiDebet.Focus()
        End If
    End Sub

    Private Sub TxtNilaiDebet_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNilaiDebet.KeyPress
        If e.KeyChar = Chr(13) Then
            TxtNilaiKredit.Focus()
        End If
        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack) Then
            e.Handled = True
        End If
        'If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = "," Or e.KeyChar = ".") Then
        '    e.Handled = True
        'End If

    End Sub

    Private Sub TxtNilaiKredit_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNilaiKredit.KeyPress
        If e.KeyChar = Chr(13) Then
            ToolStrip1.Focus()
        End If
        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack) Then
            e.Handled = True
        End If
    End Sub



    Private Sub CenterMe()
        Dim g As Graphics = Me.CreateGraphics()
        Dim startingPoint As Double = (Me.Width / 2) - (g.MeasureString(Me.Text.Trim, Me.Font).Width / 2)
        Dim widthOfASpace As Double = g.MeasureString(" ", Me.Font).Width
        Dim tmp As String = " "
        Dim tmpWidth As Double = 0
        Do
            tmp += " "
            tmpWidth += widthOfASpace
        Loop While (tmpWidth + widthOfASpace) < startingPoint

        Me.Text = tmp & Me.Text.Trim & tmp

        Me.Refresh()
    End Sub

    Private Sub FrmSawal_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        CenterMe()
    End Sub

    Private Sub TxtKelAkun_TextChanged(sender As Object, e As EventArgs) Handles TxtKelAkun.TextChanged
        Dim a As Integer
        Try
            query = "SELECT * FROM rek2 WHERE uraian = '" & TxtKelAkun.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            lblKel.Text = ""
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                lblKel.Text = dsData.Tables(0).Rows(a).Item(1)
                lblKel.ForeColor = Color.DarkCyan

                '.Items.Add(dsData.Tables(0).Rows(a).Item(2) & " : " & dsData.Tables(0).Rows(a).Item(2))
            Next
        Catch ex As Exception
            MsgBox(ex.Message, "Rek2")
        End Try
    End Sub

    Private Sub TxtJenisAkun_TextChanged(sender As Object, e As EventArgs) Handles TxtJenisAkun.TextChanged
        Dim a As Integer
        Try
            query = "SELECT * FROM rek3 WHERE uraian = '" & TxtJenisAkun.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            lblJn.Text = ""
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                lblJn.Text = dsData.Tables(0).Rows(a).Item(2)
                lblJn.ForeColor = Color.DarkCyan

                '.Items.Add(dsData.Tables(0).Rows(a).Item(2) & " : " & dsData.Tables(0).Rows(a).Item(2))
            Next
        Catch ex As Exception
            MsgBox(ex.Message, "Rek3")
        End Try
    End Sub


    'Private Sub TxtObyekAkun_TextChanged(sender As Object, e As EventArgs)
    '    Dim a As Integer
    '    Try
    '        query = "SELECT * FROM rek4 WHERE uraian = '" & TxtObyekAkun.Text & "' "
    '        daData = New OleDbDataAdapter(query, cn)
    '        dsData = New DataSet
    '        daData.Fill(dsData)
    '        'lblOb.Text = ""
    '        For a = 0 To dsData.Tables(0).Rows.Count - 1
    '            'lblOb.Text = dsData.Tables(0).Rows(a).Item(3)
    '            'lblOb.ForeColor = Color.DarkCyan

    '            '.Items.Add(dsData.Tables(0).Rows(a).Item(2) & " : " & dsData.Tables(0).Rows(a).Item(2))
    '        Next
    '    Catch ex As Exception
    '        MsgBox(ex.Message, "Rek4")
    '    End Try
    'End Sub

    Private Sub TxtAkun_TextChanged(sender As Object, e As EventArgs) Handles TxtAkun.TextChanged
        Dim a As Integer
        Try
            query = "SELECT * FROM rek1 WHERE uraian = '" & TxtAkun.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            lblAk.Text = ""
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                lblAk.Text = dsData.Tables(0).Rows(a).Item(0)
                lblAk.ForeColor = Color.DarkCyan

                '.Items.Add(dsData.Tables(0).Rows(a).Item(2) & " : " & dsData.Tables(0).Rows(a).Item(2))
            Next
        Catch ex As Exception
            MsgBox(ex.Message, "Rek1")
        End Try
    End Sub

    Private Sub BtnKeluar_Click(sender As Object, e As EventArgs) Handles BtnKeluar.Click
        Dim tanya As String
        If Val(Me.LblBalance.Text) <> 0 Then
            tanya = MsgBox("Total DEBET tidak sama dengan Total KREDIT: Tetap Mau Lanjutkan....?",
              MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Peringatan")
            '<-- Membuat logika jika benar mau menutup aplikasi maka tutup aplikasi
            If tanya = vbCancel Then
                ToolStrip1.Focus()
            Else
                Dispose()
            End If

        Else
            Dispose()
        End If

    End Sub

    Private Sub LVSawal_Click(sender As Object, e As EventArgs) Handles LVSawal.Click
        Try
            TSBEdit.Enabled = True
            TSBDelete.Enabled = True
            TSBTambah.Enabled = False
            TSBSave.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBTambah_Click_1(sender As Object, e As EventArgs) Handles TSBTambah.Click
        Try
            BersihkanIsianSawal()
            CbPeriode.Focus()
            IsiListSawal()
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            TSBSave.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBSave_Click_1(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            If CbPeriode.Text = "" Then
                MsgBox("Periode tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                CbPeriode.Focus()
            Else
                If TxtAkun.Text = "" Then
                    MsgBox("Silakan isikan akun rekening", MsgBoxStyle.Exclamation, "Error")
                    TxtAkun.Focus()
                Else
                    If TxtNoUrut.Text = "" Then
                        MsgBox("Kode Rek tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                        TxtNoUrut.Focus()
                    Else
                        query = "INSERT INTO ta_saldoawal(NoUrut, KodeRek,NamaRek,Debet,Kredit,Periode) values('" & UCase(TxtNoUrut.Text) &
                                                 "', '" & lblJn.Text & "', '" & TxtJenisAkun.Text &
                                                 "', '" & TxtNilaiDebet.Text & "', '" & TxtNilaiKredit.Text & "','" & CbPeriode.Text & "' ) "
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        deleteJurnalParent()
                        InsertJurnalParent()
                        InsertJurnalChild()
                        IsiListSawal()
                        JumlahDebetKrredit()
                        BersihkanIsianSawal()
                        MsgBox("Simpan data berhasil", , "Pesan")
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TSBEdit_Click_1(sender As Object, e As EventArgs) Handles TSBEdit.Click
        Try
            'If TxtNoBukti.Text = "" Then
            '    MsgBox("No Bukti tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
            '    TxtNoBukti.Focus()
            'Else
            'If Len(TxtNoBukti.Text) < 13 Then
            '    MsgBox("Panjang minimal  13 digit", MsgBoxStyle.Exclamation, "Error")
            '    TxtNoBukti.Focus()
            'Else
            If TxtNoUrut.Text = "" Then
                MsgBox("No urut tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                TxtNoUrut.Focus()
            Else
                If CbPeriode.Text = "" Then
                    MsgBox("Periode tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                    CbPeriode.Focus()
                Else
                    If TxtAkun.Text = "" Then
                        MsgBox("Silakan isikan kembali akun rekening", MsgBoxStyle.Exclamation, "Error")
                        TxtAkun.Focus()
                    Else

                        deleteTabel()
                        deleteJurnalChild()
                        deleteJurnalParent()
                        query = "INSERT INTO ta_saldoawal (NoUrut,KodeRek,NamaRek, Debet,Kredit,Periode) values ('" & UCase(TxtNoUrut.Text) &
                                    "', '" & lblJn.Text & "', '" & TxtJenisAkun.Text &
                                    "', '" & TxtNilaiDebet.Text & "', '" & TxtNilaiKredit.Text & "','" & CbPeriode.Text & "' ) "
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        InsertJurnalParent()
                        InsertJurnalChild()
                        IsiListSawal()
                        JumlahDebetKrredit()
                        BersihkanIsianSawal()
                        MsgBox("Ubah data berhasil", , "Pesan")

                    End If
                End If
            End If
            'End If
            'End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TSBDelete_Click_1(sender As Object, e As EventArgs) Handles TSBDelete.Click
        Dim delete As String
        delete = MsgBox("Yakin hapus...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus")
        Select Case delete
            Case vbCancel
                TxtNoUrut.Enabled = True
                TxtAkun.Focus()
                BersihkanIsianSawal()
                Exit Sub
            Case vbOK
                If TxtNoUrut.Text = "" Then
                    MsgBox("Urut tidak boleh kosong", MsgBoxStyle.Critical, "Error")
                    TxtNoUrut.Enabled = True
                    TxtNoUrut.Focus()
                Else
                    Try
                        deleteTabel()
                        deleteJurnalChild()
                        deleteJurnalParent()
                        IsiListSawal()
                        JumlahDebetKrredit()
                        BersihkanIsianSawal()
                        MsgBox("Hapus data berhasil", , "Pesan")
                    Catch ex As Exception
                        MsgBox("Hapus data gagal", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
                        TxtNoUrut.Focus()
                    End Try
                End If
        End Select
    End Sub

    Private Sub TSBCancel_Click_1(sender As Object, e As EventArgs) Handles TSBCancel.Click
        Try
            BersihkanIsianSawal()
            TSBTambah.Enabled = True
            TSBSave.Enabled = True
            TSBDelete.Enabled = False
            TSBEdit.Enabled = False
            'TSBEdit.Enabled = False
            'TSBDelete.Enabled = False
            'TSBTambah.Enabled = True

        Catch ex As Exception

        End Try
    End Sub
End Class