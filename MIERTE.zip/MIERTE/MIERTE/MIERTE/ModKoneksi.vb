﻿Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Module ModKoneksi
    Public conn As New OleDbConnection
    'Public dbDriver As String
    Public dbProviders As String
    'Public dbServer As String
    Public dbSources As String
    'Public dbDatabase As String
    'Public dbPassword As String
    'Public dbUID As String
    Public sLocalConn As String


    Public daData, da, da1, da2, da3, da4, da5 As OleDbDataAdapter
    Public dsData, ds, ds1 As DataSet
    Public datatable As New DataTable
    Public query, str, str1, str2, str3, str4, str5, str6 As String
    Public dr, dr1, dr2, dr3 As OleDbDataReader

    Public cmd, cmd1, cmd2, cmd3 As OleDbCommand

    'Public cmd As New OleDbCommand
    'Public da, daData, da1, da2, da3, da4, da5 As New OleDbDataAdapter
    'Public ds, dsData, ds1, ds2, ds3 As New DataSet
    'Public query, str, str1, str2, str3, str4, str5, str6 As String
    'Public datatable As New DataTable
    'Public DR As OleDbDataReader
    Public Const prov As String = "PEMERINTAH PROVINSI JAWA BARAT"
    Public Const company As String = "RT 00, RW 00 BSD"

    Public Sub GetDatabaseSetting()
        Try
            'dbProviders = My.Settings.dbProvider
            ''dbServer = My.Settings.dbServer
            'dbSources = My.Settings.dbSource
            ''dbDatabase = My.Settings.dbDatabase
            ''dbPassword = My.Settings.dbPassword
            ''dbUID = My.Settings.dbUID
            ''sLocalConn = "Driver=" & dbDriver & ";Server=" & dbServer & ";DATABASE=" & dbDatabase & ";PWD=" & dbPassword & ";UID=" & dbUID
            'sLocalConn = "Provider=" & dbProviders & ";Data Source=" & dbSources & ";Persist Security Info=False;"
            ''sLocalConn = "Provider=" & dbProvider & ";Data Source=" & dbSource
            'conn = New OleDbConnection(sLocalConn)

            conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; " + " Data Source=DB.accdb"
            If conn.State = ConnectionState.Closed Then conn.Open()
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try

    End Sub

    'cn.ConnectionString = "Provider = '" & FrmKoneksi.TxtProvider.Text & _
    '        "'; Data Source= '" & FrmKoneksi.TxtDataSource.Text & " ' ;" & _
    '        "Persist Security Info = False;"

    'Public Function DatabaseConnected(Optional ByVal DRIVERNAME As String = "",
    '                                  Optional ByVal SERVERNAME As String = "",
    '                                  Optional ByVal DATABASENAME As String = "",
    '                                  Optional ByVal PWDNAME As String = "",
    '                                  Optional ByVal UIDNAME As String = "") As Boolean
    Public Function DatabaseConnected(Optional ByVal PROVIDERNAME As String = "",
                                      Optional ByVal SOURCENAME As String = "") As Boolean
        'Dim conn As OleDbConnection
        conn = New OleDbConnection()
        If PROVIDERNAME = "" And SOURCENAME = "" Then
            conn.ConnectionString = sLocalConn
        Else
            conn.ConnectionString = "Provider=" & PROVIDERNAME & ";Data Source=" & SOURCENAME
        End If

        Try
            'conn = New OdbcConnection(MyDb)
            conn.Open()
            'conn.Close()
            Return True
        Catch ex As Exception
            Return False
            MsgBox("GetDatabaseSetting error" + vbNewLine + "Check Setting GetDatabaseSetting!", MsgBoxStyle.Critical, "PESAN KESALAHAN")
        Finally
            conn.Dispose()
        End Try
        Return False
    End Function

End Module
