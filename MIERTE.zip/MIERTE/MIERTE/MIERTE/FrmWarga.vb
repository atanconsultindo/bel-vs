﻿Imports System.Data.OleDb
Public Class FrmWarga
    Private Sub PosisiListAg()
        Try
            With LVAg.Columns
                .Add("No KK", 150)
                .Add("Nama KK", 150)
                .Add("Jenis Kelamin", 80)
                .Add("Alamat", 250)
                .Add("No Telepon", 90)
                .Add("Status", 60, HorizontalAlignment.Center)
                .Add("Jml Anggota KK", 60, HorizontalAlignment.Center)

            End With
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub
    '//pembelian tunai
    Sub IsiListAg()
        Dim a As Integer
        Try
            query = "SELECT r_warga.idkk, r_warga.nm_kk, r_warga.jk, r_warga.Alamat,  r_warga.Telepon, r_warga.status, r_warga.jumlah " &
                    " FROM r_warga " &
                    " ORDER BY r_warga.idkk; "

            'query = "SELECT ta_penjtunai.NoBukti, ta_penjtunai.Tanggal, " & _
            '       " ta_penjtunai.IdUnit, r_unit.NamaUnit, ta_penjtunai.ket " & _
            '       " FROM ta_penjtunai LEFT JOIN r_unit " & _
            '       " ON ta_penjtunai.IdUnit = r_unit.IdUnit " & _
            '       " ORDER BY ta_penjtunai.NoBukti;"
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVAg.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVAg
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    '.Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))

                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.Orange
                    End If
                End With

            Next

        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub cboStatus_load()
        Dim a As Integer
        Try
            query = "SELECT * FROM r_status ORDER BY idstatus "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbStatus.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbStatus
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2)
                    .Items.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBTambah_Click(sender As Object, e As EventArgs)

    End Sub


    Private Sub BersihkanIsianAg()
        TxtNoKK.Enabled = True
        TxtNoKK.Text = ""
        TxtNama.Text = ""
        CbJk.Text = ""
        TxtAlamat.Text = ""
        'DateTPMasPembelian.Text = Now
        CbStatus.Text = ""
        LblStatus.Text = ""
        TxtTelp.Text = ""
        TxtJumlah.Text = ""
        TSBTambah.Enabled = True
        TSBSave.Enabled = True
        TSBEdit.Enabled = True
        TSBDelete.Enabled = True
    End Sub

    Private Sub TSBSave_Click(sender As Object, e As EventArgs)

    End Sub


    Private Sub FrmAgSPP_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            PosisiListAg()
            IsiListAg()
            cboStatus_load()
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            TSBSave.Enabled = True
            TSBTambah.Enabled = True
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub LVAg_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVAg.SelectedIndexChanged
        Try
            TxtNoKK.Enabled = False
            AmbilDataListViewAg()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AmbilDataListViewAg()

        ''..Add("No KK", 90)
        '.Add("Nama KK", 100)
        '.Add("Jenis Kelamin", 80)
        '.Add("Alamat", 200)

        '.Add("Status", 100, HorizontalAlignment.Center)
        '.Add("Jml Anggota KK", 150, HorizontalAlignment.Center)

        With LVAg.SelectedItems
            Try
                TxtNoKK.Text = .Item(0).SubItems(0).Text
                TxtNama.Text = .Item(0).SubItems(1).Text
                CbJk.Text = .Item(0).SubItems(2).Text
                TxtAlamat.Text = .Item(0).SubItems(3).Text
                CbStatus.Text = .Item(0).SubItems(4).Text
                TxtTelp.Text = .Item(0).SubItems(5).Text
                TxtJumlah.Text = .Item(0).SubItems(6).Text
            Catch ex As Exception

            End Try
        End With
    End Sub

    Private Sub LVAg_Click(sender As Object, e As EventArgs) Handles LVAg.Click
        Try
            TSBDelete.Enabled = True
            TSBEdit.Enabled = True
            TSBSave.Enabled = False
            TSBTambah.Enabled = False

        Catch ex As Exception

        End Try
    End Sub

    Private Sub BtnKeluar_Click(sender As Object, e As EventArgs) Handles BtnKeluar.Click
        Try
            Dispose()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBTambah_Click_1(sender As Object, e As EventArgs) Handles TSBTambah.Click
        Try
            BersihkanIsianAg()
            TxtNoKK.Focus()
            IsiListAg()
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            TSBSave.Enabled = True

            'LokasiGambar()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBSave_Click_1(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            If TxtNoKK.Text = "" Then
                MsgBox("No Bukti tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                TxtNoKK.Focus()
            Else
                If TxtNama.Text = "" Then
                    MsgBox("Nama tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                    TxtNama.Focus()
                Else
                    If CbJk.Text = "" Then
                        MsgBox("Jenis Kelamin tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                        CbJk.Focus()
                    Else
                        If CbStatus.Text = "" Then
                            MsgBox("Kode Unit tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                            CbStatus.Focus()
                        Else
                            'query = "UPDATE tblNamaKlinik SET namaklinik = '" & TxtPerush.Text & _
                            '        "', namapimpinan = '" & TxtPimpinan.Text & _
                            '        "', alamat = '" & TxtAlamat.Text & _
                            '        "', notelepon = '" & TxtTelepon.Text & "'"


                            query = "INSERT INTO r_warga (idkk,nm_kk,jk,Alamat, Telepon, status, jumlah) values ('" & UCase(TxtNoKK.Text) &
                                    "', '" & TxtNama.Text & "', '" & CbJk.Text &
                                    "', '" & TxtAlamat.Text & "', '" & TxtTelp.Text &
                                    "', '" & CbStatus.Text & "', '" & TxtJumlah.Text & "') "
                            daData = New OleDbDataAdapter(query, conn)
                            dsData = New DataSet
                            daData.Fill(dsData)

                            IsiListAg()
                            BersihkanIsianAg()
                            MsgBox("Simpan data berhasil", , "Pesan")
                        End If
                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBEdit_Click_1(sender As Object, e As EventArgs) Handles TSBEdit.Click
        Try

            If TxtNoKK.Text = "" Then
                MsgBox("No Bukti tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                TxtNoKK.Focus()
            Else
                If TxtNama.Text = "" Then
                    MsgBox("Nama tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                    TxtNama.Focus()
                Else
                    If CbJk.Text = "" Then
                        MsgBox("Jenis Kelamin tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                        CbJk.Focus()
                    Else
                        If CbStatus.Text = "" Then
                            MsgBox("Kode status tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                            CbStatus.Focus()
                        Else

                            query = "UPDATE r_warga SET nm_kk = '" & TxtNama.Text & "', jk = '" & CbJk.Text &
                                "', Alamat = '" & TxtAlamat.Text & "', telepon = '" & TxtTelp.Text &
                                "', status = '" & LblStatus.Text & "', jumlah  = '" & TxtJumlah.Text & "' WHERE idkk = '" & TxtNoKK.Text & "' "


                            daData = New OleDbDataAdapter(query, conn)
                            dsData = New DataSet
                            daData.Fill(dsData)

                            IsiListAg()
                            BersihkanIsianAg()
                            MsgBox("Ubah data berhasil", , "Pesan")
                        End If
                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBDelete_Click_1(sender As Object, e As EventArgs) Handles TSBDelete.Click
        Try
            Dim delete As String
            delete = MsgBox("Yakin hapus...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus")
            Select Case delete
                Case vbCancel
                    TxtNoKK.Enabled = True
                    TxtNoKK.Focus()
                    BersihkanIsianAg()
                    Exit Sub
                Case vbOK
                    If TxtNoKK.Text = "" Then
                        MsgBox("Kode tidak boleh kosong", MsgBoxStyle.Critical, "Error")
                        TxtNoKK.Enabled = True
                        TxtNoKK.Focus()
                    Else
                        Try
                            query = "DELETE FROM r_warga WHERE idkk = '" & TxtNoKK.Text & "'"
                            daData = New OleDbDataAdapter(query, conn)
                            dsData = New DataSet
                            daData.Fill(dsData)
                            IsiListAg()
                            BersihkanIsianAg()
                            MsgBox("Hapus data berhasil", , "Pesan")
                        Catch ex As Exception
                            MsgBox("Hapus data gagal", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
                            TxtNoKK.Focus()
                        End Try
                    End If
            End Select
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TSBCancel_Click_1(sender As Object, e As EventArgs) Handles TSBCancel.Click
        Try
            BersihkanIsianAg()
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            TSBSave.Enabled = True
            TSBTambah.Enabled = True

        Catch ex As Exception

        End Try
    End Sub

    Private Sub CbStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbStatus.SelectedIndexChanged
        Dim a As Integer
        Try
            query = "SELECT * FROM r_status WHERE nmstatus = '" & CbStatus.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LblStatus.Text = ""
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                LblStatus.Text = dsData.Tables(0).Rows(a).Item(1)

                '.Items.Add(dsData.Tables(0).Rows(a).Item(2) & " : " & dsData.Tables(0).Rows(a).Item(2))
            Next
        Catch ex As Exception
            MsgBox(ex.Message, "Changer")
        End Try
    End Sub
End Class