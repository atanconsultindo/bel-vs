﻿Imports System.Data.OleDb
Public Class FrmDKeluar
    Sub PosisiListKeluarD()
        Try
            With LVKeluarD.Columns
                .Add("Tanggal", 100)
                .Add("No. Bukti", 80)
                .Add("Kd. Akun", 0)
                .Add("Nama Akun", 100)
                .Add("Kd. Kelompok", 0)
                .Add("Nama Kelompok", 150)
                .Add("Kd.Jenis", 0)
                .Add("Nama Jenis", 250)
                .Add("Volume", 40, HorizontalAlignment.Right)
                .Add("Satuan", 50)
                .Add("Harga", 100, HorizontalAlignment.Right)
                .Add("Nilai", 100, HorizontalAlignment.Right)
                .Add("Bayar", 0)
            End With
        Catch ex As Exception

        End Try

    End Sub

    Sub IsiListKeluarD()
        Dim a As Integer
        Try
            query = " SELECT ta_keluard.tanggal, ta_keluard.no_bukti, ta_keluard.IDRek1, Rek1.Uraian, ta_keluard.IDRek2, Rek2.Uraian, ta_keluard.IDRek3, Rek3.Uraian, ta_keluard.volume, ta_keluard.sat, ta_keluard.harsat, [volume]*[harsat] AS Nilai, ta_keluard.bayar" &
                    " FROM ((ta_keluard LEFT JOIN Rek1 ON ta_keluard.IDRek1 = Rek1.IDRek1) " &
                    " LEFT JOIN Rek2 ON ta_keluard.IDRek2 = Rek2.IDRek2) " &
                    " LEFT JOIN Rek3 ON ta_keluard.IDRek3 = Rek3.IDRek3 " &
                    " WHERE tahun = '" & FrmTransaksi.TxtTahunK.Text & "' AND kd_bulan = '" & FrmTransaksi.LblBulanK.Text & "' AND kd_minggu = '" & FrmTransaksi.LblMingguK.Text & "' " &
                    " ORDER BY ta_keluard.tanggal, ta_keluard.no_bukti;"
            'query = "SELECT ta_penjtunairinc.NoBukti, ta_penjtunairinc.NoUrut, ta_penjtunairinc.Rek1, Rek1.Uraian, ta_penjtunairinc.Rek2, Rek2.Uraian, ta_penjtunairinc.Rek3, Rek3.Uraian, ta_penjtunairinc.Rek4, Rek4.Uraian, ta_penjtunairinc.Jumlah, ta_penjtunairinc.Satuan, ta_penjtunairinc.Harga, ta_penjtunairinc.IdBayar" & _
            '      " FROM (((ta_penjtunairinc LEFT JOIN Rek1 ON ta_penjtunairinc.Rek1 = Rek1.IDRek1) " & _
            '      " LEFT JOIN Rek2 ON ta_penjtunairinc.Rek2 = Rek2.IDRek2) " & _
            '      " LEFT JOIN Rek3 ON ta_penjtunairinc.Rek3 = Rek3.IDRek3) " & _
            '      " LEFT JOIN Rek4 ON ta_penjtunairinc.Rek4 = Rek4.IDRek4 " & _
            '      " WHERE ((ta_penjtunairinc.NoBukti) = '" & FrmPenjualan.TxtNoBukti.Text & "') " & _
            '      " ORDER BY ta_penjtunairinc.NoBukti DESC;"
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVKeluarD.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVKeluarD
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(9))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(10))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(11))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(12))
                    '.Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(13))
                    '.Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(14))
                    '.Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(15))
                    '.Items(a).SubItems.Add(Format(Val(dsData.Tables(0).Rows(a).Item(10)) * Val(dsData.Tables(0).Rows(a).Item(12)), "###,##0"))
                    '.Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(11), "###,###"))
                    '.Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(12), "###,###"))

                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.Orange
                    End If
                End With
            Next
            'LblNamaDokter.Text = dsData.Tables(0).Rows(0).Item(1)
            TxtThKeluarD.Text = UCase(FrmTransaksi.TxtTahunK.Text)
            TxtBlnKeluarD.Text = UCase(FrmTransaksi.LblBulanK.Text)
            TxtMgKeluarD.Text = UCase(FrmTransaksi.LblMingguK.Text)

            'DTPDPener.Text = FrmTransaksi.DateTPHPener.Text
            'TxtKet.Text = mTotalPenjualanDet
            TxtUrKeluarD.Text = FrmTransaksi.TxtUraianK.Text
            TxtThKeluarD.BackColor = Color.AliceBlue
            TxtBlnKeluarD.BackColor = Color.AliceBlue
            TxtMgKeluarD.BackColor = Color.AliceBlue
            TxtUrKeluarD.BackColor = Color.AliceBlue
        Catch ex As Exception
            'MsgBox("Data penerd")
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub BtnCariRek_Click(sender As Object, e As EventArgs) Handles BtnCariRek.Click
        Try
            BersihkanIsiRekening()
            FrmCariRekDKeluar.ShowDialog()

            If Len(TxtAkun.Text) = 0 Then
                TxtAkun.Focus()
            Else
                TxtVol.Focus()
            End If

        Catch ex As Exception

        End Try
    End Sub
    Private Sub BersihkanIsiRekening()
        TxtAkun.Text = ""
        TxtKelAkun.Text = ""
        TxtJenisAkun.Text = ""
    End Sub

    Private Sub TSBSave_Click(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            If DateTPKeluarD.Text = "" Then
                MsgBox("Tanggal tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                DateTPKeluarD.Focus()
            Else
                If TxtBukti.Text = "" Then
                    MsgBox("No Urut/Bukti tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                    TxtBukti.Focus()
                Else
                    If TxtAkun.Text = "" Then
                        MsgBox("Silakan klik cari rekening", MsgBoxStyle.Exclamation, "Error")
                        BtnCariRek.Focus()

                    Else
                        If TxtVol.Text = "" Then
                            MsgBox("Volume tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                            TxtVol.Focus()
                        Else
                            If TxtHarga.Text = "" Then
                                MsgBox("Harga tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                                TxtHarga.Focus()
                            Else
                                If CbCabay.Text = "" Then
                                    MsgBox("Cara bayar tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                                    CbCabay.Focus()
                                Else


                                    'query = "UPDATE tblNamaKlinik SET namaklinik = '" & TxtPerush.Text & _
                                    '        "', namapimpinan = '" & TxtPimpinan.Text & _
                                    '        "', alamat = '" & TxtAlamat.Text & _
                                    '        "', notelepon = '" & TxtTelepon.Text & "'"


                                    query = "INSERT INTO ta_keluard(tahun, kd_bulan, kd_minggu, tanggal, no_bukti, IDRek1, IDRek2, IDRek3, volume, sat, harsat, bayar) values ('" & UCase(TxtThKeluarD.Text) &
                                            "', '" & TxtBlnKeluarD.Text & "', '" & TxtMgKeluarD.Text & "','" & DateTPKeluarD.Text & "', '" & TxtBukti.Text & "', '" & Microsoft.VisualBasic.Left(TxtAkun.Text, 1) &
                                            "', '" & Microsoft.VisualBasic.Left(TxtKelAkun.Text, 2) & "', '" & Microsoft.VisualBasic.Left(TxtJenisAkun.Text, 4) &
                                            "', '" & TxtVol.Text &
                                            "', '" & TxtSat.Text & "', '" & TxtHarga.Text &
                                            "', '" & CbCabay.Text & "') "
                                    daData = New OleDbDataAdapter(query, conn)
                                    dsData = New DataSet
                                    daData.Fill(dsData)
                                    'InsertJurnal()
                                    InsertJurnalKeluarD()
                                    IsiListKeluarD()
                                    TotalKeluarD()
                                    'FrmPenjualan.IsiListMasPenjualan()
                                    'BersihkanIsiRekening()
                                    BersihkanIsianDPener()
                                    'FrmTransaksi.IsiListHPenener()
                                    MsgBox("Simpan data berhasil", , "Pesan")

                                End If
                            End If
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub InsertJurnalKeluarD()
        Try
            'debet beban
            str = "INSERT INTO ta_jurnald(JurnalId, NoTipe, tanggal, NoUrut, rek1, rek2, rek3, NamaRek, Debet, Kredit) values ('" & TxtThKeluarD.Text & "/" & TxtBlnKeluarD.Text & "/" & TxtMgKeluarD.Text &
                                            "', 'CDJ01', '" & DateTPKeluarD.Text & "', '" & TxtBukti.Text & "', '" & Microsoft.VisualBasic.Left(TxtAkun.Text, 1) & "', '" & Microsoft.VisualBasic.Left(TxtKelAkun.Text, 2) &
                                            "',  '" & Microsoft.VisualBasic.Left(TxtJenisAkun.Text, 4) & "', '" & Microsoft.VisualBasic.Mid(TxtJenisAkun.Text, 8, 100) &
                                            "', '" & TxtNilai.Text & " ','0' ) "
            da = New OleDbDataAdapter(str, conn)
            ds = New DataSet
            da.Fill(ds)


            'kredit kas

            query = "INSERT INTO ta_jurnald(JurnalId, NoTipe, tanggal, NoUrut, rek1, rek2, rek3, NamaRek, Debet, Kredit) values ('" & TxtThKeluarD.Text & "/" & TxtBlnKeluarD.Text & "/" & TxtMgKeluarD.Text &
                                            "', 'CDJ01', '" & DateTPKeluarD.Text & "', '" & TxtBukti.Text & "', '" & Microsoft.VisualBasic.Left(LblCabay.Text, 1) & "', '" & Microsoft.VisualBasic.Left(LblCabay.Text, 2) & "', '" & LblCabay.Text &
                                            "', '" & CbCabay.Text & "', '0', '" & TxtNilai.Text & "') "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            'query = "INSERT INTO ta_jurnalh(JurnalId,uraian) values('" & TxtTahun.Text & "/" & LblBulan.Text & "/" & LblMinggu.Text &
            '"', '" & TxtUraian.Text & "') "
            'Microsoft.VisualBasic.Mid(TxtObyekAkun.Text, 10, 100)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TotalKeluarD()
        Dim mTotalPenjualanDet As Integer
        Dim mPPN As Decimal
        Dim mDPPPenjualanDet As Integer

        Try
            'query = "SELECT ta_keluard.tahun, ta_keluard.kd_bulan, ta_keluard.kd_minggu, Sum([volume]*[harsat]) AS SubTotal" &
            '        " FROM ta_keluard" &
            '        " GROUP BY ta_keluard.tahun, ta_keluard.kd_bulan, ta_keluard.kd_minggu " &
            '        " HAVING (((ta_keluard.tahun)= '" & TxtThDPener.Text & "') AND ((ta_keluard.kd_bulan)='" & TxtBlnDPener.Text & "') AND ((ta_keluard.kd_minggu)='" & TxtMgDPener.Text & "'));"

            query = " SELECT  Sum([volume]*[harsat]) AS SubTotal" &
                    " FROM ta_keluard" &
                    " WHERE (((ta_keluard.tahun)= '" & TxtThKeluarD.Text & "') AND ((ta_keluard.kd_bulan)='" & TxtBlnKeluarD.Text & "') AND ((ta_keluard.kd_minggu)='" & TxtMgKeluarD.Text & "'));"
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            TxtTotal.Text = Format(dsData.Tables(0).Rows(0).Item(0), "#,#0")
            mTotalPenjualanDet = dsData.Tables(0).Rows(0).Item(0)
            mPPN = 10 / 110 * mTotalPenjualanDet
            TxtPPN.Text = Format(mPPN, "#,#0")
            mDPPPenjualanDet = mTotalPenjualanDet - mPPN
            TxtDPP.Text = Format(mDPPPenjualanDet, "#,#0")
            'TxtNilai.Text = Format(Val(TxtVol.Text) * Val(TxtHarga.Text), "#,00")
            TerbilangRupiah()

            'CbCabay.Items.Clear()
            'For a = 0 To dsData.Tables(0).Rows.Count - 1
            '    With CbCabay
            '        .Items.Add(dsData.Tables(0).Rows(a).Item(0) & " : " & dsData.Tables(0).Rows(a).Item(1))
            '    End With
            'Next
        Catch ex As Exception
            'MsgBox("Load TotalPenjualanDet  salah format")
        End Try

    End Sub
    Private Sub TerbilangRupiah()
        Try
            ' menampilkan hasil dari fungsi terbilang ke textbox 2 berdasarkan angka dari textbox1
            Dim angka As Double = 0
            If Double.TryParse(TxtTotal.Text, angka) Then
                LblTerbilang.Text = Terbilang(angka)
            End If
            'If Double.TryParse(LblGTotal.Text, angka) Then
            '    LblTerbilang.Text = Terbilang(angka)
            'End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub FrmDPener_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        Try
            TotalKeluarD()
            TxtPPN.Text = String.Format("{0:n2}", CType(TxtPPN.Text, Double))
            TxtDPP.Text = String.Format("{0:n2}", CType(TxtDPP.Text, Double))
            'LblTotal.Text = String.Format("{0:n2}", CType(LblTotal.Text, Double))
            TxtTotal.Text = String.Format("{0:n2}", CType(TxtTotal.Text, Double))
            'LblGTotal.Text = String.Format("{0:n2}", CType(LblGTotal.Text, Double))

        Catch ex As Exception
            'MsgBox("Load  FrmPenjualanTunaiDet_Activated salah format total Penjualan")
        End Try
    End Sub

    Private Sub TSBEdit_Click(sender As Object, e As EventArgs) Handles TSBEdit.Click
        Try

            If TxtBukti.Text = "" Then
                MsgBox("No Urut tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                TxtBukti.Focus()
            Else
                'If Len(CbCabay.Text) < 10 Then
                '    MsgBox("Plih kembali cara bayar", MsgBoxStyle.OkOnly, "Pesan")
                '    CbCabay.Focus()
                'Else
                DeleteUntukEdit()
                DeleteJurnal()

                'query = "UPDATE ta_keluard SET tanggal = '" & DateTPKeluarD.Text & "', IDRek1 = '" & Microsoft.VisualBasic.Left(TxtAkun.Text, 1) &
                '                          "', IDRek2 = '" & Microsoft.VisualBasic.Left(TxtKelAkun.Text, 2) &
                '                          "', IDRek3 = '" & Microsoft.VisualBasic.Left(TxtJenisAkun.Text, 4) &
                '                          "', volume = '" & TxtVol.Text & "', sat = '" & TxtSat.Text &
                '                          "', harsat = '" & TxtHarga.Text & "', bayar =  '" & CbCabay.Text & "' " &
                '                          " WHERE tahun = '" & UCase(TxtThKeluarD.Text) & "' AND kd_bulan= '" & UCase(TxtBlnKeluarD.Text) & "' AND kd_minggu =  '" & TxtMgKeluarD.Text & "' AND no_bukti =  '" & TxtBukti.Text & "'  "
                query = "INSERT INTO ta_keluard(tahun, kd_bulan, kd_minggu, tanggal, no_bukti, IDRek1, IDRek2, IDRek3, volume, sat, harsat, bayar) values ('" & UCase(TxtThKeluarD.Text) &
                                            "', '" & TxtBlnKeluarD.Text & "', '" & TxtMgKeluarD.Text & "','" & DateTPKeluarD.Text & "', '" & TxtBukti.Text & "', '" & Microsoft.VisualBasic.Left(TxtAkun.Text, 1) &
                                            "', '" & Microsoft.VisualBasic.Left(TxtKelAkun.Text, 2) & "', '" & Microsoft.VisualBasic.Left(TxtJenisAkun.Text, 4) &
                                            "', '" & TxtVol.Text &
                                            "', '" & TxtSat.Text & "', '" & TxtHarga.Text &
                                            "', '" & CbCabay.Text & "') "


                daData = New OleDbDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)
                InsertJurnalKeluarD()
                IsiListKeluarD()
                TotalKeluarD()
                BersihkanIsianDPener()
                'FrmPenjualan.IsiListMasPenjualan()
                MsgBox("Ubah data berhasil", , "Pesan")
                'End If

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub DeleteUntukEdit()
        Try
            query = "DELETE FROM ta_keluard WHERE tahun = '" & TxtThKeluarD.Text & "' AND kd_bulan= '" & TxtBlnKeluarD.Text & "' AND kd_minggu =  '" & TxtMgKeluarD.Text & "' AND no_bukti =  '" & TxtBukti.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub DeleteJurnal()
        Try
            query = "DELETE FROM ta_jurnald WHERE jurnalid = '" & TxtThKeluarD.Text & "/" & TxtBlnKeluarD.Text & "/" & TxtMgKeluarD.Text & "' AND NoUrut = '" & TxtBukti.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
        Catch ex As Exception

        End Try
    End Sub
    Private Sub BersihkanIsianDPener()
        Try
            TxtAkun.Text = ""
            TxtBukti.Text = ""
            TxtKelAkun.Text = ""
            TxtJenisAkun.Text = ""
            'TxtObyekAkun.Text = ""
            TxtVol.Text = Val(0)
            TxtSat.Text = ""
            TxtHarga.Text = Val(0)
            CbCabay.Text = ""
            LblCabay.Text = ""
            TxtNilai.Text = Val(TxtVol.Text) * Val(TxtHarga.Text)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TSBDelete_Click(sender As Object, e As EventArgs) Handles TSBDelete.Click
        Try
            Dim delete As String
            delete = MsgBox("Yakin hapus...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus")
            Select Case delete
                Case vbCancel
                    TxtBukti.Enabled = True
                    TxtAkun.Focus()
                    BersihkanIsianDPener()
                    Exit Sub
                Case vbOK
                    If TxtBukti.Text = "" Then
                        MsgBox("No Urut tidak boleh kosong", MsgBoxStyle.Critical, "Error")
                        TxtBukti.Enabled = True
                        TxtBukti.Focus()
                    Else
                        Try
                            query = "DELETE FROM ta_keluard WHERE tahun = '" & UCase(TxtThKeluarD.Text) & "' AND kd_bulan= '" & UCase(TxtBlnKeluarD.Text) & "' AND kd_minggu =  '" & TxtMgKeluarD.Text & "' AND no_bukti =  '" & TxtBukti.Text & "' "
                            daData = New OleDbDataAdapter(query, conn)
                            dsData = New DataSet
                            daData.Fill(dsData)
                            DeleteJurnal()
                            IsiListKeluarD()
                            BersihkanIsianDPener()
                            'FrmPenjualan.IsiListMasPenjualan()
                            MsgBox("Hapus data berhasil", , "Pesan")
                        Catch ex As Exception
                            MsgBox("Hapus data gagal", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
                            TxtAkun.Focus()
                        End Try
                    End If
            End Select
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TSBCancel_Click(sender As Object, e As EventArgs) Handles TSBCancel.Click
        Try
            BersihkanIsianDPener()
            TxtBukti.Enabled = True
            TSBSave.Enabled = True
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BtnKeluar_Click(sender As Object, e As EventArgs) Handles BtnKeluar.Click
        Dispose()
    End Sub

    Private Sub LVDPener_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVKeluarD.SelectedIndexChanged
        Try
            AmbilDataLVDPener()
            TSBCancel.Enabled = True
            TxtBukti.Enabled = False
        Catch ex As Exception

        End Try

    End Sub
    Private Sub AmbilDataLVDPener()
        With LVKeluarD.SelectedItems
            Try
                DateTPKeluarD.Text = .Item(0).SubItems(0).Text
                TxtBukti.Text = .Item(0).SubItems(1).Text
                TxtAkun.Text = .Item(0).SubItems(2).Text & " : " & .Item(0).SubItems(3).Text
                TxtKelAkun.Text = .Item(0).SubItems(4).Text & " : " & .Item(0).SubItems(5).Text
                TxtJenisAkun.Text = .Item(0).SubItems(6).Text & " : " & .Item(0).SubItems(7).Text
                'TxtObyekAkun.Text = .Item(0).SubItems(8).Text & " : " & .Item(0).SubItems(9).Text
                TxtVol.Text = .Item(0).SubItems(8).Text
                TxtSat.Text = .Item(0).SubItems(9).Text
                TxtHarga.Text = .Item(0).SubItems(10).Text
                TxtNilai.Text = .Item(0).SubItems(11).Text
                CbCabay.Text = .Item(0).SubItems(12).Text
                'Lblbayar.Text = .Item(0).SubItems(12).Text



            Catch ex As Exception

            End Try
        End With
    End Sub

    Private Sub LVDPener_Click(sender As Object, e As EventArgs) Handles LVKeluarD.Click
        Try
            TSBSave.Enabled = False
            TSBEdit.Enabled = True
            TSBDelete.Enabled = True
            'TSBCancel.Enabled = False
            'BtnKeluar.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub CbCabay_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbCabay.SelectedIndexChanged
        Try
            query = "SELECT Rek3.IDRek3, Rek3.Uraian FROM Rek3 WHERE (((Rek3.Uraian) = '" & CbCabay.Text & "')) "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            With dsData.Tables(0).Rows(0)
                '.Items.Add(dsData.Tables(0).Rows(a).Item(0) & " : " & dsData.Tables(0).Rows(a).Item(1))
                LblCabay.Text = .Item(0)
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub FrmDPener_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            GetDatabaseSetting()
            PosisiListKeluarD()
            IsiListKeluarD()
            TotalKeluarD()
            carabayar_load()
            TSBCancel.Enabled = True
            TSBSave.Enabled = True
            BersihkanIsianDPener()

            'TxtNilai.Text = Format(Val(TxtVol.Text) * Val(TxtHarga.Text), "#,00")
            TerbilangRupiah()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Carabayar_load()
        Dim a As Integer
        Try
            query = "SELECT Rek3.IDRek3, Rek3.Uraian FROM Rek3 WHERE (((Rek3.IDRek3) Like '111' &'%')) ORDER BY Rek3.IDRek3;"

            'query = "SELECT Rek4.IDRek4, Rek4.Uraian FROM Rek4 " & _
            '    " WHERE (((Rek4.IDRek4) Like  '111" & "%" ))" & _
            '    " ORDER BY Rek4.IDRek4; "

            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbCabay.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbCabay
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(0) & " : " & dsData.Tables(0).Rows(a).Item(1))
                    .Items.Add(dsData.Tables(0).Rows(a).Item(1))
                End With
            Next
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TxtUrut_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtBukti.KeyPress
        If e.KeyChar = Chr(13) Then
            TxtAkun.Focus()
        End If

        'If Len(TxtUrut.Text) < 2 Then
        '    MsgBox("isikan angka 2 digit", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
        '    TxtUrut.Focus()
        'End If

        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = "," Or e.KeyChar = ".") Then
            e.Handled = True
        End If
    End Sub

    Private Sub TxtVol_TextChanged(sender As Object, e As EventArgs) Handles TxtVol.TextChanged
        Try
            TxtNilai.Text = Format(Val(TxtVol.Text) * Val(TxtHarga.Text), "#,00")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TxtHarga_TextChanged(sender As Object, e As EventArgs) Handles TxtHarga.TextChanged
        Try
            TxtNilai.Text = Format(Val(TxtVol.Text) * Val(TxtHarga.Text), "#,00")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TxtVol_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtVol.KeyPress
        If e.KeyChar = Chr(13) Then
            'TxtNilai.Text = Val(TxtVol.Text) * Val(TxtHarga.Text)
            TxtNilai.Text = Format(Val(TxtVol.Text) * Val(TxtHarga.Text), "#,00")
            TxtSat.Focus()
        End If

        'If e.KeyChar = Chr(13) Then
        '    TxtAkun.Focus()
        'End If

        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = "," Or e.KeyChar = ".") Then
            e.Handled = True
        End If
    End Sub

    Private Sub TxtHarga_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtHarga.KeyPress
        If e.KeyChar = Chr(13) Then
            'TxtNilai.Text = Val(TxtVol.Text) * Val(TxtHarga.Text)
            TxtNilai.Text = Format(Val(TxtVol.Text) * Val(TxtHarga.Text), "#,00")
            CbCabay.Focus()
        End If

        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = "," Or e.KeyChar = ".") Then
            e.Handled = True
        End If
    End Sub

    Private Sub CbCabay_TextChanged(sender As Object, e As EventArgs) Handles CbCabay.TextChanged

        Try
                query = "SELECT Rek3.IDRek3, Rek3.Uraian FROM Rek3 WHERE (((Rek3.Uraian) = '" & CbCabay.Text & "')) "
                daData = New OleDbDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)

                With dsData.Tables(0).Rows(0)
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(0) & " : " & dsData.Tables(0).Rows(a).Item(1))
                    LblCabay.Text = .Item(0)
                End With

            Catch ex As Exception

            End Try



    End Sub
End Class