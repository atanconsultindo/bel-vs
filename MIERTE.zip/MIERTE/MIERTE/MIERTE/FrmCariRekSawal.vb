﻿Imports System.Data.OleDb
Public Class FrmCariRekSawal
    Private Sub PosisiListRek()
        With LVRekeningSub.Columns
            .Add("Kd. Akun", 0)
            .Add("Nama Akun", 100)
            .Add("Kd. Kel.", 0)
            .Add("Nama Kel", 200)
            .Add("Kd Jenis", 0)
            .Add("Nama Jenis", 350)
            '.Add("Kd. Obyek", 90)
            '.Add("Nama Obyek", 300)

        End With
    End Sub

    Private Sub IsiListRekening()
        Dim a As Integer
        Try
            query = "SELECT Rek3.IDRek1, Rek1.Uraian, Rek3.IDRek2, Rek2.Uraian, Rek3.IDRek3, Rek3.Uraian " &
                    " FROM (Rek3 LEFT JOIN Rek2 ON Rek3.IDRek2 = Rek2.IDRek2)  " &
                    "  LEFT JOIN Rek1 ON Rek3.IDRek1 = Rek1.IDRek1 " &
                    " ORDER BY Rek3.IDRek1, Rek3.IDRek2, Rek3.IDRek3 "

            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVRekeningSub.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVRekeningSub
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    '.Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    '.Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))

                    '.Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))


                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.Orange
                    End If
                End With

            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub AmbilDataDariLVRekening()
        With LVRekeningSub.SelectedItems
            Try
                'FrmSawal.TxtAkun.Text = .Item(0).SubItems(0).Text & " : " & .Item(0).SubItems(1).Text
                'FrmSawal.TxtKelAkun.Text = .Item(0).SubItems(2).Text & " : " & .Item(0).SubItems(3).Text
                'FrmSawal.TxtJenisAkun.Text = .Item(0).SubItems(4).Text & " : " & .Item(0).SubItems(5).Text
                'FrmSawal.TxtObyekAkun.Text = .Item(0).SubItems(6).Text & " : " & .Item(0).SubItems(7).Text

                FrmSawal.TxtAkun.Text = .Item(0).SubItems(1).Text
                FrmSawal.TxtKelAkun.Text = .Item(0).SubItems(3).Text
                FrmSawal.TxtJenisAkun.Text = .Item(0).SubItems(5).Text
                'FrmSawal.TxtObyekAkun.Text = .Item(0).SubItems(7).Text

                'FrmDiagnosa.CariIdPasien()
            Catch ex As Exception

            End Try
        End With
    End Sub

    Private Sub CariData()
        Try
            If CboKriteria.Text = "Kode Akun" Then

                query = "SELECT Rek3.IDRek1, Rek1.Uraian, Rek3.IDRek2, Rek2.Uraian, Rek3.IDRek3, Rek3.Uraian " &
                    "  FROM (Rek3 LEFT JOIN Rek2 ON Rek3.IDRek2 = Rek2.IDRek2)  " &
                    " LEFT JOIN Rek1 ON Rek3.IDRek1 = Rek1.IDRek1 " &
                    " WHERE Rek3.IDRek3 Like   '%" & TxtCariData.Text & "%' " &
                    " ORDER BY Rek3.IDRek1, Rek3.IDRek2, Rek3.IDRek3; "
            Else
                query = "SELECT Rek3.IDRek1, Rek1.Uraian, Rek3.IDRek2, Rek2.Uraian, Rek3.IDRek3, Rek3.Uraian " &
                    "  FROM (Rek3 LEFT JOIN Rek2 ON Rek3.IDRek2 = Rek2.IDRek2)  " &
                    " LEFT JOIN Rek1 ON Rek3.IDRek1 = Rek1.IDRek1 " &
                    " WHERE Rek3.Uraian Like '%" & TxtCariData.Text & "%' " &
                    " ORDER BY Rek3.IDRek1, Rek3.IDRek2, Rek3.IDRek3; "

                'query = "SELECT Rek4.IDRek1, Rek1.Uraian, Rek4.IDRek2, Rek2.Uraian, Rek4.IDRek3, Rek3.Uraian, Rek4.IDRek4, Rek4.Uraian " &
                '    " FROM ((Rek4 LEFT JOIN Rek2 ON Rek4.IDRek2 = Rek2.IDRek2) " &
                '    " LEFT JOIN Rek3 ON Rek4.IDRek3 = Rek3.IDRek3) " &
                '    " LEFT JOIN Rek1 ON Rek4.IDRek1 = Rek1.IDRek1 " &
                '    " WHERE Rek4.Uraian Like  '%" & TxtCariData.Text & "%'  " &
                '    " ORDER BY Rek4.IDRek1, Rek4.IDRek2, Rek4.IDRek3, Rek4.IDRek4; "

                'WHERE(((Rek4.IDRek1) = "4") And ((Rek4.IDRek2) = "41"))
                '" WHERE (((Rek4.IDRek1) = 4) AND ((Rek4.Uraian) Like  '%" & TxtCariData.Text & "%'))  " & _


            End If
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVRekeningSub.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVRekeningSub
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))


                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.Orange
                    End If
                End With

            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub FrmCariRekening_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            PosisiListRek()
            IsiListRekening()

        Catch ex As Exception
            MsgBox("Koneksi Gagal")
        End Try

    End Sub

    Private Sub BtnPilih_Click(sender As Object, e As EventArgs) Handles BtnPilih.Click
        Try
            AmbilDataDariLVRekening()
            'FrmPenjualanTunaiDet.IsiListPenjTunaiDet()
            'FrmDiagnosa.TotalKunjungan()
            Dispose()
        Catch ex As Exception
            MsgBox("Koneksi data kesalahan")
        End Try
    End Sub

    Private Sub BtnKeluar_Click(sender As Object, e As EventArgs) Handles BtnKeluar.Click
        Me.Dispose()
    End Sub

    Private Sub FrmCariRekening_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        TxtCariData.Focus()
    End Sub

    Private Sub LVRekeningSub_DoubleClick(sender As Object, e As EventArgs) Handles LVRekeningSub.DoubleClick
        Try
            AmbilDataDariLVRekening()
            Dispose()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub LVRekeningSub_KeyPress(sender As Object, e As KeyPressEventArgs) Handles LVRekeningSub.KeyPress
        If e.KeyChar = Chr(13) Then
            AmbilDataDariLVRekening()
            Dispose()
        End If
    End Sub

    Private Sub LVRekeningSub_KeyUp(sender As Object, e As KeyEventArgs) Handles LVRekeningSub.KeyUp
        If e.KeyCode = Keys.Escape Then
            Me.Dispose()
        End If
    End Sub

    Private Sub CboKriteria_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CboKriteria.KeyPress
        If e.KeyChar = Chr(13) Then
            TxtCariData.Focus()
        End If
    End Sub

    Private Sub TxtCariData_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCariData.KeyPress
        If e.KeyChar = Chr(13) Then
            LVRekeningSub.Focus()
        End If
    End Sub

    Private Sub TxtCariData_KeyUp(sender As Object, e As KeyEventArgs) Handles TxtCariData.KeyUp
        If e.KeyCode = Keys.Escape Then
            If TxtCariData.Text = "" Then
                Me.Dispose()
            Else
                TxtCariData.Focus()
            End If
        End If
    End Sub

    Private Sub TxtCariData_TextChanged(sender As Object, e As EventArgs) Handles TxtCariData.TextChanged
        Try
            CariData()
        Catch ex As Exception

        End Try
    End Sub


End Class