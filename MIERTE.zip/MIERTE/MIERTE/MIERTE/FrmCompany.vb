﻿Imports System.Data.OleDb
Public Class FrmCompany
    Private Sub SetProfile()
        Try
            query = "SELECT * FROM r_perush"
            daData = New OledbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            With dsData.Tables(0).Rows(0)
                TxtNama.Text = .Item(1)
                TxtAlamat.Text = .Item(2)
                TxtNpwp.Text = .Item(3)
                TxtTelp.Text = .Item(4)
                TxtEmail.Text = .Item(5)
                TxtPimp.Text = .Item(6)
                TxtTahun.Text = .Item(7)
            End With
        Catch ex As Exception
            MsgBox("Silakan isi Company Profile...", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
        End Try
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Dispose()
    End Sub

    Private Sub FrmCompany_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetDatabaseSetting()
        SetProfile()
    End Sub


    Private Sub TxtTahun_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtTahun.KeyPress
        If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack Or e.KeyChar = ".") Then
            e.Handled = True
        End If

        If e.KeyChar = Chr(13) Then

            ToolStrip1.Focus()

        End If
    End Sub

    Private Sub TxtNama_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNama.KeyPress
        If e.KeyChar = Chr(13) Then
            If TxtNama.Text = "" Then
                MsgBox("Nama Masih Kosong", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
            Else
                TxtAlamat.Focus()
            End If
        End If
    End Sub

    Private Sub TxtAlamat_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtAlamat.KeyPress
        If e.KeyChar = Chr(13) Then
            If TxtAlamat.Text = "" Then
                MsgBox("Alamat Masih Kosong", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
            Else
                TxtNpwp.Focus()
            End If
        End If
    End Sub

    Private Sub TxtTelp_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtTelp.KeyPress
        If e.KeyChar = Chr(13) Then

            TxtEmail.Focus()

        End If
    End Sub

    Private Sub TxtEmail_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtEmail.KeyPress
        If e.KeyChar = Chr(13) Then

            TxtPimp.Focus()

        End If
    End Sub

    Private Sub TxtPimp_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtPimp.KeyPress
        If e.KeyChar = Chr(13) Then

            TxtTahun.Focus()

        End If
    End Sub

    Private Sub TSBSave_Click(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            Dim A As String

            If TxtNama.Text = "" Then
                MessageBox.Show("Nama tidak boleh kosong", "warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TxtNama.Focus()
            Else
                If TxtAlamat.Text = "" Then
                    MsgBox("Alamat tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                    TxtAlamat.Focus()
                Else
                    If TxtNpwp.Text = "" Then
                        MsgBox("NPWP akun tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                        TxtNpwp.Focus()
                    Else
                        If TxtTahun.Text = "" Then
                            MsgBox("Tahun akun tidak boleh kosong", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Pesan")
                            TxtTahun.Focus()
                        Else

                            If dsData.Tables(0).Rows.Count - 1 Then
                                query = "INSERT INTO r_perush VALUES('" & TxtNama.Text & "', '" & TxtAlamat.Text & "', '" & TxtNpwp.Text & "', '" & TxtTelp.Text & "', '" & TxtEmail.Text & "', '" & TxtPimp.Text & "', '" & TxtTahun.Text & "')"
                                daData = New OleDbDataAdapter(query, conn)
                                dsData = New DataSet
                                daData.Fill(dsData)
                                SetProfile()
                                MsgBox("Data saved ...", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Pesan")
                                TxtNama.Focus()
                            Else
                                A = MsgBox("Edit Data", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Informasi")
                                Select Case A
                                    Case vbCancel
                                        TxtNama.Focus()
                                        Exit Sub
                                    Case vbOK
                                        query = "UPDATE r_perush SET nama = '" & TxtNama.Text & "', alamat = '" & TxtAlamat.Text & "', npwp = '" & TxtNpwp.Text & "', telepon = '" & TxtTelp.Text & "', email = '" & TxtEmail.Text & "', pimpinan = '" & TxtPimp.Text & "', tahun = '" & TxtTahun.Text & "' "
                                        daData = New OleDbDataAdapter(query, conn)
                                        dsData = New DataSet
                                        daData.Fill(dsData)
                                        SetProfile()
                                        MsgBox("Data updated...", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Pesan")
                                        TxtNama.Focus()
                                End Select
                            End If
                        End If
                    End If
                End If
            End If

        Catch ex As Exception
            'MsgBox("Data tidak bisa tersimpan karena user sudah ada...", MsgBoxStyle.Exclamation, "Error")
            'CbGroup.Focus()
        End Try
    End Sub
End Class