﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSawal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmSawal))
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.TSBTambah = New System.Windows.Forms.ToolStripButton()
        Me.TSBSave = New System.Windows.Forms.ToolStripButton()
        Me.TSBEdit = New System.Windows.Forms.ToolStripButton()
        Me.TSBDelete = New System.Windows.Forms.ToolStripButton()
        Me.TSBCancel = New System.Windows.Forms.ToolStripButton()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.LblBalance = New System.Windows.Forms.Label()
        Me.LblTotalDebet = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblJn = New System.Windows.Forms.Label()
        Me.lblKel = New System.Windows.Forms.Label()
        Me.lblAk = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtNoUrut = New System.Windows.Forms.TextBox()
        Me.LVSawal = New System.Windows.Forms.ListView()
        Me.LblTotalKredit = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.CbPeriode = New System.Windows.Forms.ComboBox()
        Me.TxtNilaiKredit = New System.Windows.Forms.TextBox()
        Me.TxtJenisAkun = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtKelAkun = New System.Windows.Forms.TextBox()
        Me.TxtAkun = New System.Windows.Forms.TextBox()
        Me.BtnCariRek = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TxtNilaiDebet = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Image = CType(resources.GetObject("BtnKeluar.Image"), System.Drawing.Image)
        Me.BtnKeluar.Location = New System.Drawing.Point(328, 534)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(75, 25)
        Me.BtnKeluar.TabIndex = 57
        Me.BtnKeluar.Text = "Keluar"
        Me.BtnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBTambah, Me.TSBSave, Me.TSBEdit, Me.TSBDelete, Me.TSBCancel})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 213)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(721, 25)
        Me.ToolStrip1.TabIndex = 98
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'TSBTambah
        '
        Me.TSBTambah.Image = CType(resources.GetObject("TSBTambah.Image"), System.Drawing.Image)
        Me.TSBTambah.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBTambah.Name = "TSBTambah"
        Me.TSBTambah.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TSBTambah.Size = New System.Drawing.Size(69, 22)
        Me.TSBTambah.Text = "Tambah"
        Me.TSBTambah.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'TSBSave
        '
        Me.TSBSave.Image = CType(resources.GetObject("TSBSave.Image"), System.Drawing.Image)
        Me.TSBSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSave.Name = "TSBSave"
        Me.TSBSave.Size = New System.Drawing.Size(67, 22)
        Me.TSBSave.Text = "Simpan"
        '
        'TSBEdit
        '
        Me.TSBEdit.Image = CType(resources.GetObject("TSBEdit.Image"), System.Drawing.Image)
        Me.TSBEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBEdit.Name = "TSBEdit"
        Me.TSBEdit.Size = New System.Drawing.Size(47, 22)
        Me.TSBEdit.Text = "Edit"
        '
        'TSBDelete
        '
        Me.TSBDelete.Image = CType(resources.GetObject("TSBDelete.Image"), System.Drawing.Image)
        Me.TSBDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBDelete.Name = "TSBDelete"
        Me.TSBDelete.Size = New System.Drawing.Size(61, 22)
        Me.TSBDelete.Text = "Hapus"
        '
        'TSBCancel
        '
        Me.TSBCancel.Image = CType(resources.GetObject("TSBCancel.Image"), System.Drawing.Image)
        Me.TSBCancel.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCancel.Name = "TSBCancel"
        Me.TSBCancel.Size = New System.Drawing.Size(53, 22)
        Me.TSBCancel.Text = "Batal"
        '
        'Label21
        '
        Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(483, 496)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(100, 20)
        Me.Label21.TabIndex = 55
        Me.Label21.Text = "Balance"
        '
        'Label20
        '
        Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label20.Location = New System.Drawing.Point(483, 472)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(100, 20)
        Me.Label20.TabIndex = 54
        Me.Label20.Text = "Saldo Kredit:"
        '
        'LblBalance
        '
        Me.LblBalance.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblBalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblBalance.Location = New System.Drawing.Point(614, 496)
        Me.LblBalance.Name = "LblBalance"
        Me.LblBalance.Size = New System.Drawing.Size(125, 20)
        Me.LblBalance.TabIndex = 53
        '
        'LblTotalDebet
        '
        Me.LblTotalDebet.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblTotalDebet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblTotalDebet.Location = New System.Drawing.Point(614, 448)
        Me.LblTotalDebet.Name = "LblTotalDebet"
        Me.LblTotalDebet.Size = New System.Drawing.Size(125, 20)
        Me.LblTotalDebet.TabIndex = 52
        '
        'Label15
        '
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label15.Location = New System.Drawing.Point(483, 448)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(100, 20)
        Me.Label15.TabIndex = 51
        Me.Label15.Text = "Seldo Debet:"
        '
        'lblJn
        '
        Me.lblJn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lblJn.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblJn.Location = New System.Drawing.Point(641, 122)
        Me.lblJn.Name = "lblJn"
        Me.lblJn.Size = New System.Drawing.Size(43, 15)
        Me.lblJn.TabIndex = 96
        Me.lblJn.Text = "Jenis"
        '
        'lblKel
        '
        Me.lblKel.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lblKel.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblKel.Location = New System.Drawing.Point(641, 98)
        Me.lblKel.Name = "lblKel"
        Me.lblKel.Size = New System.Drawing.Size(43, 15)
        Me.lblKel.TabIndex = 95
        Me.lblKel.Text = "Kelompok"
        '
        'lblAk
        '
        Me.lblAk.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lblAk.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblAk.Location = New System.Drawing.Point(641, 74)
        Me.lblAk.Name = "lblAk"
        Me.lblAk.Size = New System.Drawing.Size(43, 15)
        Me.lblAk.TabIndex = 94
        Me.lblAk.Text = "Akun"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(30, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 90
        Me.Label2.Text = "No.Urut:"
        '
        'TxtNoUrut
        '
        Me.TxtNoUrut.Location = New System.Drawing.Point(83, 43)
        Me.TxtNoUrut.MaxLength = 4
        Me.TxtNoUrut.Name = "TxtNoUrut"
        Me.TxtNoUrut.Size = New System.Drawing.Size(548, 20)
        Me.TxtNoUrut.TabIndex = 89
        '
        'LVSawal
        '
        Me.LVSawal.FullRowSelect = True
        Me.LVSawal.GridLines = True
        Me.LVSawal.HideSelection = False
        Me.LVSawal.Location = New System.Drawing.Point(6, 20)
        Me.LVSawal.Name = "LVSawal"
        Me.LVSawal.Size = New System.Drawing.Size(715, 161)
        Me.LVSawal.TabIndex = 0
        Me.LVSawal.UseCompatibleStateImageBehavior = False
        Me.LVSawal.View = System.Windows.Forms.View.Details
        '
        'LblTotalKredit
        '
        Me.LblTotalKredit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblTotalKredit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblTotalKredit.Location = New System.Drawing.Point(614, 472)
        Me.LblTotalKredit.Name = "LblTotalKredit"
        Me.LblTotalKredit.Size = New System.Drawing.Size(125, 20)
        Me.LblTotalKredit.TabIndex = 56
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LVSawal)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 258)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(727, 187)
        Me.GroupBox3.TabIndex = 50
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Data Rincian Saldo wal"
        '
        'CbPeriode
        '
        Me.CbPeriode.FormattingEnabled = True
        Me.CbPeriode.Items.AddRange(New Object() {"202112", "202012", "201912", "201812", "201712", "201612", "201512"})
        Me.CbPeriode.Location = New System.Drawing.Point(83, 17)
        Me.CbPeriode.Name = "CbPeriode"
        Me.CbPeriode.Size = New System.Drawing.Size(548, 21)
        Me.CbPeriode.TabIndex = 88
        '
        'TxtNilaiKredit
        '
        Me.TxtNilaiKredit.Location = New System.Drawing.Point(408, 168)
        Me.TxtNilaiKredit.Name = "TxtNilaiKredit"
        Me.TxtNilaiKredit.Size = New System.Drawing.Size(223, 20)
        Me.TxtNilaiKredit.TabIndex = 93
        '
        'TxtJenisAkun
        '
        Me.TxtJenisAkun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtJenisAkun.Enabled = False
        Me.TxtJenisAkun.Location = New System.Drawing.Point(83, 118)
        Me.TxtJenisAkun.Name = "TxtJenisAkun"
        Me.TxtJenisAkun.Size = New System.Drawing.Size(548, 20)
        Me.TxtJenisAkun.TabIndex = 83
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.ToolStrip1)
        Me.GroupBox2.Controls.Add(Me.lblJn)
        Me.GroupBox2.Controls.Add(Me.lblKel)
        Me.GroupBox2.Controls.Add(Me.lblAk)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.TxtNoUrut)
        Me.GroupBox2.Controls.Add(Me.CbPeriode)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.TxtNilaiKredit)
        Me.GroupBox2.Controls.Add(Me.TxtJenisAkun)
        Me.GroupBox2.Controls.Add(Me.TxtKelAkun)
        Me.GroupBox2.Controls.Add(Me.TxtAkun)
        Me.GroupBox2.Controls.Add(Me.BtnCariRek)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.TxtNilaiDebet)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 11)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(727, 241)
        Me.GroupBox2.TabIndex = 49
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Formulir Isian Saldo Awal"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(331, 168)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 87
        Me.Label1.Text = "Kredit :"
        '
        'TxtKelAkun
        '
        Me.TxtKelAkun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtKelAkun.Enabled = False
        Me.TxtKelAkun.Location = New System.Drawing.Point(83, 93)
        Me.TxtKelAkun.Name = "TxtKelAkun"
        Me.TxtKelAkun.Size = New System.Drawing.Size(548, 20)
        Me.TxtKelAkun.TabIndex = 82
        '
        'TxtAkun
        '
        Me.TxtAkun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtAkun.Location = New System.Drawing.Point(83, 68)
        Me.TxtAkun.Name = "TxtAkun"
        Me.TxtAkun.Size = New System.Drawing.Size(510, 20)
        Me.TxtAkun.TabIndex = 91
        '
        'BtnCariRek
        '
        Me.BtnCariRek.Image = CType(resources.GetObject("BtnCariRek.Image"), System.Drawing.Image)
        Me.BtnCariRek.Location = New System.Drawing.Point(599, 70)
        Me.BtnCariRek.Name = "BtnCariRek"
        Me.BtnCariRek.Size = New System.Drawing.Size(32, 20)
        Me.BtnCariRek.TabIndex = 90
        Me.BtnCariRek.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(28, 17)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 13)
        Me.Label7.TabIndex = 75
        Me.Label7.Text = "Periode :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(28, 167)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 13)
        Me.Label13.TabIndex = 72
        Me.Label13.Text = "Debet :"
        '
        'TxtNilaiDebet
        '
        Me.TxtNilaiDebet.Location = New System.Drawing.Point(83, 168)
        Me.TxtNilaiDebet.Name = "TxtNilaiDebet"
        Me.TxtNilaiDebet.Size = New System.Drawing.Size(223, 20)
        Me.TxtNilaiDebet.TabIndex = 92
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label10.Location = New System.Drawing.Point(43, 117)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(34, 13)
        Me.Label10.TabIndex = 66
        Me.Label10.Text = "Jenis:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Label5.Location = New System.Drawing.Point(20, 92)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 13)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "Kelompok:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(42, 67)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "Akun:"
        '
        'FrmSawal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(751, 570)
        Me.Controls.Add(Me.BtnKeluar)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.LblBalance)
        Me.Controls.Add(Me.LblTotalDebet)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.LblTotalKredit)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmSawal"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Saldo Awal"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnKeluar As Button
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents TSBTambah As ToolStripButton
    Friend WithEvents TSBSave As ToolStripButton
    Friend WithEvents TSBEdit As ToolStripButton
    Friend WithEvents TSBDelete As ToolStripButton
    Friend WithEvents TSBCancel As ToolStripButton
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents LblBalance As Label
    Friend WithEvents LblTotalDebet As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents lblJn As Label
    Friend WithEvents lblKel As Label
    Friend WithEvents lblAk As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtNoUrut As TextBox
    Friend WithEvents LVSawal As ListView
    Friend WithEvents LblTotalKredit As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents CbPeriode As ComboBox
    Friend WithEvents TxtNilaiKredit As TextBox
    Friend WithEvents TxtJenisAkun As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtKelAkun As TextBox
    Friend WithEvents TxtAkun As TextBox
    Friend WithEvents BtnCariRek As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents TxtNilaiDebet As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
End Class
