﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCariRekDPener
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCariRekDPener))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.LVRekeningSub = New System.Windows.Forms.ListView()
        Me.TxtCariData = New System.Windows.Forms.TextBox()
        Me.CboKriteria = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.BtnPilih = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.LVRekeningSub)
        Me.GroupBox1.Controls.Add(Me.TxtCariData)
        Me.GroupBox1.Controls.Add(Me.CboKriteria)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 10)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(828, 327)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        '
        'LVRekeningSub
        '
        Me.LVRekeningSub.FullRowSelect = True
        Me.LVRekeningSub.GridLines = True
        Me.LVRekeningSub.HideSelection = False
        Me.LVRekeningSub.Location = New System.Drawing.Point(15, 62)
        Me.LVRekeningSub.MultiSelect = False
        Me.LVRekeningSub.Name = "LVRekeningSub"
        Me.LVRekeningSub.Size = New System.Drawing.Size(807, 249)
        Me.LVRekeningSub.TabIndex = 4
        Me.LVRekeningSub.UseCompatibleStateImageBehavior = False
        Me.LVRekeningSub.View = System.Windows.Forms.View.Details
        '
        'TxtCariData
        '
        Me.TxtCariData.Location = New System.Drawing.Point(156, 34)
        Me.TxtCariData.Name = "TxtCariData"
        Me.TxtCariData.Size = New System.Drawing.Size(666, 20)
        Me.TxtCariData.TabIndex = 3
        '
        'CboKriteria
        '
        Me.CboKriteria.FormattingEnabled = True
        Me.CboKriteria.Items.AddRange(New Object() {"Kode Akun", "Nama AKun"})
        Me.CboKriteria.Location = New System.Drawing.Point(15, 34)
        Me.CboKriteria.Name = "CboKriteria"
        Me.CboKriteria.Size = New System.Drawing.Size(135, 21)
        Me.CboKriteria.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(156, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Data yang dicari:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(15, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Kriteria:"
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Image = CType(resources.GetObject("BtnKeluar.Image"), System.Drawing.Image)
        Me.BtnKeluar.Location = New System.Drawing.Point(387, 343)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(75, 23)
        Me.BtnKeluar.TabIndex = 27
        Me.BtnKeluar.Text = "Keluar"
        Me.BtnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'BtnPilih
        '
        Me.BtnPilih.Image = CType(resources.GetObject("BtnPilih.Image"), System.Drawing.Image)
        Me.BtnPilih.Location = New System.Drawing.Point(306, 343)
        Me.BtnPilih.Name = "BtnPilih"
        Me.BtnPilih.Size = New System.Drawing.Size(75, 23)
        Me.BtnPilih.TabIndex = 26
        Me.BtnPilih.Text = "Pilih"
        Me.BtnPilih.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnPilih.UseVisualStyleBackColor = True
        '
        'FrmCariRekDPener
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(853, 376)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.BtnKeluar)
        Me.Controls.Add(Me.BtnPilih)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmCariRekDPener"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cari Kode Rekening Penerimaan"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents LVRekeningSub As ListView
    Friend WithEvents TxtCariData As TextBox
    Friend WithEvents CboKriteria As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents BtnKeluar As Button
    Friend WithEvents BtnPilih As Button
End Class
