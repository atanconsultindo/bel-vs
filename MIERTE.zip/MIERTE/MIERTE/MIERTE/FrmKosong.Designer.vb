﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmKosong
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmKosong))
        Me.Timer = New System.Windows.Forms.Timer(Me.components)
        Me.ChkMKI = New System.Windows.Forms.CheckBox()
        Me.LblProgress = New System.Windows.Forms.Label()
        Me.ProgressBarKos = New System.Windows.Forms.ProgressBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtKosong = New System.Windows.Forms.TextBox()
        Me.ChkBSusut = New System.Windows.Forms.CheckBox()
        Me.ChkBFiskal = New System.Windows.Forms.CheckBox()
        Me.ChkBJurnal = New System.Windows.Forms.CheckBox()
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.ChkBSawal = New System.Windows.Forms.CheckBox()
        Me.ChkBSPP = New System.Windows.Forms.CheckBox()
        Me.ChkBAset = New System.Windows.Forms.CheckBox()
        Me.ChkWarga = New System.Windows.Forms.CheckBox()
        Me.ChkProyek = New System.Windows.Forms.CheckBox()
        Me.ChkKeluar = New System.Windows.Forms.CheckBox()
        Me.ChkPener = New System.Windows.Forms.CheckBox()
        Me.BtbProses = New System.Windows.Forms.Button()
        Me.ChkBBasil = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer
        '
        '
        'ChkMKI
        '
        Me.ChkMKI.AutoSize = True
        Me.ChkMKI.Location = New System.Drawing.Point(39, 231)
        Me.ChkMKI.Name = "ChkMKI"
        Me.ChkMKI.Size = New System.Drawing.Size(108, 17)
        Me.ChkMKI.TabIndex = 17
        Me.ChkMKI.Text = "Mutasi Kas Intern"
        Me.ChkMKI.UseVisualStyleBackColor = True
        Me.ChkMKI.Visible = False
        '
        'LblProgress
        '
        Me.LblProgress.ForeColor = System.Drawing.Color.Red
        Me.LblProgress.Location = New System.Drawing.Point(316, 341)
        Me.LblProgress.Name = "LblProgress"
        Me.LblProgress.Size = New System.Drawing.Size(440, 23)
        Me.LblProgress.TabIndex = 16
        '
        'ProgressBarKos
        '
        Me.ProgressBarKos.Location = New System.Drawing.Point(317, 315)
        Me.ProgressBarKos.Name = "ProgressBarKos"
        Me.ProgressBarKos.Size = New System.Drawing.Size(439, 23)
        Me.ProgressBarKos.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.ProgressBarKos.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(314, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 13)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Pengosongan Data:"
        '
        'TxtKosong
        '
        Me.TxtKosong.Location = New System.Drawing.Point(317, 39)
        Me.TxtKosong.Multiline = True
        Me.TxtKosong.Name = "TxtKosong"
        Me.TxtKosong.Size = New System.Drawing.Size(439, 270)
        Me.TxtKosong.TabIndex = 12
        '
        'ChkBSusut
        '
        Me.ChkBSusut.AutoSize = True
        Me.ChkBSusut.Location = New System.Drawing.Point(39, 303)
        Me.ChkBSusut.Name = "ChkBSusut"
        Me.ChkBSusut.Size = New System.Drawing.Size(82, 17)
        Me.ChkBSusut.TabIndex = 11
        Me.ChkBSusut.Text = "Penyusutan"
        Me.ChkBSusut.UseVisualStyleBackColor = True
        Me.ChkBSusut.Visible = False
        '
        'ChkBFiskal
        '
        Me.ChkBFiskal.AutoSize = True
        Me.ChkBFiskal.Enabled = False
        Me.ChkBFiskal.Location = New System.Drawing.Point(39, 279)
        Me.ChkBFiskal.Name = "ChkBFiskal"
        Me.ChkBFiskal.Size = New System.Drawing.Size(117, 17)
        Me.ChkBFiskal.TabIndex = 10
        Me.ChkBFiskal.Text = "Penyesuaian Fiskal"
        Me.ChkBFiskal.UseVisualStyleBackColor = True
        Me.ChkBFiskal.Visible = False
        '
        'ChkBJurnal
        '
        Me.ChkBJurnal.AutoSize = True
        Me.ChkBJurnal.Location = New System.Drawing.Point(39, 255)
        Me.ChkBJurnal.Name = "ChkBJurnal"
        Me.ChkBJurnal.Size = New System.Drawing.Size(87, 17)
        Me.ChkBJurnal.TabIndex = 9
        Me.ChkBJurnal.Text = "Jurnal Umum"
        Me.ChkBJurnal.UseVisualStyleBackColor = True
        Me.ChkBJurnal.Visible = False
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Image = CType(resources.GetObject("BtnKeluar.Image"), System.Drawing.Image)
        Me.BtnKeluar.Location = New System.Drawing.Point(489, 542)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(75, 25)
        Me.BtnKeluar.TabIndex = 27
        Me.BtnKeluar.Text = "Keluar"
        Me.BtnKeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'ChkBSawal
        '
        Me.ChkBSawal.AutoSize = True
        Me.ChkBSawal.Enabled = False
        Me.ChkBSawal.Location = New System.Drawing.Point(39, 39)
        Me.ChkBSawal.Name = "ChkBSawal"
        Me.ChkBSawal.Size = New System.Drawing.Size(79, 17)
        Me.ChkBSawal.TabIndex = 8
        Me.ChkBSawal.Text = "Saldo Awal"
        Me.ChkBSawal.UseVisualStyleBackColor = True
        '
        'ChkBSPP
        '
        Me.ChkBSPP.AutoSize = True
        Me.ChkBSPP.Location = New System.Drawing.Point(39, 183)
        Me.ChkBSPP.Name = "ChkBSPP"
        Me.ChkBSPP.Size = New System.Drawing.Size(202, 17)
        Me.ChkBSPP.TabIndex = 5
        Me.ChkBSPP.Text = "Pemberian dan Penerimaan Pinjaman"
        Me.ChkBSPP.UseVisualStyleBackColor = True
        Me.ChkBSPP.Visible = False
        '
        'ChkBAset
        '
        Me.ChkBAset.AutoSize = True
        Me.ChkBAset.Location = New System.Drawing.Point(39, 159)
        Me.ChkBAset.Name = "ChkBAset"
        Me.ChkBAset.Size = New System.Drawing.Size(172, 17)
        Me.ChkBAset.TabIndex = 4
        Me.ChkBAset.Text = "Perolehan dan Pelapasan Aset"
        Me.ChkBAset.UseVisualStyleBackColor = True
        Me.ChkBAset.Visible = False
        '
        'ChkWarga
        '
        Me.ChkWarga.AutoSize = True
        Me.ChkWarga.Location = New System.Drawing.Point(39, 135)
        Me.ChkWarga.Name = "ChkWarga"
        Me.ChkWarga.Size = New System.Drawing.Size(58, 17)
        Me.ChkWarga.TabIndex = 3
        Me.ChkWarga.Text = "Warga"
        Me.ChkWarga.UseVisualStyleBackColor = True
        '
        'ChkProyek
        '
        Me.ChkProyek.AutoSize = True
        Me.ChkProyek.Location = New System.Drawing.Point(39, 111)
        Me.ChkProyek.Name = "ChkProyek"
        Me.ChkProyek.Size = New System.Drawing.Size(59, 17)
        Me.ChkProyek.TabIndex = 2
        Me.ChkProyek.Text = "Proyek"
        Me.ChkProyek.UseVisualStyleBackColor = True
        '
        'ChkKeluar
        '
        Me.ChkKeluar.AutoSize = True
        Me.ChkKeluar.Location = New System.Drawing.Point(39, 87)
        Me.ChkKeluar.Name = "ChkKeluar"
        Me.ChkKeluar.Size = New System.Drawing.Size(86, 17)
        Me.ChkKeluar.TabIndex = 1
        Me.ChkKeluar.Text = "Pengeluaran"
        Me.ChkKeluar.UseVisualStyleBackColor = True
        '
        'ChkPener
        '
        Me.ChkPener.AutoSize = True
        Me.ChkPener.Location = New System.Drawing.Point(39, 63)
        Me.ChkPener.Name = "ChkPener"
        Me.ChkPener.Size = New System.Drawing.Size(82, 17)
        Me.ChkPener.TabIndex = 0
        Me.ChkPener.Text = "Penerimaan"
        Me.ChkPener.UseVisualStyleBackColor = True
        '
        'BtbProses
        '
        Me.BtbProses.Image = CType(resources.GetObject("BtbProses.Image"), System.Drawing.Image)
        Me.BtbProses.Location = New System.Drawing.Point(391, 542)
        Me.BtbProses.Name = "BtbProses"
        Me.BtbProses.Size = New System.Drawing.Size(75, 25)
        Me.BtbProses.TabIndex = 28
        Me.BtbProses.Text = "Proses"
        Me.BtbProses.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BtbProses.UseVisualStyleBackColor = True
        '
        'ChkBBasil
        '
        Me.ChkBBasil.AutoSize = True
        Me.ChkBBasil.Location = New System.Drawing.Point(39, 207)
        Me.ChkBBasil.Name = "ChkBBasil"
        Me.ChkBBasil.Size = New System.Drawing.Size(73, 17)
        Me.ChkBBasil.TabIndex = 6
        Me.ChkBBasil.Text = "Bagi Hasil"
        Me.ChkBBasil.UseVisualStyleBackColor = True
        Me.ChkBBasil.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ChkMKI)
        Me.GroupBox1.Controls.Add(Me.LblProgress)
        Me.GroupBox1.Controls.Add(Me.ProgressBarKos)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TxtKosong)
        Me.GroupBox1.Controls.Add(Me.ChkBSusut)
        Me.GroupBox1.Controls.Add(Me.ChkBFiskal)
        Me.GroupBox1.Controls.Add(Me.ChkBJurnal)
        Me.GroupBox1.Controls.Add(Me.ChkBSawal)
        Me.GroupBox1.Controls.Add(Me.ChkBBasil)
        Me.GroupBox1.Controls.Add(Me.ChkBSPP)
        Me.GroupBox1.Controls.Add(Me.ChkBAset)
        Me.GroupBox1.Controls.Add(Me.ChkWarga)
        Me.GroupBox1.Controls.Add(Me.ChkProyek)
        Me.GroupBox1.Controls.Add(Me.ChkKeluar)
        Me.GroupBox1.Controls.Add(Me.ChkPener)
        Me.GroupBox1.Location = New System.Drawing.Point(25, 47)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(850, 466)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Pilihan Jenis Pengosongan Data"
        '
        'FrmKosong
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 614)
        Me.Controls.Add(Me.BtnKeluar)
        Me.Controls.Add(Me.BtbProses)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmKosong"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Hapus Data"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Timer As Timer
    Friend WithEvents ChkMKI As CheckBox
    Friend WithEvents LblProgress As Label
    Friend WithEvents ProgressBarKos As ProgressBar
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtKosong As TextBox
    Friend WithEvents ChkBSusut As CheckBox
    Friend WithEvents ChkBFiskal As CheckBox
    Friend WithEvents ChkBJurnal As CheckBox
    Friend WithEvents BtnKeluar As Button
    Friend WithEvents ChkBSawal As CheckBox
    Friend WithEvents ChkBSPP As CheckBox
    Friend WithEvents ChkBAset As CheckBox
    Friend WithEvents ChkWarga As CheckBox
    Friend WithEvents ChkProyek As CheckBox
    Friend WithEvents ChkKeluar As CheckBox
    Friend WithEvents ChkPener As CheckBox
    Friend WithEvents BtbProses As Button
    Friend WithEvents ChkBBasil As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
End Class
