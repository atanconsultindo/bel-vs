﻿Imports System.Configuration
Imports System.Windows.Forms
Imports System.Data.OleDb
Public Class FrmKoneksi
    Private Sub FrmSetKonek_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            TxtProvider.Enabled = False
            GetDatabaseSetting()
            'Me.TxtDriver.Text = dbDriver
            Me.TxtProvider.Text = dbProviders
            'Me.TxtServer.Text = dbServer
            Me.TxtSource.Text = ""
            Me.TxtSource.Text = dbSources
            'Me.TxtDB.Text = dbDatabase
            'TxtPass.Text = dbPassword
            'Me.TxtUser.Text = dbUID
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub BtnProses_Click(sender As Object, e As EventArgs) Handles BtnProses.Click
        Try
            'If DatabaseConnected(TxtDriver.Text, TxtServer.Text, TxtDB.Text, TxtPass.Text, TxtUser.Text) = False Then
            If DatabaseConnected(TxtProvider.Text, TxtSource.Text) = False Then
                'MsgBox("Konfigurasi ulang...", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
                Try
                    'Dim newdbDriver As String = TxtDriver.Text
                    'Dim newdbServer As String = TxtServer.Text
                    'Dim newdbDatabase As String = TxtDB.Text
                    'Dim newdbPassword As String = TxtPass.Text
                    'Dim newdbUID As String = TxtUser.Text
                    Dim newdbProvider As String = TxtProvider.Text
                    Dim newdbSource As String = TxtSource.Text

                    With My.Settings
                        .dbProvider = newdbProvider
                        .dbSource = newdbSource
                        .Save()
                    End With
                    MsgBox("Konfigurasi Tersimpan")
                Catch ex As Exception
                    MsgBox("Konfigurasi tidak tersimpan")
                End Try
                GetDatabaseSetting()
            Else
                'My.Settings.Save()
                GetDatabaseSetting()
                Me.DialogResult = DialogResult.OK
                Me.Close()
            End If
            'FrmLogin.Show()
            FrmMain.ToolStripStatusDriver.Text = Me.TxtProvider.Text
            FrmMain.ToolStripStatusDb.Text = Me.TxtDB.Text
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
        'Try
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Try
            TxtProvider.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Label5_DoubleClick(sender As Object, e As EventArgs) Handles Label5.DoubleClick
        Try
            TxtProvider.Enabled = False
        Catch ex As Exception

        End Try
    End Sub


    Private Sub BtnClose_Click_1(sender As Object, e As EventArgs) Handles BtnClose.Click
        Try
            Dispose()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TxtSource_TextChanged(sender As Object, e As EventArgs) Handles TxtSource.TextChanged

    End Sub
End Class