﻿Imports System.Data.OleDb
Public Class FrmTransaksi
    Dim mTahun As String
    '//Penerimaan
    Private Sub Tahun()
        query = " SELECT r_perush.tahun FROM r_perush; "
        daData = New OleDbDataAdapter(query, conn)
        dsData = New DataSet
        daData.Fill(dsData)
        With dsData.Tables(0).Rows(0)
            mTahun = .Item(0)
        End With

    End Sub

    Private Sub PosisiListPenerH()
        Try
            With LVHPener.Columns
                .Add("Tahun", 90)
                .Add("Kd Bulan", 0)
                .Add("Bulan", 100)
                .Add("Kd Mg", 0)
                .Add("Minggu", 100)
                .Add("Uraian", 500)
                '.Add("SubTotal", 150, HorizontalAlignment.Right)
            End With
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub
    '//Penerimaan
    Sub IsiListPenerH()
        Dim a As Integer
        Try
            query = " SELECT ta_penerh.tahun, ta_penerh.kd_bulan, r_bulan.nm_bulan, ta_penerh.kd_minggu, r_minggu.nm_minggu, ta_penerh.Uraian " &
                    " FROM (ta_penerh LEFT JOIN r_bulan ON ta_penerh.kd_bulan = r_bulan.kd_bulan) LEFT JOIN r_minggu ON ta_penerh.kd_minggu = r_minggu.kd_minggu " &
                    " ORDER BY ta_penerh.tahun, ta_penerh.kd_bulan, ta_penerh.kd_minggu; "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVHPener.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVHPener
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    'If Not IsDBNull(dsData.Tables(0).Rows(a).Item(5)) Then
                    '    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(5), "###,##0"))
                    'End If

                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.Orange
                    End If
                End With

            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    '//Penerimaan
    Private Sub CboMinggu_load()
        Dim a As Integer
        Try
            query = " SELECT * FROM r_minggu ORDER BY kd_minggu "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbMinggu.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbMinggu
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2))
                    .Items.Add(dsData.Tables(0).Rows(a).Item(1))
                End With
            Next
        Catch ex As Exception
            MsgBox("Minggu?s")
        End Try
    End Sub
    '//Penerimaan
    Private Sub CbMinggu_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbMinggu.SelectedIndexChanged
        Try
            query = "SELECT * FROM r_minggu WHERE  nm_minggu = '" & CbMinggu.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            'CbMinggu.Items.Clear()

            With dsData.Tables(0).Rows(0)
                LblMinggu.Text = .Item(0)
                LblMinggu.ForeColor = Color.OrangeRed
            End With

            'For a = 0 To dsData.Tables(0).Rows.Count - 1
            '    With CbMinggu
            '        '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2))
            '        .Items.Add(dsData.Tables(0).Rows(a).Item(2))
            '    End With
            'Next
        Catch ex As Exception

        End Try
    End Sub

    '//Penerimaan
    Private Sub CboBulan_load()
        Dim a As Integer
        Try
            query = "SELECT * FROM r_bulan ORDER BY kd_bulan "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CBBulan.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CBBulan
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2))
                    .Items.Add(dsData.Tables(0).Rows(a).Item(1))
                End With
            Next
        Catch ex As Exception
            MsgBox("Bulan?s")
        End Try
    End Sub
    '//Penerimaan
    Private Sub CBBulan_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBBulan.SelectedIndexChanged
        Try
            query = "SELECT * FROM r_bulan WHERE  nm_bulan = '" & CBBulan.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            'CbMinggu.Items.Clear()

            With dsData.Tables(0).Rows(0)
                LblBulan.Text = .Item(0)
                LblBulan.ForeColor = Color.OrangeRed
            End With

            'For a = 0 To dsData.Tables(0).Rows.Count - 1
            '    With CbMinggu
            '        '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2))
            '        .Items.Add(dsData.Tables(0).Rows(a).Item(2))
            '    End With
            'Next
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FrmTransaksi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            GetDatabaseSetting()
            '//Penerimaan
            PosisiListPenerH()
            IsiListPenerH()
            Tahun()
            Me.TxtTahun.Text = mTahun
            TSBTambah.Enabled = True
            TSBSave.Enabled = True
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            TSBCancel.Enabled = True

            CboBulan_load()
            CboMinggu_load()

            '//pengeluaran
            PosisiListKeluarH()
            IsiListKeluarH()
            Me.TxtTahunK.Text = mTahun
            TSBTambahK.Enabled = True
            TSBSaveK.Enabled = True
            TSBEditK.Enabled = False
            TSBDeleteK.Enabled = False
            TSBCancelK.Enabled = True
            CboBulanKel_load()
            CboMingguKel_load()

        Catch ex As Exception

        End Try
    End Sub
    '//Penerimaan
    Private Sub TSBSave_Click(sender As Object, e As EventArgs) Handles TSBSave.Click
        Try
            If TxtTahun.Text = "" Then
                MsgBox("No Bukti tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                TxtTahun.Focus()
            Else
                'If Len(TxtNoBukti.Text) < 13 Then
                '    MsgBox("Panjang karakter minimal 13 digit", MsgBoxStyle.Exclamation, "Error")
                '    TxtNoBukti.Focus()
                'Else
                If CBBulan.Text = "" Then
                    MsgBox(" Bulan tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                    CBBulan.Focus()
                Else
                    If CbMinggu.Text = "" Then
                        MsgBox("Kode Minggu tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                        CbMinggu.Focus()
                    Else
                        'query = "UPDATE tblNamaKlinik SET namaklinik = '" & TxtPerush.Text & _
                        '        "', namapimpinan = '" & TxtPimpinan.Text & _
                        '        "', alamat = '" & TxtAlamat.Text & _
                        '        "', notelepon = '" & TxtTelepon.Text & "'"


                        query = "INSERT INTO ta_penerh(tahun,kd_bulan,kd_minggu,Uraian) values('" & TxtTahun.Text &
                                    "', '" & LblBulan.Text & "', '" & LblMinggu.Text &
                                    "', '" & TxtUraian.Text & "') "
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        InsertJurnalPenerH()
                        IsiListPenerH()
                        BersihkanIsianPenerH()
                        MsgBox("Simpan data berhasil", , "Pesan")


                    End If
                End If
            End If
            'End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    '//Penerimaan
    Private Sub InsertJurnalPenerH()
        Try
            query = "INSERT INTO ta_jurnalh(JurnalId,tahun, kd_bulan, kd_minggu, TipeId,uraian) values('" & TxtTahun.Text & "/" & LblBulan.Text & "/" & LblMinggu.Text &
                                   "',  '" & TxtTahun.Text & "', '" & LblBulan.Text & "','" & LblMinggu.Text & "',  'CRJ', '" & TxtUraian.Text & "') "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    '//Penerimaan
    Private Sub BersihkanIsianPenerH()
        'TxtTahun.Text = ""
        CBBulan.Text = ""
        CbMinggu.Text = ""
        LblMinggu.Text = ""
        TxtUraian.Text = ""
    End Sub

    Private Sub BtnKeluar_Click(sender As Object, e As EventArgs) Handles BtnKeluar.Click
        Dispose()
    End Sub
    '//Penerimaan
    Private Sub LVHPener_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVHPener.SelectedIndexChanged
        Try
            TxtTahun.Enabled = False
            CBBulan.Enabled = False
            CbMinggu.Enabled = False
            AmbilListViewHPenener()
        Catch ex As Exception

        End Try
    End Sub
    '//Penerimaan
    Private Sub AmbilListViewHPenener()
        '.Add("Tahun", 90)
        '.Add("Kd Bulan", 0)
        '.Add("Bulan", 100)
        '.Add("Kd Mg", 0)
        '.Add("Minggu", 100)
        '.Add("Uraian", 500)

        With LVHPener.SelectedItems
            Try
                TxtTahun.Text = .Item(0).SubItems(0).Text
                LblBulan.Text = .Item(0).SubItems(1).Text
                CBBulan.Text = .Item(0).SubItems(2).Text
                LblMinggu.Text = .Item(0).SubItems(3).Text
                CbMinggu.Text = .Item(0).SubItems(4).Text
                TxtUraian.Text = .Item(0).SubItems(5).Text
            Catch ex As Exception

            End Try
        End With
    End Sub
    '//Penerimaan
    Private Sub TSBEdit_Click(sender As Object, e As EventArgs) Handles TSBEdit.Click
        Try
            If TxtTahun.Text = "" Then
                MsgBox("No Bukti tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                TxtTahun.Focus()
            Else
                'If Len(TxtNoBukti.Text) < 13 Then
                '    MsgBox("Panjang karakter minimal 13 digit", MsgBoxStyle.Exclamation, "Error")
                '    TxtNoBukti.Focus()
                'Else
                If CBBulan.Text = "" Then
                    MsgBox("Bulan tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                    CBBulan.Focus()
                Else
                    If CbMinggu.Text = "" Then
                        MsgBox("Kode Minggu tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                        CbMinggu.Focus()
                    Else
                        UpdateJurnalPenerH()
                        'query = "INSERT INTO ta_penerh(kd_minggu,no_bukti,tanggal,Uraian) values('" & LblMinggu.Text &
                        '            "', '" & TxtNoBukti.Text & "', '" & DateTPHPener.Text &
                        '            "', '" & TxtUraian.Text & "') "
                        query = " UPDATE ta_penerh SET ta_penerh.uraian = '" & TxtUraian.Text & "' " &
                                " WHERE (((ta_penerh.tahun)= '" & TxtTahun.Text & "') AND ((ta_penerh.kd_bulan)='" & LblBulan.Text & "') AND ((ta_penerh.kd_minggu)='" & LblMinggu.Text & "')) "
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)

                        IsiListPenerH()
                        BersihkanIsianPenerH()
                        MsgBox("Update data berhasil", , "Pesan")


                    End If
                End If
            End If
            'End If
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub

    '//penerimaan 

    Private Sub UpdateJurnalPenerH()
        Try
            query = " UPDATE ta_jurnalh SET ta_jurnalh.tahun = '" & TxtTahun.Text & "', ta_jurnalh.kd_bulan = '" & LblBulan.Text & "', ta_jurnalh.kd_minggu = '" & LblMinggu.Text & "', ta_jurnalh.uraian = '" & TxtUraian.Text & "' " &
                               " WHERE ta_jurnalh.JurnalId= '" & TxtTahun.Text & "/" & LblBulan.Text & "/" & LblMinggu.Text & "' AND ta_jurnalh.TipeId='CRJ'  "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    '//Penerimaan
    Private Sub LVHPener_Click(sender As Object, e As EventArgs) Handles LVHPener.Click
        Try
            TSBTambah.Enabled = False
            TSBSave.Enabled = False
            TSBEdit.Enabled = True
            TSBDelete.Enabled = True
        Catch ex As Exception

        End Try
    End Sub
    '//Penerimaan
    Private Sub TSBTambah_Click(sender As Object, e As EventArgs) Handles TSBTambah.Click
        'TxtTahun.Enabled = False
        CBBulan.Enabled = True
        CbMinggu.Enabled = True
        BersihkanIsianPenerH()
        TSBSave.Enabled = True
        TSBEdit.Enabled = False
        TSBDelete.Enabled = False

    End Sub
    '//Penerimaan
    Private Sub TSBDelete_Click(sender As Object, e As EventArgs) Handles TSBDelete.Click

        Try
            CariDatadiPenerD()
            'CariDataDiJurnalChild()
        Catch ex As Exception

        End Try

    End Sub
    '//Penerimaan
    Private Sub CariDatadiPenerD()
        Try
            query = "SELECT tahun, kd_minggu, kd_bulan FROM ta_penerd WHERE tahun = '" & TxtTahun.Text & "' AND kd_bulan = '" & LblBulan.Text & "' AND kd_minggu = '" & LblMinggu.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            If dsData.Tables(0).Rows.Count > 0 Then
                MsgBox("Transaksi '" & TxtTahun.Text & "/" & LblBulan.Text & "/" & LblMinggu.Text & "' sudah ada rincian, hapus data gagal", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
                TxtTahun.Enabled = True
                TxtTahun.Focus()
                BersihkanIsianPenerH()
            Else
                HapusJurnalPenerH()
                HapusDataPenerH()
            End If

        Catch ex As Exception

        End Try
    End Sub
    '//Penerimaan
    Private Sub HapusDataPenerH()
        Dim delete As String
        delete = MsgBox("Yakin hapus...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus")
        Select Case delete
            Case vbCancel
                TxtTahun.Enabled = True
                TxtTahun.Focus()
                BersihkanIsianPenerH()
                Exit Sub
            Case vbOK
                If TxtTahun.Text = "" Then
                    MsgBox("Kode tidak boleh kosong", MsgBoxStyle.Critical, "Error")
                    TxtTahun.Enabled = True
                    TxtTahun.Focus()
                Else
                    Try

                        query = "DELETE FROM ta_penerh WHERE tahun = '" & TxtTahun.Text & "' AND kd_bulan = '" & LblBulan.Text & "' AND kd_minggu = '" & LblMinggu.Text & "' "
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)

                        IsiListPenerH()
                        BersihkanIsianPenerH()
                        MsgBox("Hapus data berhasil", , "Pesan")
                    Catch ex As Exception
                        MsgBox("Hapus data gagal", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
                        TxtTahun.Focus()
                    End Try
                End If
        End Select
    End Sub
    '//Penerimaan
    Private Sub HapusJurnalPenerH()
        Try
            query = "DELETE FROM ta_jurnalh WHERE JurnalId = '" & TxtTahun.Text & "/" & LblBulan.Text & "/" & LblMinggu.Text & "' AND TipeId = 'CRJ' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    '//Penerimaan
    Private Sub TSBCancel_Click(sender As Object, e As EventArgs) Handles TSBCancel.Click
        Try
            TSBTambah.Enabled = True
            TSBSave.Enabled = True
            TSBEdit.Enabled = False
            TSBDelete.Enabled = False
            BersihkanIsianPenerH()

        Catch ex As Exception

        End Try
    End Sub
    '//Penerimaan
    Private Sub LVHPener_DoubleClick(sender As Object, e As EventArgs) Handles LVHPener.DoubleClick
        Try
            FrmDPener.ShowDialog()
        Catch ex As Exception

        End Try

    End Sub

    '//Pengeluaran
    Private Sub PosisiListKeluarH()
        Try
            With LVHKel.Columns
                .Add("Tahun", 90)
                .Add("Kd Bulan", 0)
                .Add("Bulan", 100)
                .Add("Kd Mg", 0)
                .Add("Minggu", 100)
                .Add("Uraian", 500)
                '.Add("SubTotal", 150, HorizontalAlignment.Right)
            End With
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub

    '//Pengeluaran
    Sub IsiListKeluarH()
        Dim a As Integer
        Try
            'query = " SELECT ta_keluarh.kd_minggu, ta_keluarh.no_bukti, ta_keluarh.tanggal, ta_keluarh.Uraian " &
            '        " FROM ta_keluarh " &
            '        " ORDER BY ta_keluarh.kd_minggu, ta_keluarh.no_bukti, ta_keluarh.tanggal; "

            query = " SELECT ta_keluarh.tahun, ta_keluarh.kd_bulan, r_bulan.nm_bulan, ta_keluarh.kd_minggu, r_minggu.nm_minggu, ta_keluarh.Uraian " &
                    " FROM (ta_keluarh LEFT JOIN r_bulan ON ta_keluarh.kd_bulan = r_bulan.kd_bulan) LEFT JOIN r_minggu ON ta_keluarh.kd_minggu = r_minggu.kd_minggu " &
                    " ORDER BY ta_keluarh.tahun, ta_keluarh.kd_bulan, ta_keluarh.kd_minggu; "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            LVHKel.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With LVHKel
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    'If Not IsDBNull(dsData.Tables(0).Rows(a).Item(5)) Then
                    '    .Items(a).SubItems.Add(Format(dsData.Tables(0).Rows(a).Item(5), "###,##0"))
                    'End If

                    If (a Mod 2 = 0) Then
                        .Items(a).BackColor = Color.LightSteelBlue
                    Else
                        .Items(a).BackColor = Color.Orange
                    End If
                End With

            Next

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    '//Pengeluaran
    Private Sub CboBulanKel_load()
        Dim a As Integer
        Try
            query = "SELECT * FROM r_bulan ORDER BY kd_bulan "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbBulanK.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbBulanK
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2))
                    .Items.Add(dsData.Tables(0).Rows(a).Item(1))
                End With
            Next
        Catch ex As Exception
            MsgBox("Bulan?s")
        End Try
    End Sub


    '//Pengeluaran
    Private Sub CboMingguKel_load()
        Dim a As Integer
        Try
            query = "SELECT * FROM r_minggu ORDER BY kd_minggu "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            CbMingguK.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With CbMingguK
                    '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2))
                    .Items.Add(dsData.Tables(0).Rows(a).Item(1))
                End With
            Next
        Catch ex As Exception

        End Try
    End Sub

    '//Pengeluaran
    Private Sub CBMingguHKel_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    '// Pengeluaran
    Private Sub BersihkanIsianKeluarH()
        Try

            'TxtTahunK.Text = ""
            CbBulanK.Text = ""
            CbMingguK.Text = ""
            LblMingguK.Text = ""
            TxtUraianK.Text = ""
        Catch ex As Exception

        End Try

    End Sub

    '//Pengeluaran
    Private Sub LVHKel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LVHKel.SelectedIndexChanged
        Try
            TxtTahunK.Enabled = False
            CbBulanK.Enabled = False
            CbMingguK.Enabled = False
            AmbilListViewHKel()
        Catch ex As Exception

        End Try
    End Sub

    '//Pengeluaran
    Private Sub AmbilListViewHKel()
        With LVHKel.SelectedItems
            Try
                TxtTahunK.Text = .Item(0).SubItems(0).Text
                LblBulanK.Text = .Item(0).SubItems(1).Text
                CbBulanK.Text = .Item(0).SubItems(2).Text
                LblMingguK.Text = .Item(0).SubItems(3).Text
                CbMingguK.Text = .Item(0).SubItems(4).Text
                TxtUraianK.Text = .Item(0).SubItems(5).Text
            Catch ex As Exception

            End Try
        End With
    End Sub


    '//Pengeluaran
    Private Sub LVHKel_Click(sender As Object, e As EventArgs) Handles LVHKel.Click
        Try
            TSBTambahK.Enabled = False
            TSBSaveK.Enabled = False
            TSBEditK.Enabled = True
            TSBDeleteK.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    '//Pengeluaran
    Private Sub LVHKel_DoubleClick(sender As Object, e As EventArgs) Handles LVHKel.DoubleClick
        Try
            FrmDKeluar.ShowDialog()
        Catch ex As Exception

        End Try
    End Sub
    '//Pengeluaran
    Private Sub TSBSaveK_Click(sender As Object, e As EventArgs) Handles TSBSaveK.Click
        Try
            If TxtTahunK.Text = "" Then
                MsgBox("No Bukti tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                TxtTahunK.Focus()
            Else
                'If Len(TxtNoBukti.Text) < 13 Then
                '    MsgBox("Panjang karakter minimal 13 digit", MsgBoxStyle.Exclamation, "Error")
                '    TxtNoBukti.Focus()
                'Else
                If CbBulanK.Text = "" Then
                    MsgBox(" Bulan tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                    CbBulanK.Focus()
                Else
                    If CbMingguK.Text = "" Then
                        MsgBox("Kode Minggu tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                        CbMingguK.Focus()
                    Else
                        'query = "UPDATE tblNamaKlinik SET namaklinik = '" & TxtPerush.Text & _
                        '        "', namapimpinan = '" & TxtPimpinan.Text & _
                        '        "', alamat = '" & TxtAlamat.Text & _
                        '        "', notelepon = '" & TxtTelepon.Text & "'"


                        query = "INSERT INTO ta_keluarh(tahun,kd_bulan,kd_minggu,Uraian) values('" & TxtTahunK.Text &
                                    "', '" & LblBulanK.Text & "', '" & LblMingguK.Text &
                                    "', '" & TxtUraianK.Text & "') "
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        InsertJurnalKeluarH()
                        'InsertJurnalPerentTunai()
                        IsiListKeluarH()
                        BersihkanIsianKeluarH()
                        MsgBox("Simpan data berhasil", , "Pesan")


                    End If
                End If
            End If
            'End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    '//Pengeluaran
    Private Sub InsertJurnalKeluarH()


        Try
            query = "INSERT INTO ta_jurnalh(JurnalId,tahun, kd_bulan, kd_minggu, TipeId,uraian) values('" & TxtTahunK.Text & "/" & LblBulanK.Text & "/" & LblMingguK.Text &
                                   "', '" & TxtTahunK.Text & "','" & LblBulanK.Text & "','" & LblMingguK.Text & "','CDJ','" & TxtUraianK.Text & "') "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub
    '//Pengeluaran
    Private Sub TSBEditK_Click(sender As Object, e As EventArgs) Handles TSBEditK.Click
        Try
            If TxtTahunK.Text = "" Then
                MsgBox("No Bukti tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                TxtTahunK.Focus()
            Else
                'If Len(TxtNoBukti.Text) < 13 Then
                '    MsgBox("Panjang karakter minimal 13 digit", MsgBoxStyle.Exclamation, "Error")
                '    TxtNoBukti.Focus()
                'Else
                If CbBulanK.Text = "" Then
                    MsgBox("Bulan tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                    CbBulanK.Focus()
                Else
                    If CbMingguK.Text = "" Then
                        MsgBox("Kode Minggu tidak boleh kosong", MsgBoxStyle.Exclamation, "Error")
                        CbMingguK.Focus()
                    Else
                        UpdateJurnalKeluarH()
                        'query = "INSERT INTO ta_penerh(kd_minggu,no_bukti,tanggal,Uraian) values('" & LblMinggu.Text &
                        '            "', '" & TxtNoBukti.Text & "', '" & DateTPHPener.Text &
                        '            "', '" & TxtUraian.Text & "') "
                        query = " UPDATE ta_keluarh SET ta_keluarh.uraian = '" & TxtUraianK.Text & "' " &
                                " WHERE (((ta_keluarh.tahun)= '" & TxtTahunK.Text & "') AND ((ta_keluarh.kd_bulan)='" & LblBulanK.Text & "') AND ((ta_keluarh.kd_minggu)='" & LblMingguK.Text & "'))  "
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        'InsertJurnalPerentTunai()
                        IsiListKeluarH()
                        BersihkanIsianKeluarH()
                        MsgBox("Update data berhasil", , "Pesan")


                    End If
                End If
            End If
            'End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub UpdateJurnalKeluarH()
        Try
            'query = " UPDATE ta_jurnalh SET ta_jurnalh.uraian = '" & TxtUraianK.Text & "' " &
            '                   " WHERE (((ta_jurnalh.JurnalId)= '" & TxtTahunK.Text & "/" & LblBulanK.Text & "/" & LblMingguK.Text & "')) "
            query = " UPDATE ta_jurnalh SET ta_jurnalh.tahun = '" & TxtTahunK.Text & "', ta_jurnalh.kd_bulan = '" & LblBulanK.Text & "', ta_jurnalh.kd_minggu = '" & LblMingguK.Text & "', ta_jurnalh.uraian = '" & TxtUraianK.Text & "' " &
                               " WHERE ta_jurnalh.JurnalId= '" & TxtTahunK.Text & "/" & LblBulanK.Text & "/" & LblMingguK.Text & "' AND ta_jurnalh.TipeId='CDJ' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    '//Pengeluaran
    Private Sub TSBDeleteK_Click(sender As Object, e As EventArgs) Handles TSBDeleteK.Click

        Try
            CariDatadiKeluarD()
            'CariDataDiJurnalChild()
        Catch ex As Exception

        End Try
    End Sub
    '//Pengeluaran
    Private Sub CariDatadiKeluarD()
        Try
            query = "SELECT tahun, kd_minggu, kd_bulan FROM ta_keluard WHERE tahun = '" & TxtTahunK.Text & "' AND kd_bulan = '" & LblBulanK.Text & "' AND kd_minggu = '" & LblMingguK.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

            If dsData.Tables(0).Rows.Count > 0 Then
                MsgBox("Transaksi '" & TxtTahunK.Text & "/" & LblBulanK.Text & "/" & LblMingguK.Text & "' sudah ada rincian, hapus data gagal", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
                TxtTahunK.Enabled = True
                TxtTahunK.Focus()
                BersihkanIsianKeluarH()
            Else
                HapusJurnalKeluarH()
                HapusDataKeluarH()
            End If

        Catch ex As Exception

        End Try
    End Sub
    '//Pengeluaran
    Private Sub HapusJurnalKeluarH()
        Try
            query = "DELETE FROM ta_jurnalh WHERE JurnalId = '" & TxtTahunK.Text & "/" & LblBulanK.Text & "/" & LblMingguK.Text & "' AND TipeId = 'CDJ' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    '//Pengeluaran
    Private Sub HapusDataKeluarH()
        Dim delete As String
        delete = MsgBox("Yakin hapus...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus")
        Select Case delete
            Case vbCancel
                TxtTahunK.Enabled = True
                TxtTahunK.Focus()
                BersihkanIsianKeluarH()
                Exit Sub
            Case vbOK
                If TxtTahunK.Text = "" Then
                    MsgBox("Kode tidak boleh kosong", MsgBoxStyle.Critical, "Error")
                    TxtTahunK.Enabled = True
                    TxtTahunK.Focus()
                Else
                    Try
                        query = "DELETE FROM ta_keluarh WHERE tahun = '" & TxtTahunK.Text & "' AND kd_bulan = '" & LblBulanK.Text & "' AND kd_minggu = '" & LblMingguK.Text & "' "
                        daData = New OleDbDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        IsiListKeluarH()
                        BersihkanIsianKeluarH()
                        MsgBox("Hapus data berhasil", , "Pesan")
                    Catch ex As Exception
                        MsgBox("Hapus data gagal", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Pesan")
                        TxtTahunK.Focus()
                    End Try
                End If
        End Select
    End Sub
    '//Pengeluaran
    Private Sub TSBCancelK_Click(sender As Object, e As EventArgs) Handles TSBCancelK.Click
        Try
            TSBTambahK.Enabled = True
            TSBSaveK.Enabled = True
            TSBEditK.Enabled = False
            TSBDeleteK.Enabled = False
            BersihkanIsianKeluarH()
        Catch ex As Exception

        End Try

    End Sub
    '//Pengeluaran
    Private Sub TSBTambahK_Click(sender As Object, e As EventArgs) Handles TSBTambahK.Click
        Try
            'TxtTahun.Enabled = False
            CbBulanK.Enabled = True
            CbMingguK.Enabled = True
            BersihkanIsianKeluarH()
            TSBSaveK.Enabled = True
            TSBEditK.Enabled = False
            TSBDeleteK.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub CbMingguK_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbMingguK.SelectedIndexChanged
        Try
            query = "SELECT * FROM r_minggu WHERE  nm_minggu = '" & CbMingguK.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            'CbMinggu.Items.Clear()

            With dsData.Tables(0).Rows(0)
                LblMingguK.Text = .Item(0)
                LblMingguK.ForeColor = Color.OrangeRed
            End With

            'For a = 0 To dsData.Tables(0).Rows.Count - 1
            '    With CbMinggu
            '        '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2))
            '        .Items.Add(dsData.Tables(0).Rows(a).Item(2))
            '    End With
            'Next
        Catch ex As Exception

        End Try
    End Sub

    Private Sub CbBulanK_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbBulanK.SelectedIndexChanged
        Try
            query = "SELECT * FROM r_bulan WHERE  nm_bulan = '" & CbBulanK.Text & "' "
            daData = New OleDbDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            'CbMinggu.Items.Clear()

            With dsData.Tables(0).Rows(0)
                LblBulanK.Text = .Item(0)
                LblBulanK.ForeColor = Color.OrangeRed
            End With

            'For a = 0 To dsData.Tables(0).Rows.Count - 1
            '    With CbMinggu
            '        '.Items.Add(dsData.Tables(0).Rows(a).Item(1) & " : " & dsData.Tables(0).Rows(a).Item(2))
            '        .Items.Add(dsData.Tables(0).Rows(a).Item(2))
            '    End With
            'Next
        Catch ex As Exception

        End Try
    End Sub
End Class